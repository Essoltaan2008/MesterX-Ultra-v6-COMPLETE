# ⚡ MesterX Ultra Enterprise v6

> **نظام إدارة أعمال متكامل — إنتاج مصري 🇪🇬**
> Clean Architecture · Offline-First · Multi-Tenant · Docker Ready

---

## 🚀 تشغيل سريع (5 دقايق)

```bash
# 1. انسخ المتغيرات
cp .env.example .env

# 2. عدّل .env — غيّر DB_PASSWORD و JWT_SECRET
nano .env

# 3. شغّل
docker compose up -d --build

# 4. افتح المتصفح
# Frontend : http://localhost:3000
# API Docs : http://localhost:5000/swagger
# Health   : http://localhost:5000/health
```

---

## 🏗️ هيكل المشروع

```
MesterX-Ultra-v6/
├── backend/
│   ├── Dockerfile
│   └── src/
│       ├── MesterX.Domain/          ← Entities, Enums, Interfaces
│       ├── MesterX.Application/     ← Business Logic, Services, DTOs
│       ├── MesterX.Infrastructure/  ← DB, Repositories, Background Jobs
│       └── MesterX.API/             ← Controllers, Hubs, Program.cs
├── frontend/                        ← Next.js 14 App
│   ├── pages/
│   ├── lib/
│   └── Dockerfile
├── database/
│   └── schema.sql                   ← 37 جدول PostgreSQL
├── devops/
│   ├── nginx.conf                   ← Reverse Proxy + SSL
│   └── nginx-frontend.conf
├── docker-compose.yml
├── .env.example
└── MesterX-Ultra-v6.sln
```

---

## 📦 الوحدات

| الوحدة | الوصف |
|--------|-------|
| 🔐 **Auth & RBAC** | JWT + BCrypt + Refresh Tokens + 5 أدوار |
| 🔑 **License Engine** | 5 خطط، Device Fingerprint، Auto-Downgrade |
| 🛒 **POS** | كاشير، باركود، VAT 14%، دفع مختلط |
| 📦 **Inventory** | منتجات، مخزون، حركات، تنبيه نفاذ |
| 🚚 **Purchase Orders** | أوامر شراء، موردين |
| 🔄 **Offline Sync** | Push/Pull + Conflict Resolution |
| 🍽️ **Restaurant** | مناطق، طاولات، كيتشن، SignalR |
| 🎪 **Marketplace** | Vendors، Bookings، Reviews |
| 🚴 **Delivery** | سائقين، تتبع |
| 📊 **Reports** | مبيعات، أرباح، مخزون |
| 📝 **Audit Log** | كل العمليات محفوظة |

---

## 💰 خطط الأسعار (بالجنيه المصري)

| الخطة | السعر | المميزات |
|-------|-------|----------|
| **Trial** | مجاني 14 يوم | كل المميزات |
| **Basic** | مجاني للأبد | 1 فرع، 1 مستخدم، 500 منتج |
| **Pro Monthly** | 499 ج.م/شهر | مزامنة + backup + تقارير |
| **Lifetime** | 9,999 ج.م مرة | أوفلاين دايم، مزامنة بـ 999/سنة |
| **Enterprise** | 1,999 ج.م/شهر | كل حاجة + API + White Label |

---

## 🔌 API Endpoints

### Auth
```
POST /api/auth/register
POST /api/auth/login
POST /api/auth/refresh
POST /api/auth/logout
GET  /api/auth/me
POST /api/auth/change-password
```

### POS
```
GET  /api/pos/products?branchId=&search=
POST /api/pos/sale
GET  /api/pos/sales
GET  /api/pos/sales/{id}
POST /api/pos/sales/{id}/refund
```

### Inventory
```
GET    /api/inventory/products
POST   /api/inventory/products
PUT    /api/inventory/products/{id}
DELETE /api/inventory/products/{id}
GET    /api/inventory/stock?lowStockOnly=true
POST   /api/inventory/stock/adjust
GET    /api/inventory/barcode/{barcode}
```

### License
```
GET  /api/license/status
GET  /api/license/plans
POST /api/license/activate
POST /api/license/activate-sync
```

### Sync (Offline-First)
```
POST /api/sync/push
GET  /api/sync/pull?since=
```

### Reports
```
GET /api/dashboard?branchId=
GET /api/dashboard/sales-report?fromDate=&toDate=
```

---

## 🔒 الأمان

- BCrypt hashing (cost 12)
- JWT 60 دقيقة + Refresh Token 30 يوم
- License key مخزّنة كـ SHA-512
- Device fingerprint كـ SHA-256
- Rate Limiting: 10 req/min (auth), 300 req/min (API)
- Tenant isolation على كل query
- Soft Delete — مفيش حذف فعلي
- Audit Log لكل عملية

---

## 🛠️ للمطورين

### متطلبات التشغيل المحلي
- .NET 8 SDK
- PostgreSQL 16
- Node.js 20

### تشغيل بدون Docker
```bash
# Backend
cd backend
dotnet restore MesterX-Ultra-v6.sln
dotnet run --project src/MesterX.API

# Frontend
cd frontend
npm install
npm run dev
```

### EF Core Migrations
```bash
cd backend
dotnet ef migrations add InitialCreate --project src/MesterX.Infrastructure --startup-project src/MesterX.API
dotnet ef database update --project src/MesterX.Infrastructure --startup-project src/MesterX.API
```

---

## 📊 إحصائيات المشروع

| المقياس | القيمة |
|---------|--------|
| Layer | Clean Architecture (4 طبقات) |
| ملفات C# | 118+ ملف |
| جداول DB | 37 جدول |
| DbSets | 54 entity |
| API Endpoints | 50+ endpoint |
| ضريبة القيمة المضافة | 14% (مصر) |

---

*MesterX Ultra Enterprise v6.0.0 — صُنع في مصر 🇪🇬*
