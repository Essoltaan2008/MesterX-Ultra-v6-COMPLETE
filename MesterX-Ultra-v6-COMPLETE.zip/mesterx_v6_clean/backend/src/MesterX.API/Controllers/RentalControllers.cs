using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using MesterX.Application.Services;
using MesterX.Domain.Entities.Rental;
// using MesterX.Domain.Entities;

namespace MesterX.API.Controllers;

// ═══════════════════════════════════════════════════════════════════════════
// RENTAL ASSET CONTROLLER
// ═══════════════════════════════════════════════════════════════════════════

[Route("api/rental/assets"), Authorize, EnableRateLimiting("api")]
public class RentalAssetController : MesterXBaseController
{
    private readonly IRentalAssetService _assets;
    public RentalAssetController(IRentalAssetService assets) => _assets = assets;

    /// <summary>GET /api/rental/assets?page=1&pageSize=20&category=0&status=0&search=فستان</summary>
    [HttpGet]
    public async Task<IActionResult> List(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        [FromQuery] AssetCategory? category = null,
        [FromQuery] AssetStatus? status = null,
        [FromQuery] string? search = null,
        CancellationToken ct = default)
    {
        var result = await _assets.ListAsync(CurrentTenantId, page, pageSize, category, status, search, ct);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    /// <summary>GET /api/rental/assets/{id}</summary>
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct = default)
    {
        var result = await _assets.GetByIdAsync(CurrentTenantId, id, ct);
        return result.Success ? Ok(result) : NotFound(result);
    }

    /// <summary>POST /api/rental/assets</summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateRentalAssetRequest req, CancellationToken ct = default)
    {
        if (!IsManager) return Forbid();
        var result = await _assets.CreateAsync(CurrentTenantId, CurrentUserId, req, ct);
        return result.Success
            ? CreatedAtAction(nameof(Get), new { id = result.Data!.Id }, result)
            : BadRequest(result);
    }

    /// <summary>PATCH /api/rental/assets/{id}/status</summary>
    [HttpPatch("{id:guid}/status")]
    public async Task<IActionResult> UpdateStatus(Guid id, [FromBody] AssetStatus newStatus, CancellationToken ct = default)
    {
        if (!IsManager) return Forbid();
        var result = await _assets.UpdateStatusAsync(CurrentTenantId, id, newStatus, ct);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    /// <summary>GET /api/rental/assets/{id}/availability?from=2024-01-01&to=2024-01-31</summary>
    [HttpGet("{id:guid}/availability")]
    public async Task<IActionResult> Availability(
        Guid id, [FromQuery] DateTime from, [FromQuery] DateTime to, CancellationToken ct = default)
    {
        var result = await _assets.GetAvailabilityAsync(CurrentTenantId, id, from, to, ct);
        return Ok(result);
    }

    /// <summary>POST /api/rental/assets/{id}/check-availability</summary>
    [HttpPost("{id:guid}/check-availability")]
    public async Task<IActionResult> CheckAvailability(
        Guid id,
        [FromQuery] DateTime pickupDate,
        [FromQuery] DateTime returnDate,
        [FromQuery] Guid? excludeBookingId = null,
        CancellationToken ct = default)
    {
        var result = await _assets.CheckAvailabilityAsync(
            CurrentTenantId, id, pickupDate, returnDate, excludeBookingId, ct);
        return Ok(result);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// RENTAL BOOKING CONTROLLER
// ═══════════════════════════════════════════════════════════════════════════

[Route("api/rental/bookings"), Authorize, EnableRateLimiting("api")]
public class RentalBookingController : MesterXBaseController
{
    private readonly IRentalBookingService _bookings;
    public RentalBookingController(IRentalBookingService bookings) => _bookings = bookings;

    /// <summary>GET /api/rental/bookings?page=1&status=1&from=2024-01-01&to=2024-12-31</summary>
    [HttpGet]
    public async Task<IActionResult> List(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        [FromQuery] BookingStatus? status = null,
        [FromQuery] DateTime? from = null,
        [FromQuery] DateTime? to = null,
        CancellationToken ct = default)
    {
        var result = await _bookings.ListAsync(CurrentTenantId, page, pageSize, status, from, to, ct);
        return Ok(result);
    }

    /// <summary>GET /api/rental/bookings/{id}</summary>
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct = default)
    {
        var result = await _bookings.GetByIdAsync(CurrentTenantId, id, ct);
        return result.Success ? Ok(result) : NotFound(result);
    }

    /// <summary>POST /api/rental/bookings</summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateBookingRequest req, CancellationToken ct = default)
    {
        var result = await _bookings.CreateAsync(CurrentTenantId, CurrentUserId, req, ct);
        return result.Success
            ? CreatedAtAction(nameof(Get), new { id = result.Data!.Id }, result)
            : BadRequest(result);
    }

    /// <summary>POST /api/rental/bookings/{id}/confirm</summary>
    [HttpPost("{id:guid}/confirm")]
    public async Task<IActionResult> Confirm(Guid id, CancellationToken ct = default)
    {
        if (!IsManager) return Forbid();
        var result = await _bookings.ConfirmAsync(CurrentTenantId, id, CurrentUserId, ct);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    /// <summary>POST /api/rental/bookings/{id}/pickup</summary>
    [HttpPost("{id:guid}/pickup")]
    public async Task<IActionResult> MarkPickedUp(Guid id, CancellationToken ct = default)
    {
        var result = await _bookings.MarkPickedUpAsync(CurrentTenantId, id, CurrentUserId, ct);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    /// <summary>POST /api/rental/bookings/{id}/return</summary>
    [HttpPost("{id:guid}/return")]
    public async Task<IActionResult> MarkReturned(Guid id, CancellationToken ct = default)
    {
        var result = await _bookings.MarkReturnedAsync(CurrentTenantId, id, CurrentUserId, ct);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    /// <summary>POST /api/rental/bookings/{id}/cancel</summary>
    [HttpPost("{id:guid}/cancel")]
    public async Task<IActionResult> Cancel(Guid id, CancellationToken ct = default)
    {
        if (!IsManager) return Forbid();
        var result = await _bookings.CancelAsync(CurrentTenantId, id, CurrentUserId, ct);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    /// <summary>POST /api/rental/bookings/{id}/waive-penalty</summary>
    [HttpPost("{id:guid}/waive-penalty")]
    public async Task<IActionResult> WaivePenalty(Guid id, CancellationToken ct = default)
    {
        if (!IsOwner) return Forbid();
        var result = await _bookings.WaivePenaltyAsync(CurrentTenantId, id, CurrentUserId, ct);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    /// <summary>POST /api/rental/bookings/payment</summary>
    [HttpPost("payment")]
    public async Task<IActionResult> AddPayment([FromBody] AddRentalPaymentRequest req, CancellationToken ct = default)
    {
        var result = await _bookings.AddPaymentAsync(CurrentTenantId, CurrentUserId, req, ct);
        return result.Success ? Ok(result) : BadRequest(result);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// RENTAL MODULE CONTROLLER (Platform Admin only)
// ═══════════════════════════════════════════════════════════════════════════

[Route("api/platform/rental-module"), Authorize, EnableRateLimiting("api")]
public class RentalModuleController : MesterXBaseController
{
    private readonly IRentalModuleService _module;
    public RentalModuleController(IRentalModuleService module) => _module = module;

    /// <summary>POST /api/platform/rental-module/{tenantId}/activate</summary>
    [HttpPost("{tenantId:guid}/activate")]
    public async Task<IActionResult> Activate(Guid tenantId, CancellationToken ct = default)
    {
        if (!IsPlatformOwner) return Forbid();
        var result = await _module.ActivateRentalModuleAsync(tenantId, CurrentUserId, ct);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    /// <summary>POST /api/platform/rental-module/{tenantId}/deactivate</summary>
    [HttpPost("{tenantId:guid}/deactivate")]
    public async Task<IActionResult> Deactivate(Guid tenantId, CancellationToken ct = default)
    {
        if (!IsPlatformOwner) return Forbid();
        var result = await _module.DeactivateRentalModuleAsync(tenantId, CurrentUserId, ct);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    /// <summary>GET /api/platform/rental-module/{tenantId}/status</summary>
    [HttpGet("{tenantId:guid}/status")]
    public async Task<IActionResult> Status(Guid tenantId, CancellationToken ct = default)
    {
        if (!IsPlatformOwner) return Forbid();
        var active = await _module.IsRentalActiveAsync(tenantId, ct);
        return Ok(new { tenantId, rentalModuleActive = active });
    }
}
