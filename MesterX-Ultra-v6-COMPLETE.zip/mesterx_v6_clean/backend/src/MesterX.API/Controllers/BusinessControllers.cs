using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MesterX.Application.Common.Interfaces;
using MesterX.Domain.Enums;

namespace MesterX.API.Controllers;

// ══════════════════════════════════════════════════════════════════════════════
// PRODUCTS CONTROLLER
// ══════════════════════════════════════════════════════════════════════════════

[ApiController]
[Route("api/products")]
[Authorize]
[Produces("application/json")]
public class ProductsController : ControllerBase
{
    private readonly IProductService _products;
    private readonly ICurrentUserService _currentUser;

    public ProductsController(IProductService products, ICurrentUserService currentUser)
    {
        _products    = products;
        _currentUser = currentUser;
    }

    private Guid TenantId => _currentUser.TenantId ?? throw new UnauthorizedAccessException();

    [HttpGet]
    public async Task<IActionResult> GetAll(
        [FromQuery] Guid? branchId, [FromQuery] Guid? categoryId,
        [FromQuery] string? search,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        var result = await _products.GetProductsAsync(
            TenantId, branchId, categoryId, search, page, pageSize, ct);
        return Ok(result);
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetOne(Guid id, CancellationToken ct)
    {
        var result = await _products.GetProductAsync(TenantId, id, ct);
        return Ok(result);
    }

    [HttpGet("barcode/{barcode}")]
    public async Task<IActionResult> GetByBarcode(string barcode, CancellationToken ct)
    {
        var result = await _products.GetByBarcodeAsync(TenantId, barcode, ct);
        return result is null ? NotFound(new { message = "لم يُعثر على منتج بهذا الباركود." }) : Ok(result);
    }

    [HttpPost]
    [Authorize(Policy = "Manager")]
    public async Task<IActionResult> Create([FromBody] CreateProductRequest req, CancellationToken ct)
    {
        var result = await _products.CreateProductAsync(TenantId, req, ct);
        return StatusCode(201, result);
    }

    [HttpPut("{id:guid}")]
    [Authorize(Policy = "Manager")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateProductRequest req, CancellationToken ct)
    {
        var result = await _products.UpdateProductAsync(TenantId, id, req, ct);
        return Ok(result);
    }

    [HttpDelete("{id:guid}")]
    [Authorize(Policy = "Manager")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        await _products.DeleteProductAsync(TenantId, id, ct);
        return Ok(new { message = "تم حذف المنتج." });
    }

    [HttpPut("{id:guid}/inventory")]
    [Authorize(Policy = "Manager")]
    public async Task<IActionResult> UpdateInventory(
        Guid id, [FromBody] UpdateInventoryRequest req, CancellationToken ct)
    {
        await _products.UpdateInventoryAsync(TenantId, id, req, ct);
        return Ok(new { message = "تم تحديث المخزون." });
    }

    [HttpGet("low-stock")]
    public async Task<IActionResult> LowStock(
        [FromQuery] Guid? branchId, CancellationToken ct)
    {
        var result = await _products.GetLowStockAsync(TenantId, branchId, ct);
        return Ok(result);
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// ORDERS CONTROLLER
// ══════════════════════════════════════════════════════════════════════════════

[ApiController]
[Route("api/orders")]
[Authorize]
[Produces("application/json")]
public class OrdersController : ControllerBase
{
    private readonly IOrderService _orders;
    private readonly ICurrentUserService _currentUser;

    public OrdersController(IOrderService orders, ICurrentUserService currentUser)
    {
        _orders      = orders;
        _currentUser = currentUser;
    }

    private Guid TenantId => _currentUser.TenantId ?? throw new UnauthorizedAccessException();
    private Guid UserId   => _currentUser.UserId   ?? throw new UnauthorizedAccessException();

    [HttpGet]
    public async Task<IActionResult> GetAll(
        [FromQuery] Guid? branchId, [FromQuery] OrderStatus? status,
        [FromQuery] DateTime? from,  [FromQuery] DateTime? to,
        [FromQuery] int page = 1,    [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        var result = await _orders.GetOrdersAsync(
            TenantId, branchId, status, from, to, page, pageSize, ct);
        return Ok(result);
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetOne(Guid id, CancellationToken ct)
    {
        var result = await _orders.GetOrderAsync(TenantId, id, ct);
        return Ok(result);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateOrderRequest req, CancellationToken ct)
    {
        var result = await _orders.CreateOrderAsync(TenantId, UserId, req, ct);
        return StatusCode(201, result);
    }

    [HttpPatch("{id:guid}/status")]
    [Authorize(Policy = "Manager")]
    public async Task<IActionResult> UpdateStatus(
        Guid id, [FromQuery] OrderStatus status,
        [FromQuery] string? reason, CancellationToken ct)
    {
        var result = await _orders.UpdateStatusAsync(TenantId, id, status, reason, ct);
        return Ok(result);
    }

    [HttpPatch("{id:guid}/discount")]
    [Authorize(Policy = "Manager")]
    public async Task<IActionResult> ApplyDiscount(
        Guid id, [FromQuery] decimal discount, CancellationToken ct)
    {
        var result = await _orders.ApplyDiscountAsync(TenantId, id, discount, ct);
        return Ok(result);
    }

    [HttpGet("summary/daily")]
    [Authorize(Policy = "Manager")]
    public async Task<IActionResult> DailySummary(
        [FromQuery] Guid branchId,
        [FromQuery] DateTime? date,
        CancellationToken ct)
    {
        var result = await _orders.GetDailySummaryAsync(TenantId, branchId, date ?? DateTime.UtcNow, ct);
        return Ok(result);
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// CUSTOMERS CONTROLLER
// ══════════════════════════════════════════════════════════════════════════════

[ApiController]
[Route("api/customers")]
[Authorize]
[Produces("application/json")]
public class CustomersController : ControllerBase
{
    private readonly ICustomerService _customers;
    private readonly ICurrentUserService _currentUser;

    public CustomersController(ICustomerService customers, ICurrentUserService currentUser)
    {
        _customers   = customers;
        _currentUser = currentUser;
    }

    private Guid TenantId => _currentUser.TenantId ?? throw new UnauthorizedAccessException();

    [HttpGet]
    public async Task<IActionResult> GetAll(
        [FromQuery] string? search,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        var result = await _customers.GetCustomersAsync(TenantId, search, page, pageSize, ct);
        return Ok(result);
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetOne(Guid id, CancellationToken ct)
    {
        var result = await _customers.GetCustomerAsync(TenantId, id, ct);
        return result is null ? NotFound(new { message = "العميل غير موجود." }) : Ok(result);
    }

    [HttpGet("by-phone/{phone}")]
    public async Task<IActionResult> FindByPhone(string phone, CancellationToken ct)
    {
        var result = await _customers.FindByPhoneAsync(TenantId, phone, ct);
        return result is null ? NotFound(new { message = "لم يُعثر على عميل بهذا الرقم." }) : Ok(result);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateCustomerRequest req, CancellationToken ct)
    {
        var result = await _customers.CreateCustomerAsync(TenantId, req, ct);
        return StatusCode(201, result);
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(
        Guid id, [FromBody] CreateCustomerRequest req, CancellationToken ct)
    {
        var result = await _customers.UpdateCustomerAsync(TenantId, id, req, ct);
        return Ok(result);
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// PLATFORM CONTROLLER  (PlatformOwner فقط)
// ══════════════════════════════════════════════════════════════════════════════

[ApiController]
[Route("api/platform")]
[Authorize(Policy = "PlatformOwner")]
[Produces("application/json")]
public class PlatformController : ControllerBase
{
    private readonly IPlatformService _platform;

    public PlatformController(IPlatformService platform) => _platform = platform;

    [HttpGet("stats")]
    public async Task<IActionResult> GetStats(CancellationToken ct)
    {
        var result = await _platform.GetStatsAsync(ct);
        return Ok(result);
    }

    [HttpGet("tenants")]
    public async Task<IActionResult> GetTenants(
        [FromQuery] string? search, [FromQuery] PlanType? plan,
        [FromQuery] bool? isActive,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        var result = await _platform.GetTenantsAsync(search, plan, isActive, page, pageSize, ct);
        return Ok(result);
    }

    [HttpGet("tenants/{id:guid}")]
    public async Task<IActionResult> GetTenant(Guid id, CancellationToken ct)
    {
        var result = await _platform.GetTenantAsync(id, ct);
        return Ok(result);
    }

    [HttpPost("tenants/{id:guid}/suspend")]
    public async Task<IActionResult> Suspend(
        Guid id, [FromQuery] string reason, CancellationToken ct)
    {
        await _platform.SuspendTenantAsync(id, reason, ct);
        return Ok(new { message = "تم تعليق الشركة." });
    }

    [HttpPost("tenants/{id:guid}/activate")]
    public async Task<IActionResult> Activate(Guid id, CancellationToken ct)
    {
        await _platform.ActivateTenantAsync(id, ct);
        return Ok(new { message = "تم تفعيل الشركة." });
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// SUBSCRIPTION CONTROLLER
// ══════════════════════════════════════════════════════════════════════════════

[ApiController]
[Route("api/subscription")]
[Authorize]
[Produces("application/json")]
public class SubscriptionController : ControllerBase
{
    private readonly ISubscriptionService _subscriptions;
    private readonly ICurrentUserService _currentUser;

    public SubscriptionController(ISubscriptionService subscriptions, ICurrentUserService currentUser)
    {
        _subscriptions = subscriptions;
        _currentUser   = currentUser;
    }

    private Guid TenantId => _currentUser.TenantId ?? throw new UnauthorizedAccessException();

    [HttpGet]
    public async Task<IActionResult> GetActive(CancellationToken ct)
    {
        var result = await _subscriptions.GetActiveAsync(TenantId, ct);
        return Ok(result);
    }

    [HttpGet("plans")]
    [AllowAnonymous]
    public async Task<IActionResult> GetPlans(CancellationToken ct)
    {
        var result = await _subscriptions.GetPlansAsync(ct);
        return Ok(result);
    }

    [HttpPost("upgrade")]
    [Authorize(Policy = "CompanyOwner")]
    public async Task<IActionResult> Upgrade(
        [FromQuery] Guid planId,
        [FromQuery] BillingCycle cycle,
        CancellationToken ct)
    {
        var result = await _subscriptions.UpgradeAsync(TenantId, planId, cycle, ct);
        return Ok(result);
    }

    [HttpPost("cancel")]
    [Authorize(Policy = "CompanyOwner")]
    public async Task<IActionResult> Cancel(
        [FromQuery] string reason, CancellationToken ct)
    {
        await _subscriptions.CancelAsync(TenantId, reason, ct);
        return Ok(new { message = "تم إلغاء الاشتراك بنجاح." });
    }
}
