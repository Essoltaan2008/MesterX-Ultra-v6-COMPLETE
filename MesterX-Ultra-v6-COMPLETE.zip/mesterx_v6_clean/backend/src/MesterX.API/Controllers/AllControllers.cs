using System.Security.Claims;
using MesterX.Application.DTOs;
using MesterX.Application.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MesterX.API.Controllers;

// ─────────────────────────────────────────────
// BASE CONTROLLER
// ─────────────────────────────────────────────
[ApiController]
[Produces("application/json")]
public abstract class BaseController : ControllerBase
{
    protected string IpAddress => HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
    protected string UserAgent => Request.Headers.UserAgent.ToString();
}

// ─────────────────────────────────────────────
// AUTH CONTROLLER
// ─────────────────────────────────────────────
[Route("api/auth")]
public class AuthController : BaseController
{
    private readonly IAuthService _auth;
    public AuthController(IAuthService auth) => _auth = auth;

    [HttpPost("register")]
    [AllowAnonymous]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
        var result = await _auth.RegisterAsync(request);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var result = await _auth.LoginAsync(request, IpAddress, UserAgent);
        return result.Success ? Ok(result) : Unauthorized(result);
    }

    [HttpPost("refresh")]
    [AllowAnonymous]
    public async Task<IActionResult> Refresh([FromBody] RefreshTokenRequest request)
    {
        var result = await _auth.RefreshTokenAsync(request.RefreshToken, IpAddress);
        return result.Success ? Ok(result) : Unauthorized(result);
    }

    [HttpPost("logout")]
    [Authorize]
    public async Task<IActionResult> Logout([FromBody] RefreshTokenRequest request)
    {
        var result = await _auth.LogoutAsync(request.RefreshToken);
        return Ok(result);
    }

    [HttpGet("me")]
    [Authorize]
    public async Task<IActionResult> Me()
    {
        var result = await _auth.GetCurrentUserAsync();
        return result.Success ? Ok(result) : NotFound(result);
    }

    [HttpPost("change-password")]
    [Authorize]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest request)
    {
        var result = await _auth.ChangePasswordAsync(request);
        return result.Success ? Ok(result) : BadRequest(result);
    }
}

// ─────────────────────────────────────────────
// LICENSE CONTROLLER
// ─────────────────────────────────────────────
[Route("api/license")]
[Authorize]
public class LicenseController : BaseController
{
    private readonly ILicenseService _license;
    public LicenseController(ILicenseService license) => _license = license;

    [HttpGet("status")]
    public async Task<IActionResult> GetStatus()
    {
        var result = await _license.GetStatusAsync();
        return result.Success ? Ok(result) : NotFound(result);
    }

    [HttpGet("plans")]
    [AllowAnonymous]
    public async Task<IActionResult> GetPlans()
    {
        var result = await _license.GetPlansAsync();
        return Ok(result);
    }

    [HttpPost("activate")]
    public async Task<IActionResult> Activate([FromBody] ActivateLicenseRequest request)
    {
        var result = await _license.ActivateAsync(request);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [HttpPost("activate-sync")]
    public async Task<IActionResult> ActivateSync([FromBody] ActivateSyncAddonRequest request)
    {
        var result = await _license.ActivateSyncAddonAsync(request);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [HttpPost("validate-device")]
    public async Task<IActionResult> ValidateDevice([FromBody] ValidateDeviceRequest request)
    {
        var result = await _license.ValidateDeviceAsync(request);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [HttpPost("enforce")]
    public async Task<IActionResult> Enforce()
    {
        var result = await _license.EnforceLicenseAsync();
        return result.Success ? Ok(result) : BadRequest(result);
    }
}

// ─────────────────────────────────────────────
// SYNC CONTROLLER
// ─────────────────────────────────────────────
[Route("api/sync")]
[Authorize]
public class SyncController : BaseController
{
    private readonly ISyncService _sync;
    private readonly ITenantProvider _tenant;
    public SyncController(ISyncService sync, ITenantProvider tenant)
    {
        _sync = sync;
        _tenant = tenant;
    }

    [HttpPost("push")]
    public async Task<IActionResult> Push([FromBody] SyncPushRequest request)
    {
        var tenantId = _tenant.TenantId ?? throw new UnauthorizedAccessException();
        var userId = _tenant.CurrentUserId ?? throw new UnauthorizedAccessException();
        var result = await _sync.PushAsync(tenantId, userId, request);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [HttpGet("pull")]
    public async Task<IActionResult> Pull(
        [FromQuery] Guid branchId,
        [FromQuery] DateTime? lastSyncedAt)
    {
        var tenantId = _tenant.TenantId ?? throw new UnauthorizedAccessException();
        var since = lastSyncedAt ?? DateTime.UtcNow.AddDays(-7);
        var result = await _sync.PullAsync(tenantId, branchId, since);
        return result.Success ? Ok(result) : BadRequest(result);
    }
}

// ─────────────────────────────────────────────
// POS CONTROLLER
// ─────────────────────────────────────────────
[Route("api/pos")]
[Authorize]
public class PosController : BaseController
{
    private readonly IPosService _pos;
    public PosController(IPosService pos) => _pos = pos;

    [HttpGet("products")]
    public async Task<IActionResult> GetProducts(
        [FromQuery] Guid branchId,
        [FromQuery] string? search)
    {
        var result = await _pos.GetProductsAsync(branchId, search);
        return Ok(result);
    }

    [HttpPost("sale")]
    public async Task<IActionResult> CreateSale([FromBody] CreateSaleRequest request)
    {
        var result = await _pos.CreateSaleAsync(request);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [HttpGet("sales")]
    public async Task<IActionResult> GetSales(
        [FromQuery] Guid branchId,
        [FromQuery] DateTime? fromDate,
        [FromQuery] DateTime? toDate)
    {
        var result = await _pos.GetSalesAsync(branchId, fromDate, toDate);
        return Ok(result);
    }

    [HttpGet("sales/{id:guid}")]
    public async Task<IActionResult> GetSaleById(Guid id)
    {
        var result = await _pos.GetSaleByIdAsync(id);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [HttpPost("sales/{id:guid}/refund")]
    public async Task<IActionResult> Refund(Guid id, [FromBody] RefundRequest request)
    {
        var result = await _pos.RefundSaleAsync(id, request);
        return result.Success ? Ok(result) : BadRequest(result);
    }
}

// ─────────────────────────────────────────────
// INVENTORY CONTROLLER
// ─────────────────────────────────────────────
[Route("api/inventory")]
[Authorize]
public class InventoryController : BaseController
{
    private readonly IInventoryService _inventory;
    public InventoryController(IInventoryService inventory) => _inventory = inventory;

    [HttpGet("products")]
    public async Task<IActionResult> GetProducts(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50,
        [FromQuery] string? search = null,
        [FromQuery] Guid? categoryId = null)
    {
        var result = await _inventory.GetProductsAsync(page, pageSize, search, categoryId);
        return Ok(result);
    }

    [HttpGet("barcode/{barcode}")]
    public async Task<IActionResult> GetByBarcode(string barcode)
    {
        var result = await _inventory.GetProductByBarcodeAsync(barcode);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [HttpPost("products")]
    public async Task<IActionResult> CreateProduct([FromBody] CreateProductRequest request)
    {
        var result = await _inventory.CreateProductAsync(request);
        return result.Success ? CreatedAtAction(nameof(GetProducts), result) : BadRequest(result);
    }

    [HttpPut("products/{id:guid}")]
    public async Task<IActionResult> UpdateProduct(Guid id, [FromBody] UpdateProductRequest request)
    {
        var result = await _inventory.UpdateProductAsync(id, request);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [HttpDelete("products/{id:guid}")]
    public async Task<IActionResult> DeleteProduct(Guid id)
    {
        var result = await _inventory.DeleteProductAsync(id);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [HttpGet("stock")]
    public async Task<IActionResult> GetStock(
        [FromQuery] Guid? branchId,
        [FromQuery] bool lowStockOnly = false)
    {
        var result = await _inventory.GetStockAsync(branchId, lowStockOnly);
        return Ok(result);
    }

    [HttpPost("stock/adjust")]
    public async Task<IActionResult> AdjustStock([FromBody] StockAdjustRequest request)
    {
        var result = await _inventory.AdjustStockAsync(request);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [HttpPost("stock/set")]
    public async Task<IActionResult> SetStock([FromBody] StockSetRequest request)
    {
        var result = await _inventory.SetStockAsync(request);
        return result.Success ? Ok(result) : BadRequest(result);
    }
}

// ─────────────────────────────────────────────
// DASHBOARD CONTROLLER
// ─────────────────────────────────────────────
[Route("api/dashboard")]
[Authorize]
public class DashboardController : BaseController
{
    private readonly IReportingService _reporting;
    public DashboardController(IReportingService reporting) => _reporting = reporting;

    [HttpGet]
    public async Task<IActionResult> GetDashboard([FromQuery] Guid? branchId)
    {
        var result = await _reporting.GetDashboardAsync(branchId);
        return Ok(result);
    }

    [HttpGet("sales-report")]
    public async Task<IActionResult> GetSalesReport(
        [FromQuery] DateTime? fromDate,
        [FromQuery] DateTime? toDate,
        [FromQuery] Guid? branchId)
    {
        var from = fromDate ?? DateTime.UtcNow.Date.AddDays(-30);
        var to = toDate ?? DateTime.UtcNow.Date.AddDays(1);
        var result = await _reporting.GetSalesReportAsync(branchId, from, to);
        return result.Success ? Ok(result) : BadRequest(result);
    }
}
