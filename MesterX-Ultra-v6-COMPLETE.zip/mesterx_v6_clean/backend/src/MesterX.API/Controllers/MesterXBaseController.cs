using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;

namespace MesterX.API.Controllers;

public abstract class MesterXBaseController : ControllerBase
{
    protected Guid CurrentTenantId =>
        Guid.Parse(User.FindFirstValue("tenant_id")!);

    protected Guid CurrentUserId =>
        Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    protected bool IsManager =>
        User.IsInRole("Manager");

    protected bool IsOwner =>
        User.IsInRole("Owner");

    protected bool IsPlatformOwner =>
        User.IsInRole("PlatformOwner");
}
