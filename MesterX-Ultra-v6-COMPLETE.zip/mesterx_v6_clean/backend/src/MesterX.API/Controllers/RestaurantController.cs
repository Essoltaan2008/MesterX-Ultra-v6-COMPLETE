using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MesterX.Application.Services;
using MesterX.Application.DTOs;
// using MesterX.Domain.Entities;
using MesterX.Domain.Entities.Restaurant;


namespace MesterX.API.Controllers;

[Authorize]
[ApiController]
[Route("api/restaurant")]
public class RestaurantController : BaseController
{
    private readonly IRestaurantService _svc;
    public RestaurantController(IRestaurantService svc) => _svc = svc;

    private Guid TenantId    => Guid.Parse(User.FindFirstValue("tenant_id")!);
    private Guid UserId      => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private Guid BranchIdClaim => Guid.Parse(User.FindFirstValue("branch_id") ?? Guid.Empty.ToString());

    private IActionResult R<T>(RestResult<T> r) => r.Success ? Ok(r.Data)
        : r.Code switch {
            "NOT_FOUND"  => NotFound(new  { error = r.Message }),
            "INVALID_QR" => BadRequest(new { error = r.Message }),
            "NO_SESSION" => NotFound(new  { error = r.Message }),
            _            => BadRequest(new { error = r.Message, code = r.Code })
        };

    // ── Module Status ──────────────────────────────────────────────────────
    [HttpGet("status")]
    public async Task<IActionResult> GetStatus(CancellationToken ct)
        => Ok(new { restaurantModuleEnabled = await _svc.IsModuleEnabledAsync(TenantId, ct) });

    // ── Menu ───────────────────────────────────────────────────────────────
    [HttpGet("menu/categories")]
    public async Task<IActionResult> GetCategories(CancellationToken ct)
        => R(await _svc.GetCategoriesAsync(TenantId, ct));

    [HttpGet("menu/items")]
    public async Task<IActionResult> GetMenu(
        [FromQuery] Guid? branchId, [FromQuery] Guid? categoryId, CancellationToken ct)
        => R(await _svc.GetBranchMenuAsync(TenantId, branchId ?? BranchIdClaim, categoryId, ct));

    [HttpPost("menu/items/{itemId:guid}/86")]
    public async Task<IActionResult> Set86(Guid itemId,
        [FromBody] Set86Req req, [FromQuery] Guid? branchId, CancellationToken ct)
        => R(await _svc.Set86Async(TenantId, branchId ?? BranchIdClaim, itemId, req.Status, req.Reason, UserId, ct));

    // ── Floor Plans ────────────────────────────────────────────────────────
    [HttpGet("floor-plans")]
    public async Task<IActionResult> GetFloorPlans(
        [FromQuery] Guid? branchId, CancellationToken ct)
        => R(await _svc.GetFloorPlansAsync(TenantId, branchId ?? BranchIdClaim, ct));

    // ── Sessions ───────────────────────────────────────────────────────────
    [HttpPost("sessions")]
    public async Task<IActionResult> OpenSession(
        [FromBody] OpenSessionReq req, CancellationToken ct)
        => R(await _svc.OpenSessionAsync(TenantId, req with { UserId = UserId }, ct));

    [HttpGet("tables/{tableId:guid}/session")]
    public async Task<IActionResult> GetSession(Guid tableId, CancellationToken ct)
        => R(await _svc.GetActiveSessionAsync(TenantId, tableId, ct));

    [HttpPost("sessions/close")]
    public async Task<IActionResult> CloseSession(
        [FromBody] CloseSessionReq req, CancellationToken ct)
        => R(await _svc.CloseSessionAsync(TenantId, req with { UserId = UserId }, ct));

    // ── Orders ─────────────────────────────────────────────────────────────
    [HttpGet("orders/active")]
    public async Task<IActionResult> GetActiveOrders(
        [FromQuery] Guid? branchId, CancellationToken ct)
        => R(await _svc.GetActiveOrdersAsync(TenantId, branchId ?? BranchIdClaim, ct));

    [HttpPost("orders")]
    public async Task<IActionResult> CreateOrder(
        [FromBody] CreateOrderReq req, CancellationToken ct)
        => R(await _svc.CreateOrderAsync(TenantId, req with { WaiterId = UserId }, ct));

    [AllowAnonymous]
    [HttpPost("orders/qr")]
    public async Task<IActionResult> CreateQROrder(
        [FromBody] QRCreateOrderReq req, CancellationToken ct)
        => R(await _svc.CreateQROrderAsync(req, ct));

    [HttpPost("orders/{id:guid}/confirm")]
    public async Task<IActionResult> ConfirmQR(Guid id, CancellationToken ct)
        => R(await _svc.ConfirmQROrderAsync(TenantId, id, UserId, ct));

    [HttpPost("orders/{id:guid}/send-to-kitchen")]
    public async Task<IActionResult> SendToKitchen(Guid id, CancellationToken ct)
        => R(await _svc.SendToKitchenAsync(TenantId, id, UserId, ct));

    [HttpPost("orders/{id:guid}/deliver")]
    public async Task<IActionResult> Deliver(Guid id, CancellationToken ct)
        => R(await _svc.DeliverOrderAsync(TenantId, id, UserId, ct));

    [HttpPost("orders/{id:guid}/cancel")]
    public async Task<IActionResult> Cancel(
        Guid id, [FromBody] CancelReq req, CancellationToken ct)
        => R(await _svc.CancelOrderAsync(TenantId, id, UserId, req.Reason, ct));

    // ── Kitchen ────────────────────────────────────────────────────────────
    [HttpGet("kitchen/stations")]
    public async Task<IActionResult> GetStations(
        [FromQuery] Guid? branchId, CancellationToken ct)
        => R(await _svc.GetStationsAsync(TenantId, branchId ?? BranchIdClaim, ct));

    [HttpGet("kitchen/stations/{stationId:guid}/tickets")]
    public async Task<IActionResult> GetTickets(Guid stationId, CancellationToken ct)
        => R(await _svc.GetActiveTicketsAsync(TenantId, stationId, ct));

    [HttpPatch("kitchen/tickets/{ticketId:guid}/status")]
    public async Task<IActionResult> UpdateTicket(
        Guid ticketId, [FromBody] UpdateTicketReq req, CancellationToken ct)
        => R(await _svc.UpdateTicketStatusAsync(TenantId, ticketId, req.Status, ct));
}

public record Set86Req(MenuItemAvailability Status, string? Reason);
public record CancelReq(string Reason);
public record UpdateTicketReq(KitchenTicketStatus Status);
