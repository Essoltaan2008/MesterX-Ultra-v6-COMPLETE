using MesterX.API.Hubs;
using MesterX.Application.Common.Interfaces;
using MesterX.Application.Services;
using MesterX.Domain.Interfaces;
using MesterX.Infrastructure.BackgroundJobs;
using MesterX.Infrastructure.Data;
using MesterX.Infrastructure.Extensions;
using MesterX.Infrastructure.Repositories;
using MesterX.Infrastructure.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using Serilog.Events;
using System.Text;
using System.Threading.RateLimiting;

// ─── SERILOG BOOTSTRAP ────────────────────────────────────────────────────────
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
    .MinimumLevel.Override("System", LogEventLevel.Warning)
    .Enrich.FromLogContext()
    .Enrich.WithMachineName()
    .WriteTo.Console(outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] {SourceContext}: {Message:lj}{NewLine}{Exception}")
    .WriteTo.File("logs/mesterx-.log", rollingInterval: RollingInterval.Day, retainedFileCountLimit: 30)
    .CreateLogger();

var builder = WebApplication.CreateBuilder(args);
builder.Host.UseSerilog();

var config = builder.Configuration;

// ─── DATABASE ─────────────────────────────────────────────────────────────────
builder.Services.AddDbContext<MesterXDbContext>(opt =>
{
    opt.UseNpgsql(config.GetConnectionString("DefaultConnection")!, pg =>
    {
        pg.EnableRetryOnFailure(3);
        pg.CommandTimeout(30);
        pg.MigrationsAssembly("MesterX.Infrastructure");
    });
    if (builder.Environment.IsDevelopment())
        opt.EnableSensitiveDataLogging().EnableDetailedErrors();
});

// ─── HTTP CONTEXT ─────────────────────────────────────────────────────────────
builder.Services.AddHttpContextAccessor();

// ─── INFRASTRUCTURE SERVICES ──────────────────────────────────────────────────
builder.Services.AddScoped<IUnitOfWork,          UnitOfWork>();
builder.Services.AddScoped<ICurrentUserService,  CurrentUserService>();
builder.Services.AddScoped<IDateTimeService,     DateTimeService>();
builder.Services.AddScoped<IAuditService,        AuditService>();         // ✅ Real DB write
builder.Services.AddScoped<TenantRLSInterceptor>();
builder.Services.AddScoped<ITenantProvider,      TenantProvider>();
builder.Services.AddSingleton<IFeatureFlagService, FeatureFlagService>();
builder.Services.AddScoped<IRolePermissionService, RolePermissionService>();

// ─── APPLICATION SERVICES ─────────────────────────────────────────────────────
builder.Services.AddScoped<IAuthService,         AuthService>();
builder.Services.AddScoped<ILicenseService,      LicenseService>();
builder.Services.AddScoped<ISyncService,         SyncService>();
builder.Services.AddScoped<IPosService,          PosService>();
builder.Services.AddScoped<IInventoryService,    InventoryService>();
builder.Services.AddScoped<IReportingService,    ReportingService>();

// ─── MARKETPLACE SERVICES ─────────────────────────────────────────────────────
builder.Services.AddScoped<IVendorService,       VendorAppService>();
builder.Services.AddScoped<IBookingService,      BookingAppService>();

// ─── RENTAL MODULE ────────────────────────────────────────────────────────────
builder.Services.AddScoped<IRentalUnitOfWork,    RentalUnitOfWork>();
builder.Services.AddScoped<IRentalAssetService,  RentalAssetService>();
builder.Services.AddScoped<IRentalBookingService, RentalBookingService>();
builder.Services.AddScoped<IRentalModuleService, RentalModuleService>();

// ─── RESTAURANT MODULE ────────────────────────────────────────────────────────
builder.Services.AddScoped<IRestaurantUnitOfWork, RestaurantUnitOfWork>();
builder.Services.AddScoped<IRestaurantService,    RestaurantService>();
builder.Services.AddScoped<IRestaurantNotifier,   SignalRRestaurantNotifier>();

// ─── BUSINESS SERVICES (Products, Orders, Customers, Delivery, Platform) ──────
builder.Services.AddBusinessServices();

// ─── BACKGROUND JOBS ──────────────────────────────────────────────────────────
builder.Services.AddHostedService<LicenseEnforcementJob>();

// ─── SIGNALR ──────────────────────────────────────────────────────────────────
builder.Services.AddSignalR(opt =>
{
    opt.EnableDetailedErrors  = builder.Environment.IsDevelopment();
    opt.MaximumReceiveMessageSize = 32 * 1024;
});

// ─── JWT AUTHENTICATION ───────────────────────────────────────────────────────
var jwtSection = config.GetSection("Jwt");
var jwtSecret  = jwtSection["Secret"] ?? throw new InvalidOperationException("JWT Secret not configured.");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(opt =>
    {
        opt.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer           = true,
            ValidateAudience         = true,
            ValidateLifetime         = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer              = jwtSection["Issuer"],
            ValidAudience            = jwtSection["Audience"],
            IssuerSigningKey         = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecret)),
            ClockSkew                = TimeSpan.FromSeconds(30)
        };
        opt.Events = new JwtBearerEvents
        {
            OnChallenge = ctx =>
            {
                ctx.HandleResponse();
                ctx.Response.StatusCode   = 401;
                ctx.Response.ContentType  = "application/json";
                return ctx.Response.WriteAsJsonAsync(new { success = false, message = "Unauthorized" });
            }
        };
    });

builder.Services.AddAuthorization();

// ─── RATE LIMITING ────────────────────────────────────────────────────────────
builder.Services.AddRateLimiter(opt =>
{
    opt.AddFixedWindowLimiter("auth", o => { o.PermitLimit = 10;  o.Window = TimeSpan.FromMinutes(1); o.QueueLimit = 0; });
    opt.AddFixedWindowLimiter("api",  o => { o.PermitLimit = 300; o.Window = TimeSpan.FromMinutes(1); o.QueueLimit = 0; });
    opt.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
});

// ─── CORS ─────────────────────────────────────────────────────────────────────
builder.Services.AddCors(opt => opt.AddPolicy("MesterXPolicy", policy =>
    policy.WithOrigins(config.GetSection("AllowedOrigins").Get<string[]>() ?? ["http://localhost:3000"])
          .AllowAnyHeader().AllowAnyMethod().AllowCredentials()));

// ─── CONTROLLERS ──────────────────────────────────────────────────────────────
builder.Services.AddControllers()
    .AddJsonOptions(opt =>
    {
        opt.JsonSerializerOptions.PropertyNamingPolicy        = System.Text.Json.JsonNamingPolicy.CamelCase;
        opt.JsonSerializerOptions.DefaultIgnoreCondition      = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
        opt.JsonSerializerOptions.Converters.Add(new System.Text.Json.Serialization.JsonStringEnumConverter());
    });

// ─── SWAGGER ──────────────────────────────────────────────────────────────────
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v6", new OpenApiInfo
    {
        Title       = "MesterX Ultra Enterprise v6 API",
        Version     = "v6",
        Description = "Hybrid Offline-First + Cloud Sync · Multi-Tenant · تقنية مصرية 🇪🇬"
    });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Type         = SecuritySchemeType.Http,
        Scheme       = "bearer",
        BearerFormat = "JWT",
        In           = ParameterLocation.Header,
        Description  = "Enter your JWT token"
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } },
            Array.Empty<string>()
        }
    });
});

// ─── HEALTH CHECKS ────────────────────────────────────────────────────────────
builder.Services.AddHealthChecks()
    .AddNpgSql(config.GetConnectionString("DefaultConnection")!);

// ─── RESPONSE COMPRESSION ─────────────────────────────────────────────────────
builder.Services.AddResponseCompression(opt => opt.EnableForHttps = true);

// ═════════════════════════════════════════════════════════════════════════════
// BUILD
// ═════════════════════════════════════════════════════════════════════════════
var app = builder.Build();

// ─── AUTO MIGRATE ─────────────────────────────────────────────────────────────
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<MesterXDbContext>();
    try   { db.Database.Migrate(); Log.Information("✅ DB migrations applied."); }
    catch (Exception ex) { Log.Error(ex, "❌ DB migration failed."); }
}

// ─── MIDDLEWARE PIPELINE ──────────────────────────────────────────────────────
app.UseResponseCompression();
app.UseSerilogRequestLogging();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v6/swagger.json", "MesterX v6");
        c.RoutePrefix = "swagger";
        c.DocumentTitle = "MesterX API v6";
    });
}
else
{
    app.UseHsts();
}

// ─── SECURITY HEADERS ─────────────────────────────────────────────────────────
app.Use(async (ctx, next) =>
{
    ctx.Response.Headers["X-Content-Type-Options"]  = "nosniff";
    ctx.Response.Headers["X-Frame-Options"]         = "DENY";
    ctx.Response.Headers["X-XSS-Protection"]        = "1; mode=block";
    ctx.Response.Headers["Referrer-Policy"]         = "strict-origin-when-cross-origin";
    ctx.Response.Headers["Permissions-Policy"]      = "geolocation=(), microphone=(), camera=()";
    await next();
});

// ─── GLOBAL EXCEPTION HANDLER ─────────────────────────────────────────────────
app.UseExceptionHandler(errApp => errApp.Run(async ctx =>
{
    ctx.Response.StatusCode  = 500;
    ctx.Response.ContentType = "application/json";
    await ctx.Response.WriteAsJsonAsync(new { success = false, message = "خطأ داخلي في السيرفر. حاول مرة تانية." });
}));

app.UseHttpsRedirection();
app.UseCors("MesterXPolicy");
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();

// ─── ROUTES ───────────────────────────────────────────────────────────────────
app.MapControllers().RequireRateLimiting("api");
app.MapHealthChecks("/health");
app.MapHub<RestaurantHub>("/hubs/restaurant");

Log.Information("🚀 MesterX Ultra Enterprise v6 — بدأ على {Env}", app.Environment.EnvironmentName);
app.Run();
