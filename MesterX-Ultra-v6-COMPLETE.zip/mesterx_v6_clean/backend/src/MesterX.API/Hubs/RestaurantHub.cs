using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using MesterX.Domain.Entities;
using MesterX.Domain.Interfaces;

namespace MesterX.API.Hubs;

// ═══════════════════════════════════════════════════════════════════════════
// RESTAURANT SIGNALR HUB
// ─────────────────────────────────────────────────────────────────────────
// SignalR Groups:
//   branch-{tenantId}-{branchId}          ← موظفو الفرع (ويتر / كاشير)
//   kitchen-{tenantId}-{branchId}-{stId}  ← شاشة محطة مطبخ
//   floor-{tenantId}-{branchId}           ← Floor Plan (host / manager)
//   table-{tableId}                       ← العميل على QR
//
// Server → Client events:
//   QROrderPendingConfirm  → الويتر يشوف أوردر جديد محتاج تأكيد
//   OrderReady             → الأوردر جاهز للتسليم
//   OrderCancelled         → أوردر اتلغى
//   NewTicket              → تذكرة مطبخ جديدة
//   TicketUpdated          → حالة التذكرة اتغيرت
//   TableStatusChanged     → حالة الطاولة اتغيرت (Floor Plan)
//   BillRequested          → عميل طلب الحساب
//
// Client → Server methods:
//   JoinBranch(tenantId, branchId)
//   JoinKitchenStation(tenantId, branchId, stationId)
//   JoinTable(tableId, qrToken)
//   RequestBill(tableId, qrToken)
// ═══════════════════════════════════════════════════════════════════════════

[Authorize]
public class RestaurantHub : Hub
{
    private readonly IRestaurantUnitOfWork _uow;
    public RestaurantHub(IRestaurantUnitOfWork uow)
    { _uow = uow; }

    // ── Join Groups ───────────────────────────────────────────────────────

    public async Task JoinBranch(Guid tenantId, Guid branchId)
    {
        await Groups.AddToGroupAsync(Context.ConnectionId, $"branch-{tenantId}-{branchId}");
        await Groups.AddToGroupAsync(Context.ConnectionId, $"floor-{tenantId}-{branchId}");
        await Clients.Caller.SendAsync("Joined", new { scope = "branch", tenantId, branchId });
    }

    public async Task JoinKitchenStation(Guid tenantId, Guid branchId, Guid stationId)
    {
        var station = await _uow.Stations.FirstOrDefaultAsync(
            s => s.TenantId == tenantId && s.Id == stationId, default);
        if (station is null)
        {
            await Clients.Caller.SendAsync("Error", "Station not found");
            return;
        }

        await Groups.AddToGroupAsync(Context.ConnectionId, station.SignalRGroup);

        // إرسال التذاكر الـ Active فوراً عند فتح الشاشة
        var active = await _uow.Tickets.Query()
            .Include(t => t.Items)
            .Include(t => t.Order)
            .Where(t => t.TenantId == tenantId
                && t.KitchenStationId == stationId
                && t.Status < KitchenTicketStatus.Done)
            .OrderBy(t => t.CreatedAtKitchen)
            .ToListAsync();

        await Clients.Caller.SendAsync("ActiveTickets", active.Select(t => new
        {
            ticketId    = t.Id,
            ticketNumber = t.TicketNumber,
            tableNumber  = t.TableNumber,
            status       = t.Status.ToString(),
            orderSource  = t.Order.OrderSource.ToString(),
            createdAt    = t.CreatedAtKitchen,
            waitSecs     = (int)(DateTime.UtcNow - t.CreatedAtKitchen).TotalSeconds,
            items        = t.Items.Select(i => new
            {
                i.ItemName, i.Quantity, i.Modifiers, i.SpecialInstructions
            })
        }));
    }

    [AllowAnonymous]
    public async Task JoinTable(Guid tableId, string qrToken)
    {
        var table = await _uow.Tables.FirstOrDefaultAsync(
            t => t.Id == tableId && t.QrToken == qrToken && t.IsActive, default);
        if (table is null)
        {
            await Clients.Caller.SendAsync("InvalidQR");
            return;
        }
        await Groups.AddToGroupAsync(Context.ConnectionId, $"table-{tableId}");
        await Clients.Caller.SendAsync("JoinedTable", new
        {
            tableId, tableNumber = table.TableNumber
        });
    }

    // ── Bill Request (من العميل على QR) ──────────────────────────────────

    [AllowAnonymous]
    public async Task RequestBill(Guid tableId, string qrToken)
    {
        var table = await _uow.Tables.FirstOrDefaultAsync(
            t => t.Id == tableId && t.QrToken == qrToken, default);
        if (table is null) return;

        var session = await _uow.Sessions.FirstOrDefaultAsync(
            s => s.TableId == tableId && s.Status == SessionStatus.Active, default);
        if (session is null) return;

        session.BillRequestedAt = DateTime.UtcNow;
        session.Status          = SessionStatus.BillSent;
        _uow.Sessions.Update(session);
        await _uow.SaveChangesAsync(default);

        // بلّغ موظفو الفرع
        await Clients.Group($"branch-{table.TenantId}-{table.BranchId}")
            .SendAsync("BillRequested", new
            {
                tableId,
                tableNumber = table.TableNumber,
                sessionId   = session.Id,
                totalAmount = session.TotalAmount,
                requestedAt = session.BillRequestedAt
            });
    }
}
