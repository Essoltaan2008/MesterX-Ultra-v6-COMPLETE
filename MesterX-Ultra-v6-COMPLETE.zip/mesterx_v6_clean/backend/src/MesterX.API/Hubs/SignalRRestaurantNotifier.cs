using Microsoft.AspNetCore.SignalR;
using MesterX.Application.Services;

namespace MesterX.API.Hubs;

// ═══════════════════════════════════════════════════════════════════════════
// SignalRRestaurantNotifier
// Implementation of IRestaurantNotifier using IHubContext<RestaurantHub>
// مسجّل في Program.cs:
//   builder.Services.AddScoped<IRestaurantNotifier, SignalRRestaurantNotifier>();
// ═══════════════════════════════════════════════════════════════════════════

public class SignalRRestaurantNotifier : IRestaurantNotifier
{
    private readonly IHubContext<RestaurantHub> _hub;
    public SignalRRestaurantNotifier(IHubContext<RestaurantHub> hub) => _hub = hub;

    public Task TableStatusChangedAsync(Guid tenantId, Guid branchId,
        Guid tableId, string tableNumber, string status, CancellationToken ct = default)
        => _hub.Clients
            .Group($"floor-{tenantId}-{branchId}")
            .SendAsync("TableStatusChanged", new {
                tableId, tableNumber, status, updatedAt = DateTime.UtcNow
            }, ct);

    public Task QROrderPendingAsync(Guid tenantId, Guid branchId,
        Guid orderId, string orderNumber, string tableNumber,
        string? guestName, int itemCount, decimal total, CancellationToken ct = default)
        => _hub.Clients
            .Group($"branch-{tenantId}-{branchId}")
            .SendAsync("QROrderPendingConfirm", new {
                orderId, orderNumber, tableNumber, guestName, itemCount, total
            }, ct);

    public Task OrderReadyAsync(Guid tenantId, Guid branchId,
        Guid orderId, string orderNumber, string tableNumber, CancellationToken ct = default)
        => _hub.Clients
            .Group($"branch-{tenantId}-{branchId}")
            .SendAsync("OrderReady", new { orderId, orderNumber, tableNumber }, ct);

    public Task OrderCancelledAsync(Guid tenantId, Guid branchId,
        Guid orderId, string reason, CancellationToken ct = default)
        => _hub.Clients
            .Group($"branch-{tenantId}-{branchId}")
            .SendAsync("OrderCancelled", new { orderId, reason }, ct);

    public Task NewTicketAsync(Guid tenantId, Guid branchId,
        Guid stationId, string signalRGroup, object ticketPayload, CancellationToken ct = default)
        => _hub.Clients
            .Group(signalRGroup)
            .SendAsync("NewTicket", ticketPayload, ct);

    public Task TicketUpdatedAsync(string signalRGroup,
        Guid ticketId, string status, CancellationToken ct = default)
        => _hub.Clients
            .Group(signalRGroup)
            .SendAsync("TicketUpdated", new {
                ticketId, status, updatedAt = DateTime.UtcNow
            }, ct);

    public Task BillConfirmedAsync(Guid tableId, CancellationToken ct = default)
        => _hub.Clients
            .Group($"table-{tableId}")
            .SendAsync("BillConfirmed", new { tableId, confirmedAt = DateTime.UtcNow }, ct);
}
