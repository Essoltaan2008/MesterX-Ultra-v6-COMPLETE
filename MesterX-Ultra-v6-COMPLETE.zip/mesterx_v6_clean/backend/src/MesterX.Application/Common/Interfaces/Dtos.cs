using MesterX.Domain.Enums;

namespace MesterX.Application.Common.Interfaces;

// ══════════════════════════════════════════════════════════════════════════════
// PRODUCT DTOs
// ══════════════════════════════════════════════════════════════════════════════

public record ProductDto(
    Guid         Id,
    string       Name,
    string?      Description,
    string?      ImageUrl,
    decimal      Price,
    decimal?     Cost,
    decimal?     ComparePrice,
    string?      SKU,
    string?      Barcode,
    ProductType  Type,
    bool         TrackInventory,
    bool         IsActive,
    bool         IsAvailableOnline,
    Guid?        CategoryId,
    string?      CategoryName,
    int          TotalStock,
    decimal?     RentalDailyRate,
    DateTime     CreatedAt
);

public record CreateProductRequest(
    string       Name,
    string?      Description,
    decimal      Price,
    decimal?     Cost,
    decimal?     ComparePrice,
    string?      SKU,
    string?      Barcode,
    Guid?        CategoryId,
    Guid?        BranchId,
    ProductType  Type           = ProductType.Physical,
    bool         TrackInventory = true,
    bool         IsActive       = true,
    bool         IsAvailableOnline = true,
    int          InitialStock   = 0,
    decimal?     RentalDailyRate = null,
    decimal?     RentalDeposit   = null
);

public record UpdateProductRequest(
    string?  Name            = null,
    string?  Description     = null,
    decimal? Price           = null,
    decimal? Cost            = null,
    decimal? ComparePrice    = null,
    Guid?    CategoryId      = null,
    bool?    IsActive        = null,
    bool?    IsAvailableOnline = null,
    string?  ImageUrl        = null
);

public record UpdateInventoryRequest(
    Guid BranchId,
    int  Quantity,
    int  MinQuantity = 5,
    int  MaxQuantity = 1000
);

// ══════════════════════════════════════════════════════════════════════════════
// ORDER DTOs
// ══════════════════════════════════════════════════════════════════════════════

public record OrderDto(
    Guid          Id,
    string        OrderNumber,
    Guid          BranchId,
    string?       BranchName,
    Guid?         CustomerId,
    string?       CustomerName,
    Guid?         UserId,
    string?       CashierName,
    OrderStatus   Status,
    OrderType     Type,
    int?          TableNumber,
    decimal       SubTotal,
    decimal       Discount,
    decimal       TaxAmount,
    decimal       DeliveryFee,
    decimal       Total,
    PaymentMethod PaymentMethod,
    PaymentStatus PaymentStatus,
    string?       Notes,
    string?       DeliveryAddress,
    List<OrderItemDto> Items,
    DateTime      CreatedAt,
    DateTime?     CompletedAt
);

public record OrderItemDto(
    Guid    ProductId,
    string  ProductName,
    int     Quantity,
    decimal UnitPrice,
    decimal Discount,
    decimal Total,
    string? Notes
);

public record CreateOrderRequest(
    Guid               BranchId,
    Guid?              CustomerId,
    OrderType          Type,
    int?               TableNumber,
    PaymentMethod      PaymentMethod,
    List<CreateOrderItemRequest> Items,
    string?            Notes          = null,
    string?            DeliveryAddress = null,
    double?            DeliveryLat    = null,
    double?            DeliveryLng    = null
);

public record CreateOrderItemRequest(
    Guid    ProductId,
    int     Quantity,
    string? Notes = null
);

public record OrderSummaryDto(
    DateTime Date,
    int      TotalOrders,
    int      CompletedOrders,
    int      CancelledOrders,
    decimal  TotalRevenue,
    decimal  TotalTax,
    decimal  TotalDeliveryFees,
    Dictionary<string, int>     OrdersByType,
    Dictionary<string, decimal> RevenueByPaymentMethod
);

// ══════════════════════════════════════════════════════════════════════════════
// CUSTOMER DTOs
// ══════════════════════════════════════════════════════════════════════════════

public record CustomerDto(
    Guid      Id,
    string    Name,
    string?   Email,
    string?   PhoneNumber,
    string?   Address,
    string?   City,
    int       LoyaltyPoints,
    decimal   TotalSpent,
    int       TotalOrders,
    DateTime? BirthDate,
    DateTime  CreatedAt
);

public record CreateCustomerRequest(
    string    Name,
    string?   Email       = null,
    string?   PhoneNumber = null,
    string?   Address     = null,
    string?   City        = null,
    DateTime? BirthDate   = null,
    string?   Notes       = null
);

// ══════════════════════════════════════════════════════════════════════════════
// PLAN / SUBSCRIPTION DTOs
// ══════════════════════════════════════════════════════════════════════════════

public record PlanDto(
    Guid     Id,
    string   Name,
    string   NameEn,
    PlanType Type,
    decimal  MonthlyPrice,
    decimal  AnnualPrice,
    int      MaxBranches,
    int      MaxUsers,
    int      MaxProducts,
    bool     HasMarketplace,
    bool     HasDelivery,
    bool     HasAi,
    bool     HasRestaurantModule,
    bool     HasRentalModule,
    bool     HasWhiteLabel
);

public record SubscriptionDto(
    Guid               Id,
    Guid               TenantId,
    PlanDto            Plan,
    SubscriptionStatus Status,
    BillingCycle       BillingCycle,
    decimal            Amount,
    DateTime           StartDate,
    DateTime           EndDate,
    bool               AutoRenew
);

// ══════════════════════════════════════════════════════════════════════════════
// PLATFORM DTOs
// ══════════════════════════════════════════════════════════════════════════════

public record PlatformStatsDto(
    int     TotalTenants,
    int     ActiveTenants,
    int     TrialTenants,
    int     TotalUsers,
    int     TotalOrders,
    decimal TotalRevenue,
    decimal MonthlyRevenue,
    decimal MRR,
    int     TotalProducts,
    Dictionary<string, int>     TenantsByPlan,
    Dictionary<string, decimal> RevenueByMonth,
    List<TopTenantDto>          TopTenants
);

public record TopTenantDto(
    Guid     Id,
    string   Name,
    string   Slug,
    PlanType Plan,
    int      OrderCount,
    decimal  Revenue,
    DateTime CreatedAt
);

public record TenantDetailsDto(
    Guid     Id,
    string   Name,
    string   Slug,
    PlanType Plan,
    bool     IsActive,
    bool     IsVerified,
    int      UserCount,
    int      BranchCount,
    int      OrderCount,
    decimal  TotalRevenue,
    string?  Email,
    string?  PhoneNumber,
    DateTime CreatedAt,
    DateTime? TrialEndsAt
);

// ══════════════════════════════════════════════════════════════════════════════
// DELIVERY DTOs
// ══════════════════════════════════════════════════════════════════════════════

public record DriverDto(
    Guid    Id,
    Guid    UserId,
    string  FullName,
    string? PhoneNumber,
    bool    IsVerified,
    bool    IsOnline,
    bool    IsAvailable,
    double  Rating,
    int     TotalDeliveries,
    string? VehicleType,
    double? CurrentLat,
    double? CurrentLng
);

public record DeliveryOrderDto(
    Guid           Id,
    Guid           OrderId,
    string         OrderNumber,
    Guid?          DriverId,
    string?        DriverName,
    DeliveryStatus Status,
    string         PickupAddress,
    string         DropoffAddress,
    decimal        DeliveryFee,
    int?           EstimatedMinutes,
    DateTime?      AssignedAt,
    DateTime?      DeliveredAt
);

public record RegisterDriverRequest(
    string? NationalIdFrontUrl,
    string? NationalIdBackUrl,
    string? VehicleType,
    string? VehiclePlate
);
