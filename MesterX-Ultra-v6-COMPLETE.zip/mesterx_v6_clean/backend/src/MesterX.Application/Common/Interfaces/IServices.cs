using MesterX.Domain.Enums;

namespace MesterX.Application.Common.Interfaces;

// ══════════════════════════════════════════════════════════════════════════════
// PRODUCT SERVICE
// ══════════════════════════════════════════════════════════════════════════════

public interface IProductService
{
    Task<ProductDto>              CreateProductAsync(Guid tenantId, CreateProductRequest req, CancellationToken ct = default);
    Task<ProductDto>              GetProductAsync(Guid tenantId, Guid productId, CancellationToken ct = default);
    Task<PagedResult<ProductDto>> GetProductsAsync(Guid tenantId, Guid? branchId, Guid? categoryId, string? search, int page, int pageSize, CancellationToken ct = default);
    Task<ProductDto>              UpdateProductAsync(Guid tenantId, Guid productId, UpdateProductRequest req, CancellationToken ct = default);
    Task                          DeleteProductAsync(Guid tenantId, Guid productId, CancellationToken ct = default);
    Task                          UpdateInventoryAsync(Guid tenantId, Guid productId, UpdateInventoryRequest req, CancellationToken ct = default);
    Task<List<ProductDto>>        GetLowStockAsync(Guid tenantId, Guid? branchId, CancellationToken ct = default);
    Task<ProductDto?>             GetByBarcodeAsync(Guid tenantId, string barcode, CancellationToken ct = default);
}

// ══════════════════════════════════════════════════════════════════════════════
// ORDER SERVICE
// ══════════════════════════════════════════════════════════════════════════════

public interface IOrderService
{
    Task<OrderDto>              CreateOrderAsync(Guid tenantId, Guid userId, CreateOrderRequest req, CancellationToken ct = default);
    Task<OrderDto>              GetOrderAsync(Guid tenantId, Guid orderId, CancellationToken ct = default);
    Task<PagedResult<OrderDto>> GetOrdersAsync(Guid tenantId, Guid? branchId, OrderStatus? status, DateTime? from, DateTime? to, int page, int pageSize, CancellationToken ct = default);
    Task<OrderDto>              UpdateStatusAsync(Guid tenantId, Guid orderId, OrderStatus newStatus, string? reason, CancellationToken ct = default);
    Task<OrderDto>              ApplyDiscountAsync(Guid tenantId, Guid orderId, decimal discount, CancellationToken ct = default);
    Task<OrderSummaryDto>       GetDailySummaryAsync(Guid tenantId, Guid branchId, DateTime date, CancellationToken ct = default);
}

// ══════════════════════════════════════════════════════════════════════════════
// CUSTOMER SERVICE
// ══════════════════════════════════════════════════════════════════════════════

public interface ICustomerService
{
    Task<CustomerDto>              CreateCustomerAsync(Guid tenantId, CreateCustomerRequest req, CancellationToken ct = default);
    Task<CustomerDto?>             GetCustomerAsync(Guid tenantId, Guid customerId, CancellationToken ct = default);
    Task<CustomerDto?>             FindByPhoneAsync(Guid tenantId, string phone, CancellationToken ct = default);
    Task<PagedResult<CustomerDto>> GetCustomersAsync(Guid tenantId, string? search, int page, int pageSize, CancellationToken ct = default);
    Task<CustomerDto>              UpdateCustomerAsync(Guid tenantId, Guid customerId, CreateCustomerRequest req, CancellationToken ct = default);
    Task                           AddLoyaltyPointsAsync(Guid tenantId, Guid customerId, int points, CancellationToken ct = default);
    Task                           UpdateSpendingStatsAsync(Guid tenantId, Guid customerId, decimal amount, CancellationToken ct = default);
}

// ══════════════════════════════════════════════════════════════════════════════
// SUBSCRIPTION SERVICE
// ══════════════════════════════════════════════════════════════════════════════

public interface ISubscriptionService
{
    Task<SubscriptionDto>       GetActiveAsync(Guid tenantId, CancellationToken ct = default);
    Task<SubscriptionDto>       UpgradeAsync(Guid tenantId, Guid planId, BillingCycle cycle, CancellationToken ct = default);
    Task                        CancelAsync(Guid tenantId, string reason, CancellationToken ct = default);
    Task<List<PlanDto>>         GetPlansAsync(CancellationToken ct = default);
    Task<bool>                  CheckFeatureAsync(Guid tenantId, string feature, CancellationToken ct = default);
}

// ══════════════════════════════════════════════════════════════════════════════
// PLATFORM SERVICE (PlatformOwner فقط)
// ══════════════════════════════════════════════════════════════════════════════

public interface IPlatformService
{
    Task<PlatformStatsDto>              GetStatsAsync(CancellationToken ct = default);
    Task<PagedResult<TenantDetailsDto>> GetTenantsAsync(string? search, PlanType? plan, bool? isActive, int page, int pageSize, CancellationToken ct = default);
    Task<TenantDetailsDto>              GetTenantAsync(Guid tenantId, CancellationToken ct = default);
    Task                                SuspendTenantAsync(Guid tenantId, string reason, CancellationToken ct = default);
    Task                                ActivateTenantAsync(Guid tenantId, CancellationToken ct = default);
}

// ══════════════════════════════════════════════════════════════════════════════
// DELIVERY SERVICE
// ══════════════════════════════════════════════════════════════════════════════

public interface IDeliveryService
{
    Task<DriverDto>              RegisterDriverAsync(Guid tenantId, Guid userId, RegisterDriverRequest req, CancellationToken ct = default);
    Task                         VerifyDriverAsync(Guid driverId, CancellationToken ct = default);
    Task                         SetOnlineStatusAsync(Guid userId, bool isOnline, CancellationToken ct = default);
    Task                         UpdateLocationAsync(Guid userId, double lat, double lng, CancellationToken ct = default);
    Task<DeliveryOrderDto>       AssignDriverAsync(Guid tenantId, Guid orderId, Guid driverId, CancellationToken ct = default);
    Task<DeliveryOrderDto>       UpdateDeliveryStatusAsync(Guid tenantId, Guid deliveryOrderId, DeliveryStatus status, CancellationToken ct = default);
    Task<List<DriverDto>>        GetAvailableDriversAsync(Guid tenantId, CancellationToken ct = default);
    Task<List<DeliveryOrderDto>> GetActiveDeliveriesAsync(Guid tenantId, Guid? driverId, CancellationToken ct = default);
}

// ══════════════════════════════════════════════════════════════════════════════
// SHARED RESULT TYPES
// ══════════════════════════════════════════════════════════════════════════════

public record PagedResult<T>(
    List<T> Items,
    int     Total,
    int     Page,
    int     PageSize,
    int     TotalPages
);
