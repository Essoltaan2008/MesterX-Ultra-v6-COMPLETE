using System;
using System.Collections.Generic;
using MesterX.Domain.Enums;

namespace MesterX.Application.DTOs;

public record ApiResponse<T>(bool Success, T? Data, List<string>? Errors = null, string? Message = null)
{
    public static ApiResponse<T> Ok(T data, string? message = null) => new(true, data, null, message);
    public static ApiResponse<T> Fail(string error) => new(false, default, new List<string> { error }, null);
}

public record ApiResponse(bool Success, string? Message = null, List<string>? Errors = null)
{
    public static ApiResponse Ok(string? message = null) => new(true, message, null);
    public static ApiResponse Fail(string error) => new(false, null, new List<string> { error });
}

// Auth DTOs
public record LoginRequest
{
    public string Username { get; init; } = null!;
    public string Email { get; init; } = null!;
    public string Password { get; init; } = null!;
}

public record RegisterRequest
{
    public string Username { get; init; } = null!;
    public string Email { get; init; } = null!;
    public string Password { get; init; } = null!;
    public string FullName { get; init; } = null!;
    public string? CompanyName { get; init; }
}

public record RefreshTokenRequest
{
    public string RefreshToken { get; init; } = null!;
}

public record ChangePasswordRequest
{
    public string OldPassword { get; init; } = null!;
    public string NewPassword { get; init; } = null!;
}

public record AuthResponse(string Token, string RefreshToken, UserDto User);

public record UserDto
{
    public Guid Id { get; init; }
    public string Username { get; init; } = null!;
    public string Email { get; init; } = null!;
    public string FullName { get; init; } = null!;
    public string RoleName { get; init; } = null!;
    public List<string> Permissions { get; init; } = new();
}

// Product & Inventory DTOs
public record ProductDto
{
    public Guid Id { get; init; }
    public Guid TenantId { get; init; }
    public Guid? CategoryId { get; init; }
    public string Name { get; init; } = null!;
    public string? NameAr { get; init; }
    public string? Barcode { get; init; }
    public string? Sku { get; init; }
    public decimal CostPrice { get; init; }
    public decimal SalePrice { get; init; }
    public bool HasVat { get; init; }
    public bool IsActive { get; init; }
    public bool TrackStock { get; init; }
    public int LowStockThreshold { get; init; }
    public string? Description { get; init; }
    public decimal? TotalStock { get; init; }
    public bool? IsLowStock { get; init; }
    public string? ImageUrl { get; init; }
    public DateTime? UpdatedAt { get; init; }
    public int? Version { get; init; }
}

public record CreateProductRequest
{
    public string Name { get; init; } = null!;
    public string? NameAr { get; init; }
    public string? Barcode { get; init; }
    public string? Sku { get; init; }
    public decimal CostPrice { get; init; }
    public decimal SalePrice { get; init; }
    public bool HasVat { get; init; } = true;
    public bool TrackStock { get; init; } = true;
    public int LowStockThreshold { get; init; } = 5;
    public Guid? CategoryId { get; init; }
    public Guid? BranchId { get; init; }
    public decimal InitialStock { get; init; }
    public string? ImageUrl { get; init; }
    public string? Description { get; init; }
}

public record UpdateProductRequest
{
    public string Name { get; init; } = null!;
    public string? NameAr { get; init; }
    public string? Barcode { get; init; }
    public string? Sku { get; init; }
    public decimal CostPrice { get; init; }
    public decimal SalePrice { get; init; }
    public bool HasVat { get; init; } = true;
    public bool TrackStock { get; init; } = true;
    public int LowStockThreshold { get; init; } = 5;
    public Guid? CategoryId { get; init; }
    public bool IsActive { get; init; } = true;
    public string? ImageUrl { get; init; }
    public string? Description { get; init; }
}

public record StockItemDto
{
    public Guid Id { get; init; }
    public Guid ProductId { get; init; }
    public string ProductName { get; init; } = null!;
    public string? ProductBarcode { get; init; }
    public Guid BranchId { get; init; }
    public string BranchName { get; init; } = null!;
    public decimal Quantity { get; init; }
    public decimal ReservedQuantity { get; init; }
    public decimal AvailableQuantity { get; init; }
    public int LowStockThreshold { get; init; }
    public bool IsLowStock { get; init; }
    public bool? IsOutOfStock { get; init; }
}

public record StockAdjustRequest
{
    public Guid ProductId { get; init; }
    public Guid BranchId { get; init; }
    public decimal QuantityChange { get; init; }
    public string? Notes { get; init; }
}

public record StockSetRequest
{
    public Guid ProductId { get; init; }
    public Guid BranchId { get; init; }
    public decimal NewQuantity { get; init; }
    public string? Notes { get; init; }
}

// Sale & POS DTOs
public record SaleOrderDto
{
    public Guid Id { get; init; }
    public string OrderNumber { get; init; } = null!;
    public Guid BranchId { get; init; }
    public string? BranchName { get; init; }
    public Guid? CustomerId { get; init; }
    public string? CustomerName { get; init; }
    public string? CashierName { get; init; }
    public SaleStatus Status { get; init; }
    public string StatusName { get; init; } = null!;
    public PaymentMethod PaymentMethod { get; init; }
    public decimal SubTotal { get; init; }
    public decimal VatAmount { get; init; }
    public decimal DiscountAmount { get; init; }
    public decimal TotalAmount { get; init; }
    public decimal AmountPaid { get; init; }
    public decimal Change { get; init; }
    public bool IsOffline { get; init; }
    public DateTime CreatedAt { get; init; }
    public DateTime? UpdatedAt { get; init; }
    public int? Version { get; init; }
    public Guid TenantId { get; init; }
    public List<SaleOrderItemDto> Items { get; init; } = new();
}

public record SaleOrderItemDto
{
    public Guid ProductId { get; init; }
    public string ProductName { get; init; } = null!;
    public string? ProductBarcode { get; init; }
    public decimal Quantity { get; init; }
    public decimal UnitPrice { get; init; }
    public decimal VatRate { get; init; }
    public decimal VatAmount { get; init; }
    public decimal DiscountAmount { get; init; }
    public decimal LineTotal { get; init; }
}

public record CreateSaleRequest
{
    public Guid BranchId { get; init; }
    public Guid? CustomerId { get; init; }
    public PaymentMethod PaymentMethod { get; init; }
    public decimal DiscountAmount { get; init; }
    public decimal AmountPaid { get; init; }
    public bool IsOffline { get; init; }
    public string? ClientIdempotencyKey { get; init; }
    public List<SaleItemInput> Items { get; init; } = new();
}

public record SaleItemInput
{
    public Guid ProductId { get; init; }
    public decimal Quantity { get; init; }
    public decimal? OverridePrice { get; init; }
    public decimal DiscountAmount { get; init; }
}

public record RefundRequest
{
    public decimal RefundAmount { get; init; }
    public string Reason { get; init; } = null!;
}

// License & Plan DTOs
public record LicenseSummaryDto
{
    public string PlanName { get; init; } = null!;
    public PlanType PlanType { get; init; }
    public string Status { get; init; } = null!;
    public DateTime ActivatedAt { get; init; }
    public DateTime? ExpiresAt { get; init; }
    public int? DaysRemaining { get; init; }
    public bool SyncAddonActive { get; init; }
    public DateTime? SyncAddonExpiresAt { get; init; }
    public int MaxBranches { get; init; }
    public int MaxUsers { get; init; }
    public int MaxProducts { get; init; }
    public bool AllowSync { get; init; }
    public bool AllowAdvancedReports { get; init; }
    public bool AllowApiAccess { get; init; }
}

public record SubscriptionPlanDto
{
    public Guid Id { get; init; }
    public string Name { get; init; } = null!;
    public PlanType PlanType { get; init; }
    public decimal Price { get; init; }
    public string Currency { get; init; } = "EGP";
    public int? DurationDays { get; init; }
    public int MaxBranches { get; init; }
    public int MaxUsers { get; init; }
    public int MaxProducts { get; init; }
    public bool AllowSync { get; init; }
    public bool AllowAdvancedReports { get; init; }
    public bool AllowApiAccess { get; init; }
    public bool AllowWhiteLabel { get; init; }
    public bool IsActive { get; init; }
}

public record ActivateLicenseRequest
{
    public string LicenseKey { get; init; } = null!;
    public string? DeviceFingerprint { get; init; }
}

public record ActivateSyncAddonRequest
{
    public string SyncKey { get; init; } = null!;
}

public record ValidateDeviceRequest
{
    public string DeviceFingerprint { get; init; } = null!;
}

// Reporting DTOs
public record DashboardDto
{
    public decimal TodayRevenue { get; init; }
    public int TodayTransactions { get; init; }
    public int LowStockProducts { get; init; }
    public int OutOfStockProducts { get; init; }
    public int TotalCustomers { get; init; }
    public decimal WeekRevenue { get; init; }
    public int WeekTransactions { get; init; }
    public decimal MonthRevenue { get; init; }
    public int MonthTransactions { get; init; }
    public int TotalProducts { get; init; }
    public List<DailyRevenueDto> DailyRevenue { get; init; } = new();
    public List<TopProductDto> TopProducts { get; init; } = new();
}

public record DailyRevenueDto
{
    public DateTime Date { get; init; }
    public decimal Revenue { get; init; }
    public int? Transactions { get; init; }
}

public record TopProductDto
{
    public Guid ProductId { get; init; }
    public string ProductName { get; init; } = null!;
    public decimal QuantitySold { get; init; }
    public decimal Revenue { get; init; }
}

public record SalesReportDto
{
    public DateTime FromDate { get; init; }
    public DateTime ToDate { get; init; }
    public decimal TotalRevenue { get; init; }
    public decimal TotalVat { get; init; }
    public decimal TotalDiscount { get; init; }
    public decimal NetRevenue { get; init; }
    public int TotalTransactions { get; init; }
    public decimal AverageOrderValue { get; init; }
    public List<SalesReportLineDto> Lines { get; init; } = new();
}

public record SalesReportLineDto
{
    public DateTime Date { get; init; }
    public string? BranchName { get; init; }
    public int Transactions { get; init; }
    public decimal Revenue { get; init; }
    public decimal VatAmount { get; init; }
    public decimal DiscountAmount { get; init; }
    public decimal NetRevenue { get; init; }
}

// Sync DTOs
public record SyncPushRequest
{
    public Guid DeviceId { get; init; }
    public string DeviceName { get; init; } = null!;
    public DateTime ClientLastSyncedAt { get; init; }
    public List<SyncItemInput> Items { get; init; } = new();
}

public record SyncItemInput
{
    public string IdempotencyKey { get; init; } = null!;
    public SyncEntityType EntityType { get; init; }
    public Guid EntityId { get; init; }
    public string Payload { get; init; } = null!;
    public int ClientVersion { get; init; }
    public ConflictStrategy ConflictStrategy { get; init; }
}

public record SyncItemRequest
{
    public string IdempotencyKey { get; init; } = null!;
    public SyncEntityType EntityType { get; init; }
    public Guid EntityId { get; init; }
    public string Payload { get; init; } = null!;
    public int ClientVersion { get; init; }
    public ConflictStrategy ConflictStrategy { get; init; }
}

public record SyncItemResult
{
    public string IdempotencyKey { get; init; } = null!;
    public bool Success { get; init; }
    public string? Message { get; init; }
    public string? ErrorMessage { get; init; }
}

public record SyncPushResponse
{
    public List<SyncItemResult> Results { get; init; } = new();
    public int ProcessedCount { get; init; }
    public int ConflictCount { get; init; }
    public int Accepted { get; init; }
    public int Rejected { get; init; }
    public int Conflicts { get; init; }
}

public record SyncPullResponse
{
    public List<ProductDto>? Products { get; init; }
    public List<StockItemDto>? StockItems { get; init; }
    public DateTime? ServerLastSyncedAt { get; init; }
    public DateTime ServerTime { get; init; }
    public DateTime? LastSyncedAt { get; init; }
    public List<UserDto>? Customers { get; init; } // Placeholder or use actual customer DTO
    public List<SaleOrderDto>? SaleOrders { get; init; }
    public int TotalItems { get; init; }
}
