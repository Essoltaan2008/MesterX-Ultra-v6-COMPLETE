using System;
using System.Collections.Generic;
using MesterX.Domain.Enums;

namespace MesterX.Application.DTOs;

// ─── VENDOR DTOs ───────────────────────────────────────────────

public record VendorDto
{
    public Guid Id { get; init; }
    public string BusinessName { get; init; } = null!;
    public string VendorType { get; init; } = null!;
    public decimal Rating { get; init; }
    public int ReviewCount { get; init; }
    public string? LogoUrl { get; init; }
    public string? Address { get; init; }
    public bool IsVerified { get; init; }
    public bool IsActive { get; init; }
    public DateTime CreatedAt { get; init; }

    // Constructor to support old positional usage if any, but properties are better
    public VendorDto() { }
    public VendorDto(Guid id, string name, string type, decimal rating, int count, string? logo, string? addr, bool verified, bool active, DateTime created)
    {
        Id = id; BusinessName = name; VendorType = type; Rating = rating; ReviewCount = count; LogoUrl = logo; Address = addr; IsVerified = verified; IsActive = active; CreatedAt = created;
    }
}

public record VendorDetailDto
{
    public Guid Id { get; init; }
    public string BusinessName { get; init; } = null!;
    public string Bio { get; init; } = null!;
    public decimal Rating { get; init; }
    public int ReviewCount { get; init; }
    public string? LogoUrl { get; init; }
    public string? CoverImageUrl { get; init; }
    public string? Address { get; init; }
    public string? City { get; init; }
    public decimal? Latitude { get; init; }
    public decimal? Longitude { get; init; }
    public bool IsVerified { get; init; }
    public bool IsActive { get; init; }
    public List<VendorServiceDto> Services { get; init; } = new();
    public List<VendorReviewDto> Reviews { get; init; } = new();

    public VendorDetailDto() { }
    public VendorDetailDto(Guid id, string name, string bio, decimal rating, int count, string? logo, string? cover, string? addr, string? city, decimal? lat, decimal? lon, List<VendorServiceDto> services, List<ReviewDto> reviews)
    {
        Id = id; BusinessName = name; Bio = bio; Rating = rating; ReviewCount = count; LogoUrl = logo; CoverImageUrl = cover; Address = addr; City = city; Latitude = lat; Longitude = lon; Services = services; 
        Reviews = reviews.Select(r => new VendorReviewDto { Id = r.Id, CustomerName = r.CustomerName, Rating = r.Rating, Review = r.Review, CreatedAt = r.CreatedAt }).ToList();
    }
}

public record VendorServiceDto
{
    public Guid Id { get; init; }
    public string Name { get; init; } = null!;
    public string Description { get; init; } = null!;
    public decimal BasePrice { get; init; }
    public string? ImageUrl { get; init; }
    public int MinGuests { get; init; }
    public int MaxGuests { get; init; }

    public VendorServiceDto() { }
    public VendorServiceDto(Guid id, string name, string desc, decimal price, string? img)
    {
        Id = id; Name = name; Description = desc; BasePrice = price; ImageUrl = img;
    }
}

public record VendorReviewDto
{
    public Guid Id { get; init; }
    public string CustomerName { get; init; } = null!;
    public decimal Rating { get; init; }
    public string? Review { get; init; }
    public DateTime CreatedAt { get; init; }
}

public record ReviewDto(Guid Id, string CustomerName, decimal Rating, string? Review, DateTime CreatedAt);

// ─── BOOKING DTOs ───────────────────────────────────────────────

public record BookingDto
{
    public Guid Id { get; init; }
    public string BookingNumber { get; init; } = null!;
    public Guid VendorId { get; init; }
    public string VendorName { get; init; } = null!;
    public DateTime EventDate { get; init; }
    public string Status { get; init; } = null!;
    public decimal TotalPrice { get; init; }
    public decimal DepositAmount { get; init; }
    public decimal RemainingAmount { get; init; }
    public DateTime CreatedAt { get; init; }
    public List<BookingServiceDto> Services { get; init; } = new();

    public BookingDto() { }
    public BookingDto(Guid id, string num, Guid vId, string vName, DateTime date, string status, decimal total, decimal deposit, decimal remaining, DateTime created)
    {
        Id = id; BookingNumber = num; VendorId = vId; VendorName = vName; EventDate = date; Status = status; TotalPrice = total; DepositAmount = deposit; RemainingAmount = remaining; CreatedAt = created;
    }
}

public record BookingServiceDto
{
    public Guid Id { get; init; }
    public string ServiceName { get; init; } = null!;
    public decimal ServicePrice { get; init; }
    public int Quantity { get; init; }
    public decimal LineTotal { get; init; }
}

public record CreateBookingRequest
{
    public Guid VendorId { get; init; }
    public DateTime EventDate { get; init; }
    public int EstimatedGuests { get; init; }
    public string? Notes { get; init; }
    public List<BookingServiceInput> Services { get; init; } = new();
}

public record BookingServiceInput
{
    public Guid VendorServiceId { get; init; }
    public int Quantity { get; init; }
}

// ─── DASHBOARD & ANALYTICS ─────────────────────────────────────

public record VendorDashboardDto
{
    public decimal TotalRevenue { get; init; }
    public int TotalBookings { get; init; }
    public int UpcomingBookings { get; init; }
    public decimal AverageRating { get; init; }
    public List<BookingDto> RecentBookings { get; init; } = new();
    public List<VendorRevenueDto> RevenueChart { get; init; } = new();
}

public record VendorRevenueDto
{
    public DateTime Date { get; init; }
    public decimal Revenue { get; init; }
    public int BookingCount { get; init; }
}

public record CustomerDashboardDto
{
    public int TotalBookings { get; init; }
    public int UpcomingBookings { get; init; }
    public decimal TotalSpent { get; init; }
    public List<BookingDto> MyBookings { get; init; } = new();
}
