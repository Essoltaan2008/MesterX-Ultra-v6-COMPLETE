using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using MesterX.Application.DTOs;
using MesterX.Domain.Entities;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace MesterX.Application.Services;

public interface ISyncService
{
    Task<ApiResponse<SyncPushResponse>> PushAsync(Guid tenantId, Guid userId, SyncPushRequest request);
    Task<ApiResponse<SyncPullResponse>> PullAsync(Guid tenantId, Guid branchId, DateTime lastSyncedAt);
}

public class SyncService : ISyncService
{
    private readonly IUnitOfWork _uow;
    private readonly ILicenseService _license;
    private readonly IAuditService _audit;
    private readonly ILogger<SyncService> _logger;

    public SyncService(IUnitOfWork uow, ILicenseService license, IAuditService audit, ILogger<SyncService> logger)
    {
        _uow = uow;
        _license = license;
        _audit = audit;
        _logger = logger;
    }

    public async Task<ApiResponse<SyncPushResponse>> PushAsync(Guid tenantId, Guid userId, SyncPushRequest request)
    {
        // Check sync permission
        var licenseStatus = await _license.GetStatusAsync();
        if (!licenseStatus.Data?.AllowSync ?? true)
            return ApiResponse<SyncPushResponse>.Fail("Your current plan does not support cloud sync. Upgrade to Pro Monthly, Lifetime (with sync add-on), or Enterprise.");

        await _uow.BeginTransactionAsync();
        try
        {
            var results = new List<SyncItemResult>();
            int accepted = 0, rejected = 0, conflicts = 0;

            foreach (var item in request.Items)
            {
                var syncReq = new SyncItemRequest
                {
                    IdempotencyKey = item.IdempotencyKey,
                    EntityType = item.EntityType,
                    EntityId = item.EntityId,
                    Payload = item.Payload,
                    ClientVersion = item.ClientVersion,
                    ConflictStrategy = item.ConflictStrategy
                };
                var result = await ProcessSyncItemAsync(tenantId, syncReq);
                results.Add(result);
                if (result.Success) accepted++;
                else if (result.ErrorMessage?.Contains("Conflict") == true) conflicts++;
                else rejected++;
            }

            // Log sync session
            var session = new SyncSession
            {
                TenantId = tenantId,
                CreatedBy = userId,
                DeviceId = request.DeviceId,
                DeviceName = request.DeviceName,
                LastSyncedAt = DateTime.UtcNow,
                ItemsPushed = request.Items.Count,
                ConflictsDetected = conflicts,
                IsSuccess = rejected == 0
            };
            await _uow.SyncSessions.AddAsync(session);
            await _uow.SaveChangesAsync();
            await _uow.CommitTransactionAsync();

            await _audit.LogAsync(tenantId, userId, AuditAction.SyncPush, "SyncQueue");

            return new ApiResponse<SyncPushResponse>(true, new SyncPushResponse
            {
                Accepted = accepted,
                Rejected = rejected,
                Conflicts = conflicts,
                Results = results
            });
        }
        catch (Exception ex)
        {
            await _uow.RollbackTransactionAsync();
            _logger.LogError(ex, "Sync push failed for tenant {TenantId}", tenantId);
            return ApiResponse<SyncPushResponse>.Fail("Sync failed. Please try again.");
        }
    }

    public async Task<ApiResponse<SyncPullResponse>> PullAsync(Guid tenantId, Guid branchId, DateTime lastSyncedAt)
    {
        var licenseStatus = await _license.GetStatusAsync();
        if (!licenseStatus.Data?.AllowSync ?? true)
            return ApiResponse<SyncPullResponse>.Fail("Cloud sync is not available on your current plan.");

        var products = (await _uow.Products.FindAsync(p =>
            p.TenantId == tenantId && !p.IsDeleted && p.UpdatedAt > lastSyncedAt))
            .Select(p => new ProductDto
            {
                Id = p.Id,
                Name = p.Name,
                NameAr = p.NameAr,
                Barcode = p.Barcode,
                Sku = p.Sku,
                SalePrice = p.SalePrice,
                CostPrice = p.CostPrice,
                HasVat = p.HasVat,
                IsActive = p.IsActive,
                TrackStock = p.TrackStock,
                LowStockThreshold = p.LowStockThreshold,
                UpdatedAt = p.UpdatedAt,
                Version = p.Version,
                TenantId = p.TenantId
            }).ToList();

        var customers = (await _uow.Customers.FindAsync(c =>
            c.TenantId == tenantId && !c.IsDeleted && c.UpdatedAt > lastSyncedAt))
            .Select(c => new UserDto
            {
                Id = c.Id,
                FullName = c.Name,
                Email = c.Email ?? "",
                Username = c.Phone ?? c.Id.ToString(),
                RoleName = "Customer"
            }).ToList();

        var stockItems = (await _uow.StockItems.FindAsync(s =>
            s.TenantId == tenantId && s.BranchId == branchId && !s.IsDeleted && s.UpdatedAt > lastSyncedAt))
            .Select(s => new StockItemDto
            {
                Id = s.Id,
                ProductId = s.ProductId,
                BranchId = s.BranchId,
                Quantity = s.Quantity,
                ReservedQuantity = s.ReservedQuantity,
                AvailableQuantity = s.AvailableQuantity,
                ProductName = "Unknown", // Placeholder
                BranchName = "Unknown" // Placeholder
            }).ToList();

        var saleOrders = (await _uow.SaleOrders.FindAsync(o =>
            o.TenantId == tenantId && o.BranchId == branchId && !o.IsDeleted && o.CreatedAt > lastSyncedAt))
            .Select(o => new SaleOrderDto
            {
                Id = o.Id,
                OrderNumber = o.OrderNumber,
                BranchId = o.BranchId,
                TotalAmount = o.TotalAmount,
                Status = o.Status,
                StatusName = o.Status.ToString(),
                CreatedAt = o.CreatedAt,
                TenantId = o.TenantId
            }).ToList();

        await _audit.LogAsync(tenantId, null, AuditAction.SyncPull, "SyncQueue");

        var response = new SyncPullResponse
        {
            ServerTime = DateTime.UtcNow,
            LastSyncedAt = lastSyncedAt,
            Products = products,
            Customers = customers,
            StockItems = stockItems,
            SaleOrders = saleOrders,
            TotalItems = products.Count + customers.Count + stockItems.Count + saleOrders.Count
        };

        return ApiResponse<SyncPullResponse>.Ok(response);
    }

    // ─── Private ───────────────────────────────────────────────

    private async Task<SyncItemResult> ProcessSyncItemAsync(Guid tenantId, SyncItemRequest item)
    {
        // Idempotency check
        if (await _uow.SyncQueue.AnyAsync(q => q.TenantId == tenantId && q.IdempotencyKey == item.IdempotencyKey))
        {
            return new SyncItemResult
            {
                IdempotencyKey = item.IdempotencyKey,
                Success = true,
                Message = "Already processed (idempotent)."
            };
        }

        var syncEntry = new SyncQueue
        {
            TenantId = tenantId,
            EntityType = item.EntityType,
            EntityId = item.EntityId,
            Payload = item.Payload,
            IdempotencyKey = item.IdempotencyKey,
            Status = SyncStatus.Processing,
            ConflictStrategy = item.ConflictStrategy,
            ClientVersion = item.ClientVersion
        };

        try
        {
            bool hasConflict = false;
            string? conflictDetails = null;

            switch (item.EntityType)
            {
                case SyncEntityType.SaleOrder:
                    (hasConflict, conflictDetails) = await ProcessSaleOrderSync(tenantId, item);
                    break;
                case SyncEntityType.Customer:
                    (hasConflict, conflictDetails) = await ProcessCustomerSync(tenantId, item);
                    break;
                case SyncEntityType.StockMovement:
                    (hasConflict, conflictDetails) = await ProcessStockMovementSync(tenantId, item);
                    break;
            }

            syncEntry.Status = hasConflict && item.ConflictStrategy == ConflictStrategy.Manual
                ? SyncStatus.Conflict
                : SyncStatus.Completed;
            syncEntry.HasConflict = hasConflict;
            syncEntry.ConflictDetails = conflictDetails;
            syncEntry.ProcessedAt = DateTime.UtcNow;
            await _uow.SyncQueue.AddAsync(syncEntry);

            return new SyncItemResult
            {
                IdempotencyKey = item.IdempotencyKey,
                Success = true,
                Message = hasConflict ? $"Conflict detected: {conflictDetails}" : "Processed successfully."
            };
        }
        catch (Exception ex)
        {
            syncEntry.Status = SyncStatus.Failed;
            syncEntry.ErrorMessage = ex.Message;
            syncEntry.RetryCount++;
            await _uow.SyncQueue.AddAsync(syncEntry);
            _logger.LogError(ex, "Failed to process sync item {Key}", item.IdempotencyKey);

            return new SyncItemResult
            {
                IdempotencyKey = item.IdempotencyKey,
                Success = false,
                ErrorMessage = "Processing failed."
            };
        }
    }

    private async Task<(bool conflict, string? details)> ProcessSaleOrderSync(Guid tenantId, SyncItemRequest item)
    {
        var payload = JsonSerializer.Deserialize<SaleOrderSyncPayload>(item.Payload);
        if (payload == null) return (false, null);

        // Check if sale already exists
        if (await _uow.SaleOrders.AnyAsync(o => o.TenantId == tenantId && o.Id == item.EntityId))
            return (false, null); // Already synced

        // Deserialize and create sale
        var existingOrder = await _uow.SaleOrders.FirstOrDefaultAsync(o =>
            o.TenantId == tenantId && o.ClientIdempotencyKey == item.IdempotencyKey);

        if (existingOrder != null) return (false, null);

        // For offline sales, we trust the client data (they already deducted stock)
        return (false, null);
    }

    private async Task<(bool conflict, string? details)> ProcessCustomerSync(Guid tenantId, SyncItemRequest item)
    {
        var existing = await _uow.Customers.FirstOrDefaultAsync(c =>
            c.TenantId == tenantId && c.Id == item.EntityId);

        if (existing == null) return (false, null);

        // Version conflict check
        if (existing.Version > item.ClientVersion)
        {
            if (item.ConflictStrategy == ConflictStrategy.ServerWins)
                return (true, $"Server version {existing.Version} is newer than client version {item.ClientVersion}. Server wins.");

            if (item.ConflictStrategy == ConflictStrategy.ClientWins)
            {
                // In real app, we would update server with client data
                return (true, "Client wins (placeholder logic).");
            }
        }

        return (false, null);
    }

    private async Task<(bool conflict, string? details)> ProcessStockMovementSync(Guid tenantId, SyncItemRequest item)
    {
        // Stock movements are append-only — no conflict possible
        if (await _uow.StockMovements.AnyAsync(m => m.TenantId == tenantId && m.Id == item.EntityId))
            return (false, null);

        return (false, null);
    }

    // Minimal payload shapes for deserialization
    private record SaleOrderSyncPayload(Guid Id, DateTime CreatedAt, decimal TotalAmount);
    private record CustomerSyncPayload(Guid Id, DateTime UpdatedAt, string Name, string? Phone);
}
