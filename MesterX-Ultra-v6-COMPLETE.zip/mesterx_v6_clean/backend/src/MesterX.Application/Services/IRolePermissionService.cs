using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MesterX.Application.DTOs;

namespace MesterX.Application.Services;

public interface IRolePermissionService
{
    Task<ApiResponse<List<RoleDto>>> GetRolesAsync(Guid tenantId);
    Task<ApiResponse<RoleDto>> CreateRoleAsync(Guid tenantId, CreateRoleRequest request);
    Task<ApiResponse<RoleDto>> UpdateRoleAsync(Guid tenantId, Guid roleId, UpdateRoleRequest request);
    Task<ApiResponse> DeleteRoleAsync(Guid tenantId, Guid roleId);
    Task<ApiResponse<List<PermissionDto>>> GetPermissionsAsync(Guid tenantId);
}

public record RoleDto(Guid Id, string Name, string? Description, bool IsSystemRole, List<string> Permissions);
public record CreateRoleRequest(string Name, string? Description, List<string> PermissionCodes);
public record UpdateRoleRequest(string Name, string? Description, List<string> PermissionCodes);
public record PermissionDto(Guid Id, string Name, string Code, string Module, string? Description);
