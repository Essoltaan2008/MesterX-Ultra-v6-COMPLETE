using System;
using System.Threading.Tasks;
using MesterX.Application.DTOs;

namespace MesterX.Application.Services;

public interface IAuthService
{
    Task<ApiResponse<AuthResponse>> LoginAsync(LoginRequest request, string ipAddress, string userAgent);
    Task<ApiResponse<AuthResponse>> RegisterAsync(RegisterRequest request);
    Task<ApiResponse<AuthResponse>> RefreshTokenAsync(string refreshToken, string ipAddress);
    Task<ApiResponse> LogoutAsync(string refreshToken);
    Task<ApiResponse<UserDto>> GetCurrentUserAsync();
    Task<ApiResponse> ChangePasswordAsync(ChangePasswordRequest request);
}
