using MesterX.Application.DTOs;
using MesterX.Domain.Entities;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;
using Microsoft.Extensions.Logging;

namespace MesterX.Application.Services;

public interface IInventoryService
{
    Task<ApiResponse<List<ProductDto>>> GetProductsAsync(int page, int pageSize, string? search, Guid? categoryId);
    Task<ApiResponse<ProductDto>> GetProductByBarcodeAsync(string barcode);
    Task<ApiResponse<ProductDto>> CreateProductAsync(CreateProductRequest request);
    Task<ApiResponse<ProductDto>> UpdateProductAsync(Guid productId, UpdateProductRequest request);
    Task<ApiResponse<bool>> DeleteProductAsync(Guid productId);
    Task<ApiResponse<List<StockItemDto>>> GetStockAsync(Guid? branchId, bool lowStockOnly);
    Task<ApiResponse<StockItemDto>> AdjustStockAsync(StockAdjustRequest request);
    Task<ApiResponse<StockItemDto>> SetStockAsync(StockSetRequest request);
}

public interface IReportingService
{
    Task<ApiResponse<DashboardDto>> GetDashboardAsync(Guid? branchId);
    Task<ApiResponse<SalesReportDto>> GetSalesReportAsync(Guid? branchId, DateTime fromDate, DateTime toDate);
}

// ─────────────────────────────────────────────────────────────
// INVENTORY SERVICE
// ─────────────────────────────────────────────────────────────
public class InventoryService : IInventoryService
{
    private readonly IUnitOfWork _uow;
    private readonly IAuditService _audit;
    private readonly ITenantProvider _tenantProvider;
    private readonly IFeatureFlagService _featureFlags;
    private readonly ILogger<InventoryService> _logger;

    public InventoryService(IUnitOfWork uow, IAuditService audit, ITenantProvider tenantProvider, IFeatureFlagService featureFlags, ILogger<InventoryService> logger)
    {
        _uow = uow;
        _audit = audit;
        _tenantProvider = tenantProvider;
        _featureFlags = featureFlags;
        _logger = logger;
    }

    public async Task<ApiResponse<List<ProductDto>>> GetProductsAsync(
        int page, int pageSize, string? search, Guid? categoryId)
    {
        await _featureFlags.EnsureEnabledAsync("INVENTORY");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();

        var products = await _uow.Products.FindAsync(p =>
            !p.IsDeleted &&
            (search == null || p.Name.Contains(search) || (p.Barcode != null && p.Barcode.Contains(search))) &&
            (categoryId == null || p.CategoryId == categoryId));

        var stockItems = await _uow.StockItems.FindAsync(s => !s.IsDeleted);
        var stockByProduct = stockItems.GroupBy(s => s.ProductId)
            .ToDictionary(g => g.Key, g => g.Sum(s => s.AvailableQuantity));

        var pagedProducts = products
            .OrderBy(p => p.Name)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(p => new ProductDto
            {
                Id = p.Id,
                Name = p.Name,
                NameAr = p.NameAr,
                Description = p.Description,
                Barcode = p.Barcode,
                Sku = p.Sku,
                CategoryId = p.CategoryId,
                SalePrice = p.SalePrice,
                CostPrice = p.CostPrice,
                HasVat = p.HasVat,
                ImageUrl = p.ImageUrl,
                IsActive = p.IsActive,
                TrackStock = p.TrackStock,
                LowStockThreshold = p.LowStockThreshold,
                TotalStock = stockByProduct.TryGetValue(p.Id, out var qty) ? qty : 0,
                IsLowStock = p.TrackStock && (stockByProduct.TryGetValue(p.Id, out var s2) ? s2 <= p.LowStockThreshold : true),
                UpdatedAt = p.UpdatedAt,
                Version = p.Version
            }).ToList();

        return ApiResponse<List<ProductDto>>.Ok(pagedProducts);
    }

    public async Task<ApiResponse<ProductDto>> GetProductByBarcodeAsync(string barcode)
    {
        await _featureFlags.EnsureEnabledAsync("INVENTORY");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();

        var product = await _uow.Products.FirstOrDefaultAsync(p =>
            p.Barcode == barcode && !p.IsDeleted);

        if (product == null) return ApiResponse<ProductDto>.Fail("Product not found.");

        var stock = (await _uow.StockItems.FindAsync(s => s.ProductId == product.Id && !s.IsDeleted))
            .Sum(s => s.AvailableQuantity);

        return ApiResponse<ProductDto>.Ok(new ProductDto
        {
            Id = product.Id,
            Name = product.Name,
            NameAr = product.NameAr,
            Barcode = product.Barcode,
            Sku = product.Sku,
            SalePrice = product.SalePrice,
            CostPrice = product.CostPrice,
            HasVat = product.HasVat,
            TotalStock = stock,
            IsLowStock = product.TrackStock && stock <= product.LowStockThreshold
        });
    }

    public async Task<ApiResponse<ProductDto>> CreateProductAsync(CreateProductRequest request)
    {
        await _featureFlags.EnsureEnabledAsync("INVENTORY");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();
        var userId = _tenantProvider.CurrentUserId ?? throw new UnauthorizedAccessException();

        // License check for product count
        var license = await _uow.Licenses.FirstOrDefaultAsync(l => !l.IsDeleted);
        if (license != null)
        {
            var productCount = await _uow.Products.CountAsync(p => !p.IsDeleted);
            if (productCount >= license.MaxProducts)
                return ApiResponse<ProductDto>.Fail($"Product limit reached ({license.MaxProducts}). Upgrade your plan to add more products.");
        }

        // Barcode uniqueness
        if (request.Barcode != null && await _uow.Products.AnyAsync(p =>
            p.Barcode == request.Barcode && !p.IsDeleted))
            return ApiResponse<ProductDto>.Fail("A product with this barcode already exists.");

        await _uow.BeginTransactionAsync();
        try
        {
            var product = new Product
            {
                TenantId = tenantId,
                Name = request.Name,
                NameAr = request.NameAr,
                Description = request.Description,
                Barcode = request.Barcode,
                Sku = request.Sku,
                CategoryId = request.CategoryId,
                CostPrice = request.CostPrice,
                SalePrice = request.SalePrice,
                HasVat = request.HasVat,
                ImageUrl = request.ImageUrl,
                TrackStock = request.TrackStock,
                LowStockThreshold = request.LowStockThreshold,
                IsActive = true,
                CreatedBy = userId,
                UpdatedBy = userId
            };
            await _uow.Products.AddAsync(product);

            // Initial stock entry
            if (request.InitialStock > 0 && request.BranchId.HasValue)
            {
                var stockItem = new StockItem
                {
                    TenantId = tenantId,
                    ProductId = product.Id,
                    BranchId = request.BranchId.Value,
                    Quantity = request.InitialStock,
                    CreatedBy = userId,
                    UpdatedBy = userId
                };
                await _uow.StockItems.AddAsync(stockItem);

                await _uow.StockMovements.AddAsync(new StockMovement
                {
                    TenantId = tenantId,
                    StockItemId = stockItem.Id,
                    ProductId = product.Id,
                    BranchId = request.BranchId.Value,
                    MovementType = StockMovementType.Adjustment,
                    Quantity = request.InitialStock,
                    QuantityBefore = 0,
                    QuantityAfter = request.InitialStock,
                    Reference = "Initial stock",
                    Notes = "Product creation",
                    CreatedBy = userId
                });
            }

            await _uow.SaveChangesAsync();
            await _uow.CommitTransactionAsync();
            await _audit.LogAsync(tenantId, userId, AuditAction.Create, "Product", product.Id);

            return ApiResponse<ProductDto>.Ok(new ProductDto
            {
                Id = product.Id,
                Name = product.Name,
                SalePrice = product.SalePrice,
                CostPrice = product.CostPrice,
                Barcode = product.Barcode,
                IsActive = product.IsActive,
                TotalStock = request.InitialStock,
                UpdatedAt = product.UpdatedAt,
                Version = product.Version
            }, "Product created.");
        }
        catch (Exception ex)
        {
            await _uow.RollbackTransactionAsync();
            _logger.LogError(ex, "Product creation failed");
            return ApiResponse<ProductDto>.Fail("Failed to create product.");
        }
    }

    public async Task<ApiResponse<ProductDto>> UpdateProductAsync(Guid productId, UpdateProductRequest request)
    {
        await _featureFlags.EnsureEnabledAsync("INVENTORY");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();
        var userId = _tenantProvider.CurrentUserId ?? throw new UnauthorizedAccessException();

        var product = await _uow.Products.GetByIdAsync(productId);
        if (product == null) return ApiResponse<ProductDto>.Fail("Product not found.");

        // Barcode uniqueness (excluding self)
        if (request.Barcode != null && await _uow.Products.AnyAsync(p =>
            p.Barcode == request.Barcode && p.Id != productId && !p.IsDeleted))
            return ApiResponse<ProductDto>.Fail("Barcode already used by another product.");

        product.Name = request.Name;
        product.NameAr = request.NameAr;
        product.Description = request.Description;
        product.Barcode = request.Barcode;
        product.Sku = request.Sku;
        product.CategoryId = request.CategoryId;
        product.CostPrice = request.CostPrice;
        product.SalePrice = request.SalePrice;
        product.HasVat = request.HasVat;
        product.ImageUrl = request.ImageUrl;
        product.TrackStock = request.TrackStock;
        product.LowStockThreshold = request.LowStockThreshold;
        product.IsActive = request.IsActive;
        product.UpdatedAt = DateTime.UtcNow;
        product.UpdatedBy = userId;
        product.Version++;

        _uow.Products.Update(product);
        await _uow.SaveChangesAsync();
        await _audit.LogAsync(tenantId, userId, AuditAction.Update, "Product", product.Id);

        return ApiResponse<ProductDto>.Ok(new ProductDto
        {
            Id = product.Id,
            Name = product.Name,
            SalePrice = product.SalePrice,
            IsActive = product.IsActive,
            UpdatedAt = product.UpdatedAt,
            Version = product.Version
        }, "Product updated.");
    }

    public async Task<ApiResponse<bool>> DeleteProductAsync(Guid productId)
    {
        await _featureFlags.EnsureEnabledAsync("INVENTORY");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();
        var userId = _tenantProvider.CurrentUserId ?? throw new UnauthorizedAccessException();

        var product = await _uow.Products.GetByIdAsync(productId);
        if (product == null) return ApiResponse<bool>.Fail("Product not found.");

        product.IsDeleted = true;
        product.DeletedAt = DateTime.UtcNow;
        product.DeletedBy = userId;
        product.UpdatedAt = DateTime.UtcNow;
        product.Version++;
        _uow.Products.Update(product);
        await _uow.SaveChangesAsync();
        await _audit.LogAsync(tenantId, userId, AuditAction.Delete, "Product", product.Id);

        return ApiResponse<bool>.Ok(true, "Product deleted.");
    }

    public async Task<ApiResponse<List<StockItemDto>>> GetStockAsync(Guid? branchId, bool lowStockOnly)
    {
        await _featureFlags.EnsureEnabledAsync("INVENTORY");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();

        var stockItems = await _uow.StockItems.FindAsync(s =>
            !s.IsDeleted &&
            (branchId == null || s.BranchId == branchId));

        var productIds = stockItems.Select(s => s.ProductId).Distinct();
        var products = (await _uow.Products.FindAsync(p => productIds.Contains(p.Id) && !p.IsDeleted))
            .ToDictionary(p => p.Id);
        var branches = (await _uow.Branches.FindAsync(b => !b.IsDeleted))
            .ToDictionary(b => b.Id);

        var dtos = stockItems.Select(s => new StockItemDto
        {
            Id = s.Id,
            ProductId = s.ProductId,
            ProductName = products.TryGetValue(s.ProductId, out var p) ? p.Name : "Unknown",
            ProductBarcode = p?.Barcode,
            BranchId = s.BranchId,
            BranchName = branches.TryGetValue(s.BranchId, out var b) ? b.Name : "Unknown",
            Quantity = s.Quantity,
            ReservedQuantity = s.ReservedQuantity,
            AvailableQuantity = s.AvailableQuantity,
            LowStockThreshold = p?.LowStockThreshold ?? 5,
            IsLowStock = s.AvailableQuantity <= (p?.LowStockThreshold ?? 5),
            IsOutOfStock = s.AvailableQuantity <= 0
        });

        if (lowStockOnly) dtos = dtos.Where(d => d.IsLowStock);

        return ApiResponse<List<StockItemDto>>.Ok(dtos.ToList());
    }

    public async Task<ApiResponse<StockItemDto>> AdjustStockAsync(StockAdjustRequest request)
    {
        await _featureFlags.EnsureEnabledAsync("INVENTORY");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();
        var userId = _tenantProvider.CurrentUserId ?? throw new UnauthorizedAccessException();

        var stockItem = await _uow.StockItems.FirstOrDefaultAsync(s =>
            s.ProductId == request.ProductId && s.BranchId == request.BranchId && !s.IsDeleted);

        if (stockItem == null)
        {
            // Create new stock entry
            stockItem = new StockItem
            {
                TenantId = tenantId,
                ProductId = request.ProductId,
                BranchId = request.BranchId,
                Quantity = 0,
                CreatedBy = userId
            };
            await _uow.StockItems.AddAsync(stockItem);
            await _uow.SaveChangesAsync();
        }

        var before = stockItem.Quantity;
        var after = before + request.QuantityChange;

        if (after < 0) return ApiResponse<StockItemDto>.Fail("Stock cannot go below zero.");

        stockItem.Quantity = after;
        stockItem.UpdatedAt = DateTime.UtcNow;
        stockItem.UpdatedBy = userId;
        stockItem.Version++;
        _uow.StockItems.Update(stockItem);

        await _uow.StockMovements.AddAsync(new StockMovement
        {
            TenantId = tenantId,
            StockItemId = stockItem.Id,
            ProductId = request.ProductId,
            BranchId = request.BranchId,
            MovementType = StockMovementType.Adjustment,
            Quantity = request.QuantityChange,
            QuantityBefore = before,
            QuantityAfter = after,
            Notes = request.Notes,
            CreatedBy = userId
        });

        await _uow.SaveChangesAsync();
        return ApiResponse<StockItemDto>.Ok(new StockItemDto
        {
            Id = stockItem.Id,
            ProductId = stockItem.ProductId,
            BranchId = stockItem.BranchId,
            Quantity = stockItem.Quantity,
            AvailableQuantity = stockItem.AvailableQuantity
        }, "Stock adjusted.");
    }

    public async Task<ApiResponse<StockItemDto>> SetStockAsync(StockSetRequest request)
    {
        await _featureFlags.EnsureEnabledAsync("INVENTORY");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();

        var stockItem = await _uow.StockItems.FirstOrDefaultAsync(s =>
            s.ProductId == request.ProductId && s.BranchId == request.BranchId && !s.IsDeleted);

        var adj = new StockAdjustRequest
        {
            ProductId = request.ProductId,
            BranchId = request.BranchId,
            QuantityChange = request.NewQuantity - (stockItem?.Quantity ?? 0),
            Notes = request.Notes
        };

        return await AdjustStockAsync(adj);
    }
}

// ─────────────────────────────────────────────────────────────
// REPORTING SERVICE
// ─────────────────────────────────────────────────────────────
public class ReportingService : IReportingService
{
    private readonly IUnitOfWork _uow;
    private readonly ILicenseService _license;
    private readonly ITenantProvider _tenantProvider;
    private readonly IFeatureFlagService _featureFlags;

    public ReportingService(IUnitOfWork uow, ILicenseService license, ITenantProvider tenantProvider, IFeatureFlagService featureFlags)
    {
        _uow = uow;
        _license = license;
        _tenantProvider = tenantProvider;
        _featureFlags = featureFlags;
    }

    public async Task<ApiResponse<DashboardDto>> GetDashboardAsync(Guid? branchId)
    {
        await _featureFlags.EnsureEnabledAsync("DASHBOARD");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();

        var now = DateTime.UtcNow;
        var todayStart = now.Date;
        var weekStart = todayStart.AddDays(-(int)now.DayOfWeek);
        var monthStart = new DateTime(now.Year, now.Month, 1);

        var sales = await _uow.SaleOrders.FindAsync(o =>
            !o.IsDeleted &&
            o.Status == SaleStatus.Completed &&
            (branchId == null || o.BranchId == branchId) &&
            o.CreatedAt >= monthStart);

        var todaySales = sales.Where(o => o.CreatedAt >= todayStart).ToList();
        var weekSales = sales.Where(o => o.CreatedAt >= weekStart).ToList();
        var allMonthSales = sales.ToList();

        var products = await _uow.Products.FindAsync(p => !p.IsDeleted);
        var stockItems = await _uow.StockItems.FindAsync(s =>
            !s.IsDeleted &&
            (branchId == null || s.BranchId == branchId));
        var customers = await _uow.Customers.FindAsync(c => !c.IsDeleted);

        var productList = products.ToList();
        var stockList = stockItems.ToList();
        var stockByProduct = stockList.GroupBy(s => s.ProductId)
            .ToDictionary(g => g.Key, g => g.Sum(s => s.AvailableQuantity));

        // Top products (last 30 days)
        var orderItems = await _uow.SaleOrderItems.FindAsync(i =>
            allMonthSales.Select(s => s.Id).Contains(i.SaleOrderId));

        var dashboard = new DashboardDto
        {
            TodayRevenue = todaySales.Sum(o => o.TotalAmount),
            TodayTransactions = todaySales.Count,
            LowStockProducts = productList.Count(p => p.TrackStock && (stockByProduct.TryGetValue(p.Id, out var qty) ? qty <= p.LowStockThreshold : true)),
            OutOfStockProducts = productList.Count(p => p.TrackStock && (stockByProduct.TryGetValue(p.Id, out var qty) ? qty <= 0 : true)),
            TotalCustomers = customers.Count(),
            WeekRevenue = weekSales.Sum(o => o.TotalAmount),
            WeekTransactions = weekSales.Count,
            MonthRevenue = allMonthSales.Sum(o => o.TotalAmount),
            MonthTransactions = allMonthSales.Count,
            TotalProducts = productList.Count,
            DailyRevenue = allMonthSales.GroupBy(o => o.CreatedAt.Date)
                .Select(g => new DailyRevenueDto
                {
                    Date = g.Key,
                    Revenue = g.Sum(o => o.TotalAmount),
                    Transactions = g.Count()
                }).OrderBy(r => r.Date).ToList(),
            TopProducts = orderItems.GroupBy(i => i.ProductId)
                .Select(g => new TopProductDto
                {
                    ProductId = g.Key,
                    ProductName = g.First().ProductName,
                    QuantitySold = g.Sum(i => i.Quantity),
                    Revenue = g.Sum(i => i.LineTotal)
                }).OrderByDescending(p => p.Revenue).Take(5).ToList()
        };

        return ApiResponse<DashboardDto>.Ok(dashboard);
    }

    public async Task<ApiResponse<SalesReportDto>> GetSalesReportAsync(
        Guid? branchId, DateTime fromDate, DateTime toDate)
    {
        await _featureFlags.EnsureEnabledAsync("REPORTS");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();

        // Check plan allows advanced reports
        var licenseStatus = await _license.GetStatusAsync();
        if (licenseStatus.Data?.PlanType == PlanType.Basic)
            return ApiResponse<SalesReportDto>.Fail("Advanced sales reports require Pro Monthly, Lifetime, or Enterprise plan.");

        var sales = await _uow.SaleOrders.FindAsync(o =>
            !o.IsDeleted &&
            o.Status != SaleStatus.Voided &&
            (branchId == null || o.BranchId == branchId) &&
            o.CreatedAt >= fromDate && o.CreatedAt < toDate);

        var salesList = sales.ToList();
        var branches = (await _uow.Branches.FindAsync(b => !b.IsDeleted))
            .ToDictionary(b => b.Id, b => b.Name);

        var report = new SalesReportDto
        {
            FromDate = fromDate,
            ToDate = toDate,
            TotalRevenue = salesList.Sum(o => o.TotalAmount),
            TotalVat = salesList.Sum(o => o.VatAmount),
            TotalDiscount = salesList.Sum(o => o.DiscountAmount),
            NetRevenue = salesList.Sum(o => o.SubTotal),
            TotalTransactions = salesList.Count,
            AverageOrderValue = salesList.Any() ? salesList.Average(o => o.TotalAmount) : 0,
            Lines = salesList.GroupBy(o => new { o.CreatedAt.Date, o.BranchId })
                .Select(g => new SalesReportLineDto
                {
                    Date = g.Key.Date,
                    BranchName = branches.TryGetValue(g.Key.BranchId, out var name) ? name : "Unknown",
                    Transactions = g.Count(),
                    Revenue = g.Sum(o => o.TotalAmount),
                    VatAmount = g.Sum(o => o.VatAmount),
                    DiscountAmount = g.Sum(o => o.DiscountAmount),
                    NetRevenue = g.Sum(o => o.SubTotal)
                }).OrderBy(l => l.Date).ToList()
        };

        return ApiResponse<SalesReportDto>.Ok(report);
    }
}
