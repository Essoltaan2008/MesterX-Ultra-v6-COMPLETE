using MesterX.Domain.Entities;

namespace MesterX.Application.Services;

// ═══════════════════════════════════════════════════════════════════════════
// IRestaurantNotifier
// ─────────────────────────────────────────────────────────────────────────
// يكسر الـ Circular Dependency:
//   Application لا تعرف RestaurantHub (موجود في API)
//   بدلاً منه: تعتمد على الـ interface ده
//   API بتـ implement الـ interface باستخدام IHubContext<RestaurantHub>
// ═══════════════════════════════════════════════════════════════════════════

public interface IRestaurantNotifier
{
    // Floor plan updates
    Task TableStatusChangedAsync(Guid tenantId, Guid branchId,
        Guid tableId, string tableNumber, string status, CancellationToken ct = default);

    // Order events — branch staff
    Task QROrderPendingAsync(Guid tenantId, Guid branchId,
        Guid orderId, string orderNumber, string tableNumber,
        string? guestName, int itemCount, decimal total, CancellationToken ct = default);

    Task OrderReadyAsync(Guid tenantId, Guid branchId,
        Guid orderId, string orderNumber, string tableNumber, CancellationToken ct = default);

    Task OrderCancelledAsync(Guid tenantId, Guid branchId,
        Guid orderId, string reason, CancellationToken ct = default);

    // Kitchen events
    Task NewTicketAsync(Guid tenantId, Guid branchId,
        Guid stationId, string signalRGroup, object ticketPayload, CancellationToken ct = default);

    Task TicketUpdatedAsync(string signalRGroup,
        Guid ticketId, string status, CancellationToken ct = default);

    // Customer (QR) events
    Task BillConfirmedAsync(Guid tableId, CancellationToken ct = default);
}
