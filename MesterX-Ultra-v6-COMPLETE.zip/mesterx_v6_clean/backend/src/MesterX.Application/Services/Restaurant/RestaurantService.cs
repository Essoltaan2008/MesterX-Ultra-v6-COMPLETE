using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MesterX.Domain.Entities;
using MesterX.Domain.Interfaces;

namespace MesterX.Application.Services;

// ═══════════════════════════════════════════════════════════════════════════
// SHARED RESPONSE + MODULE GUARD
// ═══════════════════════════════════════════════════════════════════════════

public record RestResult<T>(bool Success, string? Message = null,
    T? Data = default, string? Code = null);

/// <summary>يتحقق إن الـ Tenant عنده صلاحية Restaurant Module</summary>
public class RestaurantModuleGuard
{
    private readonly IRestaurantUnitOfWork _uow;
    public RestaurantModuleGuard(IRestaurantUnitOfWork uow) => _uow = uow;

    public async Task<bool> IsEnabledAsync(Guid tenantId, CancellationToken ct = default)
    {
        var tenant = await _uow.Tenants.GetByIdAsync(tenantId, ct);
        return tenant is not null && tenant.HasModule(TenantModules.Restaurant);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// DTOs
// ═══════════════════════════════════════════════════════════════════════════

// ── Menu ──────────────────────────────────────────────────────────────────
public record MenuCategoryDto(Guid Id, string NameAr, string NameEn,
    string? ImageUrl, string? Color, int SortOrder);

public record MenuItemDto(
    Guid Id, string NameAr, string NameEn, string? ImageUrl, string? DescriptionAr,
    decimal BasePrice, decimal? BranchPrice, bool IsActive, bool IsFeatured,
    int PrepTimeMinutes, Guid CategoryId, string CategoryNameAr,
    MenuItemAvailability Availability,
    List<VariantDtoR>        Variants,
    List<ModifierGroupDtoR>  ModifierGroups
);
public record VariantDtoR(Guid Id, string NameAr, string NameEn, decimal PriceDelta, bool IsDefault);
public record ModifierGroupDtoR(Guid Id, string NameAr, string NameEn, bool IsRequired, bool AllowMultiple, int Max, List<ModifierDtoR> Modifiers);
public record ModifierDtoR(Guid Id, string NameAr, string NameEn, decimal ExtraPrice, bool IsDefault);

// ── Tables ────────────────────────────────────────────────────────────────
public record FloorPlanDto(Guid Id, string Name, int SortOrder,
    int Width, int Height, string? BgImage, List<TableDtoR> Tables);

public record TableDtoR(Guid Id, string TableNumber, int Capacity,
    TableStatus Status, int PosX, int PosY, int W, int H, int Rotation,
    string? QrToken, ActiveSessionDtoR? Session);

public record ActiveSessionDtoR(Guid Id, int GuestCount, DateTime OpenedAt,
    decimal SubTotal, int OrderCount, bool BillRequested);

// ── Orders ────────────────────────────────────────────────────────────────
public record CreateOrderReq(
    Guid SessionId, DineInOrderSource Source,
    Guid? WaiterId, string? GuestName, string? Notes,
    List<CreateOrderItemReq> Items
);
public record CreateOrderItemReq(
    Guid MenuItemId, Guid? VariantId, int Quantity,
    string? SpecialInstructions, List<Guid> ModifierIds
);
public record QRCreateOrderReq(
    string QrToken, string? GuestName, string? Notes,
    List<CreateOrderItemReq> Items
);

public record OrderSummaryDtoR(
    Guid Id, string OrderNumber, DineInOrderStatus Status, DineInOrderSource Source,
    string TableNumber, string? WaiterName, string? GuestName,
    int ItemCount, decimal Total, DateTime OrderedAt, bool NeedsConfirm
);

// ── Session ───────────────────────────────────────────────────────────────
public record OpenSessionReq(Guid TableId, int GuestCount, Guid? CustomerId, Guid UserId);
public record CloseSessionReq(Guid SessionId, Guid UserId, List<AddPaymentReq> Payments);
public record AddPaymentReq(decimal Amount, PaymentMethod Method, string? Reference);

public record SessionDetailDtoR(
    Guid Id, string TableNumber, SessionStatus Status,
    int GuestCount, DateTime OpenedAt, DateTime? ClosedAt,
    decimal SubTotal, decimal ServiceCharge, decimal Vat,
    decimal Total, decimal Paid, decimal Remaining,
    bool BillRequested, List<OrderSummaryDtoR> Orders
);

// ── Kitchen ───────────────────────────────────────────────────────────────
public record KitchenStationDto(Guid Id, string Name, string? Color,
    bool HasKds, bool HasPrinter, int SortOrder);

public record KitchenTicketDto(
    Guid Id, string TicketNumber, string TableNumber,
    KitchenTicketStatus Status, DineInOrderSource OrderSource,
    DateTime CreatedAt, int? WaitSeconds,
    List<TicketItemDto> Items
);
public record TicketItemDto(string Name, int Qty, string? Modifiers, string? Special);

// ═══════════════════════════════════════════════════════════════════════════
// RESTAURANT SERVICE INTERFACE
// ═══════════════════════════════════════════════════════════════════════════

public interface IRestaurantService
{
    // ── Module check ──────────────────────────────────────────────────────
    Task<bool> IsModuleEnabledAsync(Guid tenantId, CancellationToken ct = default);

    // ── Menu ──────────────────────────────────────────────────────────────
    Task<RestResult<List<MenuCategoryDto>>> GetCategoriesAsync(Guid tenantId, CancellationToken ct = default);
    Task<RestResult<List<MenuItemDto>>>     GetBranchMenuAsync(Guid tenantId, Guid branchId, Guid? categoryId, CancellationToken ct = default);
    Task<RestResult<bool>>                  Set86Async(Guid tenantId, Guid branchId, Guid itemId, MenuItemAvailability status, string? reason, Guid userId, CancellationToken ct = default);

    // ── Tables & Floor Plan ───────────────────────────────────────────────
    Task<RestResult<List<FloorPlanDto>>>    GetFloorPlansAsync(Guid tenantId, Guid branchId, CancellationToken ct = default);

    // ── Sessions ──────────────────────────────────────────────────────────
    Task<RestResult<SessionDetailDtoR>>     OpenSessionAsync(Guid tenantId, OpenSessionReq req, CancellationToken ct = default);
    Task<RestResult<SessionDetailDtoR>>     GetActiveSessionAsync(Guid tenantId, Guid tableId, CancellationToken ct = default);
    Task<RestResult<SessionDetailDtoR>>     CloseSessionAsync(Guid tenantId, CloseSessionReq req, CancellationToken ct = default);

    // ── Orders ────────────────────────────────────────────────────────────
    Task<RestResult<OrderSummaryDtoR>>      CreateOrderAsync(Guid tenantId, CreateOrderReq req, CancellationToken ct = default);
    Task<RestResult<OrderSummaryDtoR>>      CreateQROrderAsync(QRCreateOrderReq req, CancellationToken ct = default);
    Task<RestResult<List<OrderSummaryDtoR>>> GetActiveOrdersAsync(Guid tenantId, Guid branchId, CancellationToken ct = default);
    Task<RestResult<bool>>                  ConfirmQROrderAsync(Guid tenantId, Guid orderId, Guid waiterId, CancellationToken ct = default);
    Task<RestResult<bool>>                  SendToKitchenAsync(Guid tenantId, Guid orderId, Guid userId, CancellationToken ct = default);
    Task<RestResult<bool>>                  DeliverOrderAsync(Guid tenantId, Guid orderId, Guid userId, CancellationToken ct = default);
    Task<RestResult<bool>>                  CancelOrderAsync(Guid tenantId, Guid orderId, Guid userId, string reason, CancellationToken ct = default);

    // ── Kitchen ───────────────────────────────────────────────────────────
    Task<RestResult<List<KitchenStationDto>>> GetStationsAsync(Guid tenantId, Guid branchId, CancellationToken ct = default);
    Task<RestResult<List<KitchenTicketDto>>>  GetActiveTicketsAsync(Guid tenantId, Guid stationId, CancellationToken ct = default);
    Task<RestResult<bool>>                    UpdateTicketStatusAsync(Guid tenantId, Guid ticketId, KitchenTicketStatus status, CancellationToken ct = default);
}

// ═══════════════════════════════════════════════════════════════════════════
// IMPLEMENTATION
// ═══════════════════════════════════════════════════════════════════════════

public class RestaurantService : IRestaurantService
{
    private readonly IRestaurantUnitOfWork _uow;
    private readonly IRestaurantNotifier _notifier;
    private readonly ILogger<RestaurantService> _log;

    public RestaurantService(
        IRestaurantUnitOfWork uow,
        IRestaurantNotifier notifier,
        ILogger<RestaurantService> log)
    { _uow = uow; _notifier = notifier; _log = log; }

    // ── Module Check ──────────────────────────────────────────────────────

    public async Task<bool> IsModuleEnabledAsync(Guid tenantId, CancellationToken ct = default)
    {
        var t = await _uow.Tenants.GetByIdAsync(tenantId, ct);
        return t?.HasModule(TenantModules.Restaurant) ?? false;
    }

    // ── Menu ──────────────────────────────────────────────────────────────

    public async Task<RestResult<List<MenuCategoryDto>>> GetCategoriesAsync(
        Guid tenantId, CancellationToken ct = default)
    {
        var cats = await _uow.Categories.Query()
            .Where(c => c.TenantId == tenantId && c.IsActive)
            .OrderBy(c => c.SortOrder)
            .Select(c => new MenuCategoryDto(c.Id, c.NameAr, c.NameEn, c.ImageUrl, c.Color, c.SortOrder))
            .ToListAsync(ct);
        return Ok(cats);
    }

    public async Task<RestResult<List<MenuItemDto>>> GetBranchMenuAsync(
        Guid tenantId, Guid branchId, Guid? categoryId, CancellationToken ct = default)
    {
        var q = _uow.MenuItems.Query()
            .Include(i => i.Category)
            .Include(i => i.Variants.Where(v => v.IsActive))
            .Include(i => i.ModifierGroups.Where(g => g.IsActive))
                .ThenInclude(g => g.Modifiers.Where(m => m.IsActive))
            .Include(i => i.BranchOverrides.Where(o => o.BranchId == branchId))
            .Include(i => i.Availabilities.Where(a => a.BranchId == branchId))
            .Where(i => i.TenantId == tenantId && i.IsActive);

        if (categoryId.HasValue) q = q.Where(i => i.CategoryId == categoryId.Value);

        var items = await q.OrderBy(i => i.SortOrder).ToListAsync(ct);
        var now   = DateTime.UtcNow;
        var dtos  = new List<MenuItemDto>();

        foreach (var i in items)
        {
            var over  = i.BranchOverrides.FirstOrDefault();
            var avail = i.Availabilities.FirstOrDefault();

            if (over?.IsHiddenInBranch == true) continue;

            // Auto-restore SoldOut
            if (avail?.Status == MenuItemAvailability.SoldOut
                && avail.AvailableAgainAt <= now)
            {
                avail.Status = MenuItemAvailability.Available;
                _uow.ItemAvailability.Update(avail);
            }

            dtos.Add(new MenuItemDto(
                i.Id, i.NameAr, i.NameEn, i.ImageUrl, i.DescriptionAr,
                i.BasePrice, over?.OverridePrice, i.IsActive, i.IsFeatured,
                i.PrepTimeMinutes, i.CategoryId, i.Category.NameAr,
                avail?.Status ?? MenuItemAvailability.Available,
                i.Variants.OrderBy(v => v.SortOrder)
                    .Select(v => new VariantDtoR(v.Id, v.NameAr, v.NameEn, v.PriceDelta, v.IsDefault))
                    .ToList(),
                i.ModifierGroups.OrderBy(g => g.SortOrder)
                    .Select(g => new ModifierGroupDtoR(g.Id, g.NameAr, g.NameEn, g.IsRequired,
                        g.AllowMultiple, g.MaxSelections,
                        g.Modifiers.OrderBy(m => m.SortOrder)
                            .Select(m => new ModifierDtoR(m.Id, m.NameAr, m.NameEn, m.ExtraPrice, m.IsDefault))
                            .ToList()))
                    .ToList()
            ));
        }

        await _uow.SaveChangesAsync(ct);
        return Ok(dtos);
    }

    public async Task<RestResult<bool>> Set86Async(
        Guid tenantId, Guid branchId, Guid itemId,
        MenuItemAvailability status, string? reason, Guid userId, CancellationToken ct = default)
    {
        var a = await _uow.ItemAvailability.FirstOrDefaultAsync(
            x => x.TenantId == tenantId && x.BranchId == branchId && x.MenuItemId == itemId, ct);

        if (a is null)
            _uow.ItemAvailability.Add(new BranchItemAvailability
            {
                TenantId   = tenantId, BranchId = branchId, MenuItemId = itemId,
                Status     = status,   Reason   = reason,
                MarkedBy   = userId,   CreatedBy = userId,
                AvailableAgainAt = status == MenuItemAvailability.SoldOut
                    ? DateTime.UtcNow.Date.AddDays(1)   // يرجع غداً تلقائياً
                    : null
            });
        else
        {
            a.Status = status; a.Reason = reason; a.MarkedBy = userId;
            a.AvailableAgainAt = status == MenuItemAvailability.SoldOut
                ? DateTime.UtcNow.Date.AddDays(1) : null;
            _uow.ItemAvailability.Update(a);
        }

        await _uow.SaveChangesAsync(ct);
        return Ok(true);
    }

    // ── Floor Plans ───────────────────────────────────────────────────────

    public async Task<RestResult<List<FloorPlanDto>>> GetFloorPlansAsync(
        Guid tenantId, Guid branchId, CancellationToken ct = default)
    {
        var plans = await _uow.FloorPlans.Query()
            .Include(f => f.Tables.Where(t => t.IsActive))
            .Where(f => f.TenantId == tenantId && f.BranchId == branchId && f.IsActive)
            .OrderBy(f => f.SortOrder)
            .ToListAsync(ct);

        var tableIds = plans.SelectMany(p => p.Tables).Select(t => t.Id).ToList();
        var activeSessions = await _uow.Sessions.Query()
            .Include(s => s.Orders)
            .Where(s => tableIds.Contains(s.TableId) && s.Status == SessionStatus.Active)
            .ToListAsync(ct);
        var sessionMap = activeSessions.ToDictionary(s => s.TableId);

        var dtos = plans.Select(p => new FloorPlanDto(
            p.Id, p.Name, p.SortOrder, p.CanvasWidth, p.CanvasHeight,
            p.BackgroundImageUrl,
            p.Tables.Select(t =>
            {
                sessionMap.TryGetValue(t.Id, out var s);
                return new TableDtoR(t.Id, t.TableNumber, t.Capacity, t.Status,
                    t.PosX, t.PosY, t.Width, t.Height, t.Rotation, t.QrToken,
                    s is null ? null : new ActiveSessionDtoR(
                        s.Id, s.GuestCount, s.OpenedAt, s.SubTotal,
                        s.Orders.Count, s.BillRequestedAt.HasValue));
            }).ToList()
        )).ToList();

        return Ok(dtos);
    }

    // ── Sessions ──────────────────────────────────────────────────────────

    public async Task<RestResult<SessionDetailDtoR>> OpenSessionAsync(
        Guid tenantId, OpenSessionReq req, CancellationToken ct = default)
    {
        var table = await _uow.Tables.FirstOrDefaultAsync(
            t => t.TenantId == tenantId && t.Id == req.TableId && t.IsActive, ct);
        if (table is null) return Fail<SessionDetailDtoR>("TABLE_NOT_FOUND");

        if (table.Status == TableStatus.Occupied)
            return Fail<SessionDetailDtoR>("TABLE_OCCUPIED", "الطاولة مشغولة");

        await _uow.BeginTransactionAsync(ct);
        try
        {
            var session = new TableSession
            {
                TenantId       = tenantId, BranchId = table.BranchId,
                TableId        = req.TableId, GuestCount = req.GuestCount,
                OpenedByUserId = req.UserId, CustomerId = req.CustomerId,
                CreatedBy      = req.UserId
            };
            _uow.Sessions.Add(session);

            table.Status    = TableStatus.Occupied;
            table.UpdatedAt = DateTime.UtcNow;
            _uow.Tables.Update(table);

            await _uow.SaveChangesAsync(ct);
            await _uow.CommitTransactionAsync(ct);

            await _notifier.TableStatusChangedAsync(tenantId, table.BranchId,
                table.Id, table.TableNumber, "Occupied", ct);

            return Ok(await LoadSessionAsync(tenantId, session.Id, ct));
        }
        catch { await _uow.RollbackTransactionAsync(ct); throw; }
    }

    public async Task<RestResult<SessionDetailDtoR>> GetActiveSessionAsync(
        Guid tenantId, Guid tableId, CancellationToken ct = default)
    {
        var s = await _uow.Sessions.FirstOrDefaultAsync(
            x => x.TenantId == tenantId && x.TableId == tableId
              && x.Status == SessionStatus.Active, ct);
        if (s is null) return Fail<SessionDetailDtoR>("NO_SESSION");
        return Ok(await LoadSessionAsync(tenantId, s.Id, ct));
    }

    public async Task<RestResult<SessionDetailDtoR>> CloseSessionAsync(
        Guid tenantId, CloseSessionReq req, CancellationToken ct = default)
    {
        var session = await _uow.Sessions.Query()
            .Include(s => s.Table)
            .Include(s => s.Orders)
            .FirstOrDefaultAsync(s => s.TenantId == tenantId && s.Id == req.SessionId, ct);
        if (session is null) return Fail<SessionDetailDtoR>("NOT_FOUND");
        if (session.Status == SessionStatus.Closed)
            return Fail<SessionDetailDtoR>("ALREADY_CLOSED");

        var pending = session.Orders.Any(o =>
            o.Status is not (DineInOrderStatus.Delivered
                or DineInOrderStatus.Cancelled));
        if (pending) return Fail<SessionDetailDtoR>("PENDING_ORDERS", "يوجد طلبات لم تُسلَّم بعد");

        await _uow.BeginTransactionAsync(ct);
        try
        {
            var vatRate      = 0.14m;
            var serviceRate  = 0m;  // TODO: from Branch settings
            var serviceCharge = session.SubTotal * serviceRate;
            var vatAmount     = (session.SubTotal + serviceCharge) * vatRate;
            var total         = session.SubTotal + serviceCharge + vatAmount;

            session.ServiceCharge = serviceCharge;
            session.VatAmount     = vatAmount;
            session.TotalAmount   = total;

            foreach (var p in req.Payments)
            {
                _uow.Payments.Add(new SessionPayment
                {
                    TenantId = tenantId, BranchId = session.BranchId,
                    TableSessionId = session.Id, Amount = p.Amount,
                    PaymentMethod = p.Method, Reference = p.Reference,
                    ReceivedBy = req.UserId, CreatedBy = req.UserId
                });
                session.AmountPaid += p.Amount;
            }

            session.Status    = SessionStatus.Closed;
            session.ClosedAt  = DateTime.UtcNow;
            session.UpdatedAt = DateTime.UtcNow;
            _uow.Sessions.Update(session);

            session.Table.Status    = TableStatus.Cleaning;
            session.Table.UpdatedAt = DateTime.UtcNow;
            _uow.Tables.Update(session.Table);

            await _uow.SaveChangesAsync(ct);
            await _uow.CommitTransactionAsync(ct);

            await _notifier.TableStatusChangedAsync(tenantId, session.BranchId,
                session.Table.Id, session.Table.TableNumber, "Cleaning", ct);

            return Ok(await LoadSessionAsync(tenantId, session.Id, ct));
        }
        catch { await _uow.RollbackTransactionAsync(ct); throw; }
    }

    // ── Orders ────────────────────────────────────────────────────────────

    public async Task<RestResult<OrderSummaryDtoR>> CreateOrderAsync(
        Guid tenantId, CreateOrderReq req, CancellationToken ct = default)
    {
        var session = await _uow.Sessions.Query()
            .Include(s => s.Table)
            .FirstOrDefaultAsync(s => s.TenantId == tenantId
                && s.Id == req.SessionId && s.Status == SessionStatus.Active, ct);
        if (session is null) return Fail<OrderSummaryDtoR>("SESSION_NOT_FOUND");

        var dayCount = await _uow.Orders.CountAsync(
            o => o.TenantId == tenantId && o.BranchId == session.BranchId
              && o.CreatedAt.Date == DateTime.UtcNow.Date, ct);
        var orderNum = $"T{session.Table.TableNumber}-{dayCount + 1:D3}";

        decimal subTotal = 0m;
        int maxPrep = 0;
        var orderItems = new List<DineInOrderItem>();

        foreach (var ir in req.Items)
        {
            var mi = await _uow.MenuItems.Query()
                .Include(i => i.Variants)
                .FirstOrDefaultAsync(i => i.TenantId == tenantId
                    && i.Id == ir.MenuItemId && i.IsActive, ct);
            if (mi is null) return Fail<OrderSummaryDtoR>("ITEM_NOT_FOUND", $"الصنف {ir.MenuItemId} غير موجود");

            var over      = await _uow.MenuOverrides.FirstOrDefaultAsync(
                o => o.BranchId == session.BranchId && o.MenuItemId == mi.Id, ct);
            var unitPrice = (over?.OverridePrice ?? mi.BasePrice);
            var variant   = ir.VariantId.HasValue
                ? mi.Variants.FirstOrDefault(v => v.Id == ir.VariantId) : null;
            unitPrice += variant?.PriceDelta ?? 0;

            var mods = new List<OrderItemModifier>();
            foreach (var mid in ir.ModifierIds)
            {
                var mod = await _uow.Modifiers.GetByIdAsync(mid, ct);
                if (mod is null) continue;
                unitPrice += mod.ExtraPrice;
                mods.Add(new OrderItemModifier
                {
                    TenantId    = tenantId, ModifierId = mod.Id,
                    NameAr = mod.NameAr, NameEn = mod.NameEn,
                    ExtraPrice  = mod.ExtraPrice, CreatedBy = req.WaiterId
                });
            }

            var lineTotal = unitPrice * ir.Quantity;
            subTotal += lineTotal;
            if (mi.PrepTimeMinutes > maxPrep) maxPrep = mi.PrepTimeMinutes;

            orderItems.Add(new DineInOrderItem
            {
                TenantId = tenantId, MenuItemId = mi.Id,
                ItemNameAr = mi.NameAr, ItemNameEn = mi.NameEn,
                VariantId = variant?.Id, VariantName = variant?.NameAr,
                Quantity = ir.Quantity, UnitPrice = unitPrice, LineTotal = lineTotal,
                SpecialInstructions = ir.SpecialInstructions,
                KitchenStationId = mi.DefaultKitchenStationId,
                Modifiers = mods, CreatedBy = req.WaiterId
            });
        }

        var status = req.Source == DineInOrderSource.QRSelf
            ? DineInOrderStatus.QRPendingConfirm
            : DineInOrderStatus.Draft;

        await _uow.BeginTransactionAsync(ct);
        try
        {
            var order = new DineInOrder
            {
                TenantId = tenantId, BranchId = session.BranchId,
                OrderNumber = orderNum, TableSessionId = req.SessionId,
                OrderSource = req.Source, Status = status,
                WaiterId = req.WaiterId, GuestName = req.GuestName,
                SubTotal = subTotal, TotalAmount = subTotal,
                EstimatedPrepMins = maxPrep, Notes = req.Notes,
                CreatedBy = req.WaiterId
            };
            _uow.Orders.Add(order);
            await _uow.SaveChangesAsync(ct);

            foreach (var item in orderItems)
            {
                item.DineInOrderId = order.Id;
                _uow.OrderItems.Add(item);
                await _uow.SaveChangesAsync(ct);
                foreach (var mod in item.Modifiers)
                {
                    mod.OrderItemId = item.Id;
                    _uow.OrderModifiers.Add(mod);
                }
            }

            session.SubTotal  += subTotal;
            session.UpdatedAt  = DateTime.UtcNow;
            _uow.Sessions.Update(session);
            await _uow.SaveChangesAsync(ct);
            await _uow.CommitTransactionAsync(ct);

            if (req.Source == DineInOrderSource.QRSelf)
                await _notifier.QROrderPendingAsync(tenantId, session.BranchId,
                    order.Id, orderNum, session.Table.TableNumber,
                    req.GuestName, orderItems.Count, subTotal, ct);

            _log.LogInformation("[Restaurant] Order {Num} — Tenant {TenantId}", orderNum, tenantId);
            return Ok(new OrderSummaryDtoR(order.Id, orderNum, status, req.Source,
                session.Table.TableNumber, null, req.GuestName,
                orderItems.Count, subTotal, order.OrderedAt, order.NeedsWaiterConfirm));
        }
        catch { await _uow.RollbackTransactionAsync(ct); throw; }
    }

    public async Task<RestResult<OrderSummaryDtoR>> CreateQROrderAsync(
        QRCreateOrderReq req, CancellationToken ct = default)
    {
        var table = await _uow.Tables.FirstOrDefaultAsync(
            t => t.QrToken == req.QrToken && t.IsActive, ct);
        if (table is null) return Fail<OrderSummaryDtoR>("INVALID_QR");

        var session = await _uow.Sessions.FirstOrDefaultAsync(
            s => s.TableId == table.Id && s.Status == SessionStatus.Active, ct);
        if (session is null) return Fail<OrderSummaryDtoR>("NO_SESSION", "لا توجد جلسة مفتوحة");

        return await CreateOrderAsync(table.TenantId, new CreateOrderReq(
            session.Id, DineInOrderSource.QRSelf, null,
            req.GuestName, req.Notes, req.Items), ct);
    }

    public async Task<RestResult<List<OrderSummaryDtoR>>> GetActiveOrdersAsync(
        Guid tenantId, Guid branchId, CancellationToken ct = default)
    {
        var orders = await _uow.Orders.Query()
            .Include(o => o.Session).ThenInclude(s => s.Table)
            .Include(o => o.Waiter)
            .Include(o => o.Items)
            .Where(o => o.TenantId == tenantId && o.BranchId == branchId
                && o.Status < DineInOrderStatus.Delivered
                && o.Status != DineInOrderStatus.Cancelled)
            .OrderBy(o => o.OrderedAt)
            .ToListAsync(ct);

        return Ok(orders.Select(o => new OrderSummaryDtoR(
            o.Id, o.OrderNumber, o.Status, o.OrderSource,
            o.Session.Table.TableNumber, o.Waiter?.FullName,
            o.GuestName, o.Items.Count, o.TotalAmount,
            o.OrderedAt, o.NeedsWaiterConfirm)).ToList());
    }

    public async Task<RestResult<bool>> ConfirmQROrderAsync(
        Guid tenantId, Guid orderId, Guid waiterId, CancellationToken ct = default)
    {
        var order = await _uow.Orders.FirstOrDefaultAsync(
            o => o.TenantId == tenantId && o.Id == orderId
              && o.Status == DineInOrderStatus.QRPendingConfirm, ct);
        if (order is null) return Fail<bool>("NOT_FOUND");

        order.Status            = DineInOrderStatus.SentToKitchen;
        order.ConfirmedByUserId = waiterId;
        order.ConfirmedAt       = DateTime.UtcNow;
        order.WaiterId          = waiterId;
        order.KitchenSentAt     = DateTime.UtcNow;
        order.UpdatedAt         = DateTime.UtcNow;
        _uow.Orders.Update(order);
        await _uow.SaveChangesAsync(ct);

        await GenerateAndBroadcastTicketsAsync(tenantId, order, ct);
        return Ok(true);
    }

    public async Task<RestResult<bool>> SendToKitchenAsync(
        Guid tenantId, Guid orderId, Guid userId, CancellationToken ct = default)
    {
        var order = await _uow.Orders.FirstOrDefaultAsync(
            o => o.TenantId == tenantId && o.Id == orderId
              && o.Status == DineInOrderStatus.Draft, ct);
        if (order is null) return Fail<bool>("NOT_FOUND");

        order.Status        = DineInOrderStatus.SentToKitchen;
        order.KitchenSentAt = DateTime.UtcNow;
        order.UpdatedAt     = DateTime.UtcNow;
        _uow.Orders.Update(order);
        await _uow.SaveChangesAsync(ct);

        await GenerateAndBroadcastTicketsAsync(tenantId, order, ct);
        return Ok(true);
    }

    public async Task<RestResult<bool>> DeliverOrderAsync(
        Guid tenantId, Guid orderId, Guid userId, CancellationToken ct = default)
    {
        var order = await _uow.Orders.FirstOrDefaultAsync(
            o => o.TenantId == tenantId && o.Id == orderId
              && o.Status == DineInOrderStatus.Ready, ct);
        if (order is null) return Fail<bool>("NOT_READY", "الأوردر مش Ready");

        order.Status      = DineInOrderStatus.Delivered;
        order.DeliveredAt = DateTime.UtcNow;
        order.UpdatedAt   = DateTime.UtcNow;
        order.UpdatedBy   = userId;
        _uow.Orders.Update(order);

        var items = await _uow.OrderItems.FindAsync(i => i.DineInOrderId == orderId, ct);
        foreach (var item in items.Where(i => i.Status != OrderItemStatus.Cancelled))
        { item.Status = OrderItemStatus.Delivered; _uow.OrderItems.Update(item); }

        await _uow.SaveChangesAsync(ct);
        return Ok(true);
    }

    public async Task<RestResult<bool>> CancelOrderAsync(
        Guid tenantId, Guid orderId, Guid userId, string reason, CancellationToken ct = default)
    {
        var order = await _uow.Orders.Query()
            .Include(o => o.Session)
            .FirstOrDefaultAsync(o => o.TenantId == tenantId && o.Id == orderId, ct);
        if (order is null) return Fail<bool>("NOT_FOUND");
        if (order.Status >= DineInOrderStatus.Delivered)
            return Fail<bool>("CANNOT_CANCEL", "لا يمكن إلغاء أوردر تم تسليمه");

        order.Status       = DineInOrderStatus.Cancelled;
        order.CancelReason = reason;
        order.CancelledAt  = DateTime.UtcNow;
        order.UpdatedBy    = userId;
        _uow.Orders.Update(order);

        order.Session.SubTotal -= order.TotalAmount;
        _uow.Sessions.Update(order.Session);

        await _uow.SaveChangesAsync(ct);
        await _notifier.OrderCancelledAsync(tenantId, order.BranchId, orderId, reason, ct);
        return Ok(true);
    }

    // ── Kitchen ───────────────────────────────────────────────────────────

    public async Task<RestResult<List<KitchenStationDto>>> GetStationsAsync(
        Guid tenantId, Guid branchId, CancellationToken ct = default)
    {
        var list = await _uow.Stations.Query()
            .Where(s => s.TenantId == tenantId && s.BranchId == branchId && s.IsActive)
            .OrderBy(s => s.SortOrder)
            .Select(s => new KitchenStationDto(s.Id, s.Name, s.Color,
                s.HasKdsScreen, s.HasPrinter, s.SortOrder))
            .ToListAsync(ct);
        return Ok(list);
    }

    public async Task<RestResult<List<KitchenTicketDto>>> GetActiveTicketsAsync(
        Guid tenantId, Guid stationId, CancellationToken ct = default)
    {
        var tickets = await _uow.Tickets.Query()
            .Include(t => t.Items)
            .Include(t => t.Order)
            .Where(t => t.TenantId == tenantId
                && t.KitchenStationId == stationId
                && t.Status < KitchenTicketStatus.Done)
            .OrderBy(t => t.CreatedAtKitchen)
            .ToListAsync(ct);

        return Ok(tickets.Select(t => new KitchenTicketDto(
            t.Id, t.TicketNumber, t.TableNumber, t.Status, t.Order.OrderSource,
            t.CreatedAtKitchen,
            (int?)(DateTime.UtcNow - t.CreatedAtKitchen).TotalSeconds,
            t.Items.Select(i => new TicketItemDto(
                i.ItemName, i.Quantity, i.Modifiers, i.SpecialInstructions))
            .ToList()
        )).ToList());
    }

    public async Task<RestResult<bool>> UpdateTicketStatusAsync(
        Guid tenantId, Guid ticketId, KitchenTicketStatus status, CancellationToken ct = default)
    {
        var ticket = await _uow.Tickets.Query()
            .Include(t => t.Order)
            .Include(t => t.Station)
            .FirstOrDefaultAsync(t => t.TenantId == tenantId && t.Id == ticketId, ct);
        if (ticket is null) return Fail<bool>("NOT_FOUND");

        ticket.Status    = status;
        ticket.UpdatedAt = DateTime.UtcNow;
        if (status == KitchenTicketStatus.Seen)      ticket.SeenAt      = DateTime.UtcNow;
        if (status == KitchenTicketStatus.Preparing) ticket.PreparingAt = DateTime.UtcNow;
        if (status == KitchenTicketStatus.Done)      ticket.DoneAt      = DateTime.UtcNow;
        _uow.Tickets.Update(ticket);

        // كل تذاكر الأوردر Done → الأوردر Ready
        if (status == KitchenTicketStatus.Done)
        {
            var allDone = await _uow.Tickets.Query()
                .Where(t => t.DineInOrderId == ticket.DineInOrderId)
                .AllAsync(t => t.Status == KitchenTicketStatus.Done, ct);

            if (allDone)
            {
                ticket.Order.Status  = DineInOrderStatus.Ready;
                ticket.Order.ReadyAt = DateTime.UtcNow;
                _uow.Orders.Update(ticket.Order);

                await _notifier.OrderReadyAsync(tenantId, ticket.Order.BranchId,
                    ticket.Order.Id, ticket.Order.OrderNumber, ticket.TableNumber, ct);
            }
        }

        await _uow.SaveChangesAsync(ct);

        await _notifier.TicketUpdatedAsync(ticket.Station.SignalRGroup,
            ticketId, status.ToString(), ct);

        return Ok(true);
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private async Task GenerateAndBroadcastTicketsAsync(
        Guid tenantId, DineInOrder order, CancellationToken ct)
    {
        var items = await _uow.OrderItems.Query()
            .Include(i => i.Modifiers)
            .Where(i => i.DineInOrderId == order.Id)
            .ToListAsync(ct);

        var tableNum = (await _uow.Sessions.Query()
            .Include(s => s.Table)
            .FirstOrDefaultAsync(s => s.Id == order.TableSessionId, ct))
            ?.Table.TableNumber ?? "?";

        var byStation = items.GroupBy(i => i.KitchenStationId ?? Guid.Empty).ToList();
        int seq = 1;

        foreach (var group in byStation)
        {
            Guid? stId = group.Key == Guid.Empty
                ? (await _uow.Stations.FirstOrDefaultAsync(
                    s => s.TenantId == tenantId && s.BranchId == order.BranchId && s.IsActive, ct))?.Id
                : group.Key as Guid?;
            if (stId is null) continue;

            var station = await _uow.Stations.GetByIdAsync(stId.Value, ct);
            if (station is null) continue;

            var ticket = new KitchenTicket
            {
                TenantId         = tenantId,
                BranchId         = order.BranchId,
                DineInOrderId    = order.Id,
                KitchenStationId = stId.Value,
                TicketNumber     = $"{order.OrderNumber}-K{seq++}",
                TableNumber      = tableNum,
                CreatedBy        = order.CreatedBy
            };
            _uow.Tickets.Add(ticket);
            await _uow.SaveChangesAsync(ct);

            foreach (var item in group)
            {
                var modText = string.Join(" / ", item.Modifiers.Select(m => m.NameAr));
                _uow.TicketItems.Add(new KitchenTicketItem
                {
                    TenantId        = tenantId,
                    KitchenTicketId = ticket.Id,
                    OrderItemId     = item.Id,
                    ItemName        = item.ItemNameAr,
                    Quantity        = item.Quantity,
                    Modifiers       = string.IsNullOrEmpty(modText) ? null : modText,
                    SpecialInstructions = item.SpecialInstructions,
                    CreatedBy       = order.CreatedBy
                });
            }
            await _uow.SaveChangesAsync(ct);

            var ticketPayload = new {
                ticketId = ticket.Id, ticketNumber = ticket.TicketNumber,
                tableNumber = tableNum, orderSource = order.OrderSource.ToString(),
                items = group.Select(i => new {
                    name = i.ItemNameAr, qty = i.Quantity,
                    mods = string.Join(" / ", i.Modifiers.Select(m => m.NameAr)),
                    special = i.SpecialInstructions
                })
            };
            await _notifier.NewTicketAsync(tenantId, order.BranchId,
                stId.Value, station.SignalRGroup, ticketPayload, ct);
        }
    }

    private async Task<SessionDetailDtoR> LoadSessionAsync(
        Guid tenantId, Guid sessionId, CancellationToken ct)
    {
        var s = await _uow.Sessions.Query()
            .Include(x => x.Table)
            .Include(x => x.Orders).ThenInclude(o => o.Waiter)
            .Include(x => x.Payments)
            .FirstOrDefaultAsync(x => x.TenantId == tenantId && x.Id == sessionId, ct);

        return new SessionDetailDtoR(
            s!.Id, s.Table.TableNumber, s.Status, s.GuestCount,
            s.OpenedAt, s.ClosedAt, s.SubTotal, s.ServiceCharge,
            s.VatAmount, s.TotalAmount, s.AmountPaid, s.Remaining,
            s.BillRequestedAt.HasValue,
            s.Orders.Select(o => new OrderSummaryDtoR(
                o.Id, o.OrderNumber, o.Status, o.OrderSource,
                s.Table.TableNumber, o.Waiter?.FullName, o.GuestName,
                o.Items?.Count ?? 0, o.TotalAmount, o.OrderedAt, o.NeedsWaiterConfirm))
            .ToList());
    }

    private static RestResult<T> Ok<T>(T d)                    => new(true,  Data: d);
    private static RestResult<T> Fail<T>(string m)             => new(false, m);
    private static RestResult<T> Fail<T>(string c, string m)   => new(false, m, Code: c);
}
