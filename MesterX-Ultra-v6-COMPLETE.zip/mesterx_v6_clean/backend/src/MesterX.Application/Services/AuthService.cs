using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using MesterX.Application.Common;
using MesterX.Application.DTOs;
using MesterX.Domain.Entities;
using MesterX.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace MesterX.Application.Services;

public class AuthService : IAuthService
{
    private readonly IUnitOfWork _uow;
    private readonly IConfiguration _config;
    private readonly IAuditService _audit;
    private readonly ITenantProvider _tenantProvider;

    public AuthService(IUnitOfWork uow, IConfiguration config, IAuditService audit, ITenantProvider tenantProvider)
    {
        _uow = uow;
        _config = config;
        _audit = audit;
        _tenantProvider = tenantProvider;
    }

    public async Task<ApiResponse<AuthResponse>> LoginAsync(LoginRequest request, string ipAddress, string userAgent)
    {
        var user = await _uow.Users.Query()
            .Include(u => u.Role)
            .ThenInclude(r => r.Permissions)
            .FirstOrDefaultAsync(u => u.Username == request.Username || u.Email == request.Email);

        if (user == null || !SecurityHelper.VerifyPassword(request.Password, user.PasswordHash))
        {
            return ApiResponse<AuthResponse>.Fail("Invalid username or password.");
        }

        if (!user.IsActive)
        {
            return ApiResponse<AuthResponse>.Fail("User account is deactivated.");
        }

        var token = GenerateJwtToken(user);
        var refreshToken = SecurityHelper.GenerateRefreshToken();

        var rt = new RefreshToken
        {
            UserId = user.Id,
            TokenHash = refreshToken,
            ExpiresAt = DateTime.UtcNow.AddDays(7),
            CreatedByIp = ipAddress,
            TenantId = user.TenantId
        };

        await _uow.RefreshTokens.AddAsync(rt);
        user.LastLoginAt = DateTime.UtcNow;
        user.LastLoginIp = ipAddress;

        await _uow.SaveChangesAsync();

        var userDto = new UserDto
        {
            Id = user.Id,
            Username = user.Username,
            Email = user.Email,
            FullName = user.FullName,
            RoleName = user.Role?.Name ?? "No Role",
            Permissions = user.Role?.Permissions.Select(p => p.Code).ToList() ?? new List<string>()
        };

        return ApiResponse<AuthResponse>.Ok(new AuthResponse(token, refreshToken, userDto));
    }

    public async Task<ApiResponse<AuthResponse>> RegisterAsync(RegisterRequest request)
    {
        var existing = await _uow.Users.AnyAsync(u => u.Username == request.Username || u.Email == request.Email);
        if (existing) return ApiResponse<AuthResponse>.Fail("Username or email already exists.");

        await _uow.BeginTransactionAsync();
        try
        {
            // Create Tenant
            var tenant = new Tenant
            {
                Name = request.CompanyName ?? $"{request.FullName}'s Company",
                Slug = request.Username.ToLower(),
                Currency = "EGP",
                VatRate = 14.00m,
                IsActive = true
            };
            await _uow.Tenants.AddAsync(tenant);
            await _uow.SaveChangesAsync();

            // Create default role for tenant admin
            var adminRole = new ApplicationRole
            {
                TenantId = tenant.Id,
                Name = "Company Admin",
                IsSystemRole = true,
                Description = "Full access to company settings and operations."
            };
            await _uow.Roles.AddAsync(adminRole);
            await _uow.SaveChangesAsync();

            // Create User
            var user = new ApplicationUser
            {
                TenantId = tenant.Id,
                Username = request.Username,
                Email = request.Email,
                FullName = request.FullName,
                PasswordHash = SecurityHelper.HashPassword(request.Password),
                RoleId = adminRole.Id,
                IsActive = true
            };
            await _uow.Users.AddAsync(user);
            await _uow.SaveChangesAsync();

            await _uow.CommitTransactionAsync();

            return await LoginAsync(new LoginRequest { Username = user.Username, Email = user.Email, Password = request.Password }, "internal", "system");
        }
        catch (Exception ex)
        {
            await _uow.RollbackTransactionAsync();
            return ApiResponse<AuthResponse>.Fail($"Registration failed: {ex.Message}");
        }
    }

    public async Task<ApiResponse<AuthResponse>> RefreshTokenAsync(string refreshToken, string ipAddress)
    {
        var rt = await _uow.RefreshTokens.Query()
            .Include(r => r.User)
            .ThenInclude(u => u.Role)
            .ThenInclude(r => r.Permissions)
            .FirstOrDefaultAsync(r => r.TokenHash == refreshToken && !r.IsRevoked && r.ExpiresAt > DateTime.UtcNow);

        if (rt == null) return ApiResponse<AuthResponse>.Fail("Invalid refresh token.");

        var token = GenerateJwtToken(rt.User);
        var newRefreshToken = SecurityHelper.GenerateRefreshToken();

        rt.IsRevoked = true;
        var newRt = new RefreshToken
        {
            UserId = rt.UserId,
            TokenHash = newRefreshToken,
            ExpiresAt = DateTime.UtcNow.AddDays(7),
            CreatedByIp = ipAddress,
            TenantId = rt.TenantId
        };

        await _uow.RefreshTokens.AddAsync(newRt);
        await _uow.SaveChangesAsync();

        var userDto = new UserDto
        {
            Id = rt.User.Id,
            Username = rt.User.Username,
            Email = rt.User.Email,
            FullName = rt.User.FullName,
            RoleName = rt.User.Role?.Name ?? "No Role",
            Permissions = rt.User.Role?.Permissions.Select(p => p.Code).ToList() ?? new List<string>()
        };

        return ApiResponse<AuthResponse>.Ok(new AuthResponse(token, newRefreshToken, userDto));
    }

    public async Task<ApiResponse> LogoutAsync(string refreshToken)
    {
        var rt = await _uow.RefreshTokens.FirstOrDefaultAsync(r => r.TokenHash == refreshToken);
        if (rt != null)
        {
            rt.IsRevoked = true;
            await _uow.SaveChangesAsync();
        }
        return ApiResponse.Ok("Logged out successfully.");
    }

    public async Task<ApiResponse<UserDto>> GetCurrentUserAsync()
    {
        var userId = _tenantProvider.CurrentUserId ?? throw new UnauthorizedAccessException();
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();

        var user = await _uow.Users.Query()
            .Include(u => u.Role)
            .ThenInclude(r => r.Permissions)
            .FirstOrDefaultAsync(u => u.Id == userId && u.TenantId == tenantId);

        if (user == null) return ApiResponse<UserDto>.Fail("User not found.");

        var dto = new UserDto
        {
            Id = user.Id,
            Username = user.Username,
            Email = user.Email,
            FullName = user.FullName,
            RoleName = user.Role?.Name ?? "No Role",
            Permissions = user.Role?.Permissions.Select(p => p.Code).ToList() ?? new List<string>()
        };

        return ApiResponse<UserDto>.Ok(dto);
    }

    public async Task<ApiResponse> ChangePasswordAsync(ChangePasswordRequest request)
    {
        var userId = _tenantProvider.CurrentUserId ?? throw new UnauthorizedAccessException();
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();

        var user = await _uow.Users.FirstOrDefaultAsync(u => u.Id == userId && u.TenantId == tenantId);
        if (user == null) return ApiResponse.Fail("User not found.");

        if (!SecurityHelper.VerifyPassword(request.OldPassword, user.PasswordHash))
        {
            return ApiResponse.Fail("Incorrect old password.");
        }

        user.PasswordHash = SecurityHelper.HashPassword(request.NewPassword);
        await _uow.SaveChangesAsync();

        return ApiResponse.Ok("Password changed successfully.");
    }

    private string GenerateJwtToken(ApplicationUser user)
    {
        var secret = _config["Jwt:Secret"] ?? throw new InvalidOperationException("JWT Secret not found.");
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new List<Claim>
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, user.Email),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new Claim("tenant_id", user.TenantId.ToString()),
            new Claim(ClaimTypes.Role, user.Role?.Name ?? "User")
        };

        if (user.Role?.Permissions != null)
        {
            foreach (var perm in user.Role.Permissions)
            {
                claims.Add(new Claim("permission", perm.Code));
            }
        }

        var token = new JwtSecurityToken(
            issuer: _config["Jwt:Issuer"],
            audience: _config["Jwt:Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddHours(2),
            signingCredentials: creds
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
