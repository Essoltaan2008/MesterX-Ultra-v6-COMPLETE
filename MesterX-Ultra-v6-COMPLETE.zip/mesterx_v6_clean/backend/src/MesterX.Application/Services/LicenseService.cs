using System.Security.Cryptography;
using System.Text;
using MesterX.Application.DTOs;
using MesterX.Domain.Entities;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;
using Microsoft.Extensions.Logging;

namespace MesterX.Application.Services;

public interface ILicenseService
{
    Task<ApiResponse<LicenseSummaryDto>> GetStatusAsync();
    Task<ApiResponse<List<SubscriptionPlanDto>>> GetPlansAsync();
    Task<ApiResponse<LicenseSummaryDto>> ActivateAsync(ActivateLicenseRequest request);
    Task<ApiResponse<LicenseSummaryDto>> ActivateSyncAddonAsync(ActivateSyncAddonRequest request);
    Task<ApiResponse<bool>> ValidateDeviceAsync(ValidateDeviceRequest request);
    Task<ApiResponse<bool>> EnforceLicenseAsync();
    Task<int> RunEnforcementJobAsync(); // returns count of downgraded tenants
}

public class LicenseService : ILicenseService
{
    private readonly IUnitOfWork _uow;
    private readonly IAuditService _audit;
    private readonly ITenantProvider _tenantProvider;
    private readonly ILogger<LicenseService> _logger;

    public LicenseService(IUnitOfWork uow, IAuditService audit, ITenantProvider tenantProvider, ILogger<LicenseService> logger)
    {
        _uow = uow;
        _audit = audit;
        _tenantProvider = tenantProvider;
        _logger = logger;
    }

    public async Task<ApiResponse<LicenseSummaryDto>> GetStatusAsync()
    {
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();
        var license = await _uow.Licenses.FirstOrDefaultAsync(l => l.TenantId == tenantId && !l.IsDeleted);
        if (license == null)
            return ApiResponse<LicenseSummaryDto>.Fail("No license found for this tenant.");

        return ApiResponse<LicenseSummaryDto>.Ok(MapLicenseSummary(license));
    }

    public async Task<ApiResponse<List<SubscriptionPlanDto>>> GetPlansAsync()
    {
        var plans = await _uow.SubscriptionPlans.FindAsync(p => p.IsActive);
        var dtos = plans.Select(p => new SubscriptionPlanDto
        {
            Id = p.Id,
            Name = p.Name,
            PlanType = p.PlanType,
            Price = p.Price,
            Currency = p.Currency,
            DurationDays = p.DurationDays,
            MaxBranches = p.MaxBranches,
            MaxUsers = p.MaxUsers,
            MaxProducts = p.MaxProducts,
            AllowSync = p.AllowSync,
            AllowAdvancedReports = p.AllowAdvancedReports,
            AllowApiAccess = p.AllowApiAccess,
            AllowWhiteLabel = p.AllowWhiteLabel
        }).ToList();

        return ApiResponse<List<SubscriptionPlanDto>>.Ok(dtos);
    }

    public async Task<ApiResponse<LicenseSummaryDto>> ActivateAsync(ActivateLicenseRequest request)
    {
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();
        var userId = _tenantProvider.CurrentUserId ?? throw new UnauthorizedAccessException();
        // In production: validate key against a key-generation server or cryptographic signature.
        // Here we hash it and store. Real validation would use asymmetric signing.
        var keyHash = HashSha512(request.LicenseKey);

        // Check if key already used by another tenant
        if (await _uow.Licenses.AnyAsync(l => l.LicenseKeyHash == keyHash && l.TenantId != tenantId && !l.IsDeleted))
            return ApiResponse<LicenseSummaryDto>.Fail("License key is already in use by another account.");

        // Decode plan from key prefix (e.g. "PRO-", "LTD-", "ENT-")
        var planType = DecodePlanFromKey(request.LicenseKey);
        var plan = await _uow.SubscriptionPlans.FirstOrDefaultAsync(p => p.PlanType == planType && p.IsActive);
        if (plan == null)
            return ApiResponse<LicenseSummaryDto>.Fail("Invalid license key or plan not found.");

        var existing = await _uow.Licenses.FirstOrDefaultAsync(l => l.TenantId == tenantId && !l.IsDeleted);

        if (existing != null)
        {
            existing.LicenseKeyHash = keyHash;
            existing.PlanType = planType;
            existing.Status = LicenseStatus.Active;
            existing.ActivatedAt = DateTime.UtcNow;
            existing.ExpiresAt = plan.DurationDays.HasValue
                ? DateTime.UtcNow.AddDays(plan.DurationDays.Value)
                : null;
            existing.MaxBranches = plan.MaxBranches;
            existing.MaxUsers = plan.MaxUsers;
            existing.MaxProducts = plan.MaxProducts;
            existing.DowngradedAt = null;
            existing.DowngradeReason = null;
            existing.UpdatedAt = DateTime.UtcNow;
            existing.Version++;

            if (request.DeviceFingerprint != null)
                existing.DeviceFingerprintHash = HashSha256(request.DeviceFingerprint);

            _uow.Licenses.Update(existing);
        }
        else
        {
            var license = new License
            {
                TenantId = tenantId,
                LicenseKeyHash = keyHash,
                PlanType = planType,
                Status = LicenseStatus.Active,
                ActivatedAt = DateTime.UtcNow,
                ExpiresAt = plan.DurationDays.HasValue ? DateTime.UtcNow.AddDays(plan.DurationDays.Value) : null,
                MaxBranches = plan.MaxBranches,
                MaxUsers = plan.MaxUsers,
                MaxProducts = plan.MaxProducts,
                DeviceFingerprintHash = request.DeviceFingerprint != null ? HashSha256(request.DeviceFingerprint) : null
            };
            await _uow.Licenses.AddAsync(license);
            existing = license;
        }

        await _uow.SaveChangesAsync();
        await _audit.LogAsync(tenantId, null, AuditAction.LicenseActivate, "License", existing.Id);

        return ApiResponse<LicenseSummaryDto>.Ok(MapLicenseSummary(existing), $"{planType} plan activated successfully.");
    }

    public async Task<ApiResponse<LicenseSummaryDto>> ActivateSyncAddonAsync(ActivateSyncAddonRequest request)
    {        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();
        var userId = _tenantProvider.CurrentUserId ?? throw new UnauthorizedAccessException();
        var license = await _uow.Licenses.FirstOrDefaultAsync(l => l.TenantId == tenantId && !l.IsDeleted);
        if (license == null) return ApiResponse<LicenseSummaryDto>.Fail("No active license found.");

        license.SyncAddonActive = true;
        license.LicenseKeyHash = HashSha512(request.SyncKey);
        license.UpdatedAt = DateTime.UtcNow;
        license.Version++;

        _uow.Licenses.Update(license);
        await _uow.SaveChangesAsync();
        await _audit.LogAsync(tenantId, userId, AuditAction.Update, "LicenseAddon", license.Id, null, "Sync Enabled");

        return ApiResponse<LicenseSummaryDto>.Ok(MapLicenseSummary(license));
    }

    public async Task<ApiResponse<bool>> ValidateDeviceAsync(ValidateDeviceRequest request)
    {        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();
        var license = await _uow.Licenses.FirstOrDefaultAsync(l => l.TenantId == tenantId && !l.IsDeleted);
        if (license == null || license.Status != LicenseStatus.Active)
            return ApiResponse<bool>.Fail("No active license.");

        // In a real system, we'd track allowed Device IDs per tenant
        return ApiResponse<bool>.Ok(true);
    }

    public async Task<ApiResponse<bool>> EnforceLicenseAsync()
    {        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();
        var license = await _uow.Licenses.FirstOrDefaultAsync(l => l.TenantId == tenantId && !l.IsDeleted);
        if (license == null) return ApiResponse<bool>.Ok(true);

        if (license.ExpiresAt.HasValue && license.ExpiresAt < DateTime.UtcNow)
        {
            license.Status = LicenseStatus.Expired;
            license.UpdatedAt = DateTime.UtcNow;
            _uow.Licenses.Update(license);
            await _uow.SaveChangesAsync();
            return ApiResponse<bool>.Fail("License expired.");
        }

        return ApiResponse<bool>.Ok(true);
    }

    public async Task<int> RunEnforcementJobAsync()
    {
        int downgraded = 0;
        var expiredLicenses = await _uow.Licenses.FindAsync(l =>
            !l.IsDeleted
            && l.Status == LicenseStatus.Active
            && l.ExpiresAt.HasValue
            && l.ExpiresAt.Value <= DateTime.UtcNow
            && (l.PlanType == PlanType.Trial || l.PlanType == PlanType.ProMonthly));

        foreach (var license in expiredLicenses)
        {
            await DowngradeToBasicAsync(license, $"Auto-downgrade: {license.PlanType} expired");
            downgraded++;
        }

        // Expire sync add-ons
        var expiredSyncLicenses = await _uow.Licenses.FindAsync(l =>
            !l.IsDeleted
            && l.SyncAddonActive
            && l.SyncAddonExpiresAt.HasValue
            && l.SyncAddonExpiresAt.Value <= DateTime.UtcNow);

        foreach (var license in expiredSyncLicenses)
        {
            license.SyncAddonActive = false;
            license.UpdatedAt = DateTime.UtcNow;
            license.Version++;
            _uow.Licenses.Update(license);
        }

        if (downgraded > 0 || expiredSyncLicenses.Any())
            await _uow.SaveChangesAsync();

        _logger.LogInformation("License enforcement: {Downgraded} tenants downgraded.", downgraded);
        return downgraded;
    }

    // ─── Private ───────────────────────────────────────────────

    private async Task DowngradeToBasicAsync(License license, string reason)
    {
        var basicPlan = await _uow.SubscriptionPlans.FirstOrDefaultAsync(p => p.PlanType == PlanType.Basic);

        license.PlanType = PlanType.Basic;
        license.Status = LicenseStatus.Downgraded;
        license.ExpiresAt = null;
        license.MaxBranches = basicPlan?.MaxBranches ?? 1;
        license.MaxUsers = basicPlan?.MaxUsers ?? 1;
        license.MaxProducts = basicPlan?.MaxProducts ?? 500;
        license.DowngradedAt = DateTime.UtcNow;
        license.DowngradeReason = reason;
        license.UpdatedAt = DateTime.UtcNow;
        license.Version++;
        _uow.Licenses.Update(license);

        await _audit.LogAsync(license.TenantId, null, AuditAction.LicenseDowngrade, "License", license.Id,
            newValues: reason);
    }

    private static LicenseSummaryDto MapLicenseSummary(License l) => new()
    {
        PlanType = l.PlanType,
        PlanName = l.PlanType.ToString(),
        Status = l.Status.ToString(),
        ActivatedAt = l.ActivatedAt,
        ExpiresAt = l.ExpiresAt,
        DaysRemaining = l.ExpiresAt.HasValue
            ? Math.Max(0, (int)(l.ExpiresAt.Value - DateTime.UtcNow).TotalDays)
            : int.MaxValue,
        SyncAddonActive = l.SyncAddonActive,
        SyncAddonExpiresAt = l.SyncAddonExpiresAt,
        MaxBranches = l.MaxBranches,
        MaxUsers = l.MaxUsers,
        MaxProducts = l.MaxProducts,
        AllowSync = l.PlanType is PlanType.ProMonthly or PlanType.Enterprise
            || (l.PlanType == PlanType.Lifetime && l.SyncAddonActive),
        AllowAdvancedReports = l.PlanType is not PlanType.Basic,
        AllowApiAccess = l.PlanType == PlanType.Enterprise
    };

    private static PlanType DecodePlanFromKey(string key)
    {
        var upper = key.ToUpper();
        if (upper.StartsWith("TRL-")) return PlanType.Trial;
        if (upper.StartsWith("PRO-")) return PlanType.ProMonthly;
        if (upper.StartsWith("LTD-")) return PlanType.Lifetime;
        if (upper.StartsWith("ENT-")) return PlanType.Enterprise;
        return PlanType.Basic;
    }

    private static string HashSha256(string input)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(input));
        return Convert.ToHexString(bytes).ToLower();
    }

    private static string HashSha512(string input)
    {
        var bytes = SHA512.HashData(Encoding.UTF8.GetBytes(input));
        return Convert.ToHexString(bytes).ToLower();
    }
}
