using System;

namespace MesterX.Application.Services;

public interface ITenantProvider
{
    Guid? TenantId { get; }
    string? CurrentUserRole { get; }
    Guid? CurrentUserId { get; }
}
