using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MesterX.Application.DTOs;
using MesterX.Domain.Entities;
using MesterX.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MesterX.Application.Services;

public class RolePermissionService : IRolePermissionService
{
    private readonly IUnitOfWork _uow;

    public RolePermissionService(IUnitOfWork uow)
    {
        _uow = uow;
    }

    public async Task<ApiResponse<List<RoleDto>>> GetRolesAsync(Guid tenantId)
    {
        var roles = await _uow.Roles.Query()
            .Include(r => r.Permissions)
            .Where(r => r.TenantId == tenantId && !r.IsDeleted)
            .ToListAsync();

        var dtos = roles.Select(r => new RoleDto(
            r.Id,
            r.Name,
            r.Description,
            r.IsSystemRole,
            r.Permissions.Select(p => p.Code).ToList()
        )).ToList();

        return ApiResponse<List<RoleDto>>.Ok(dtos);
    }

    public async Task<ApiResponse<RoleDto>> CreateRoleAsync(Guid tenantId, CreateRoleRequest request)
    {
        var existing = await _uow.Roles.AnyAsync(r => r.TenantId == tenantId && r.Name == request.Name && !r.IsDeleted);
        if (existing) return ApiResponse<RoleDto>.Fail("Role name already exists.");

        var permissions = await _uow.Permissions.FindAsync(p => 
            p.TenantId == tenantId && request.PermissionCodes.Contains(p.Code) && !p.IsDeleted);

        var role = new ApplicationRole
        {
            TenantId = tenantId,
            Name = request.Name,
            Description = request.Description,
            Permissions = permissions.ToList()
        };

        await _uow.Roles.AddAsync(role);
        await _uow.SaveChangesAsync();

        return ApiResponse<RoleDto>.Ok(new RoleDto(
            role.Id,
            role.Name,
            role.Description,
            role.IsSystemRole,
            role.Permissions.Select(p => p.Code).ToList()
        ));
    }

    public async Task<ApiResponse<RoleDto>> UpdateRoleAsync(Guid tenantId, Guid roleId, UpdateRoleRequest request)
    {
        var role = await _uow.Roles.Query()
            .Include(r => r.Permissions)
            .FirstOrDefaultAsync(r => r.Id == roleId && r.TenantId == tenantId && !r.IsDeleted);

        if (role == null) return ApiResponse<RoleDto>.Fail("Role not found.");
        if (role.IsSystemRole) return ApiResponse<RoleDto>.Fail("Cannot update system roles.");

        role.Name = request.Name;
        role.Description = request.Description;

        var permissions = await _uow.Permissions.FindAsync(p => 
            p.TenantId == tenantId && request.PermissionCodes.Contains(p.Code) && !p.IsDeleted);

        role.Permissions.Clear();
        foreach (var p in permissions) role.Permissions.Add(p);

        await _uow.SaveChangesAsync();

        return ApiResponse<RoleDto>.Ok(new RoleDto(
            role.Id,
            role.Name,
            role.Description,
            role.IsSystemRole,
            role.Permissions.Select(p => p.Code).ToList()
        ));
    }

    public async Task<ApiResponse> DeleteRoleAsync(Guid tenantId, Guid roleId)
    {
        var role = await _uow.Roles.FirstOrDefaultAsync(r => r.Id == roleId && r.TenantId == tenantId && !r.IsDeleted);
        if (role == null) return ApiResponse.Fail("Role not found.");
        if (role.IsSystemRole) return ApiResponse.Fail("Cannot delete system roles.");

        role.IsDeleted = true;
        await _uow.SaveChangesAsync();

        return ApiResponse.Ok("Role deleted successfully.");
    }

    public async Task<ApiResponse<List<PermissionDto>>> GetPermissionsAsync(Guid tenantId)
    {
        var permissions = await _uow.Permissions.FindAsync(p => p.TenantId == tenantId && !p.IsDeleted);
        var dtos = permissions.Select(p => new PermissionDto(
            p.Id,
            p.Name,
            p.Code,
            p.Module,
            p.Description
        )).ToList();

        return ApiResponse<List<PermissionDto>>.Ok(dtos);
    }
}
