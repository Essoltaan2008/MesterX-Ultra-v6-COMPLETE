using MesterX.Application.DTOs;
using MesterX.Domain.Entities;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;
using Microsoft.Extensions.Logging;

namespace MesterX.Application.Services;

public interface IPosService
{
    Task<ApiResponse<List<ProductDto>>> GetProductsAsync(Guid branchId, string? search);
    Task<ApiResponse<SaleOrderDto>> CreateSaleAsync(CreateSaleRequest request);
    Task<ApiResponse<List<SaleOrderDto>>> GetSalesAsync(Guid branchId, DateTime? fromDate, DateTime? toDate);
    Task<ApiResponse<SaleOrderDto>> GetSaleByIdAsync(Guid saleId);
    Task<ApiResponse<SaleOrderDto>> RefundSaleAsync(Guid saleId, RefundRequest request);
}

public class PosService : IPosService
{
    private readonly IUnitOfWork _uow;
    private readonly IAuditService _audit;
    private readonly ITenantProvider _tenantProvider;
    private readonly IFeatureFlagService _featureFlags;
    private readonly ILogger<PosService> _logger;

    public PosService(IUnitOfWork uow, IAuditService audit, ITenantProvider tenantProvider, IFeatureFlagService featureFlags, ILogger<PosService> logger)
    {
        _uow = uow;
        _audit = audit;
        _tenantProvider = tenantProvider;
        _featureFlags = featureFlags;
        _logger = logger;
    }

    public async Task<ApiResponse<List<ProductDto>>> GetProductsAsync(Guid branchId, string? search)
    {
        await _featureFlags.EnsureEnabledAsync("POS");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();

        var products = await _uow.Products.FindAsync(p =>
            p.IsActive && !p.IsDeleted &&
            (search == null || p.Name.Contains(search) || p.Barcode == search));

        var stockItems = await _uow.StockItems.FindAsync(s =>
            s.BranchId == branchId && !s.IsDeleted);

        var stockLookup = stockItems.ToDictionary(s => s.ProductId, s => s.AvailableQuantity);

        var dtos = products.Select(p => new ProductDto
        {
            Id = p.Id,
            Name = p.Name,
            NameAr = p.NameAr,
            Barcode = p.Barcode,
            Sku = p.Sku,
            CategoryId = p.CategoryId,
            SalePrice = p.SalePrice,
            CostPrice = p.CostPrice,
            HasVat = p.HasVat,
            ImageUrl = p.ImageUrl,
            IsActive = p.IsActive,
            TrackStock = p.TrackStock,
            LowStockThreshold = p.LowStockThreshold,
            TotalStock = stockLookup.TryGetValue(p.Id, out var qty) ? qty : 0,
            IsLowStock = p.TrackStock && (stockLookup.TryGetValue(p.Id, out var sq) ? sq <= p.LowStockThreshold : true),
            UpdatedAt = p.UpdatedAt,
            Version = p.Version,
            TenantId = p.TenantId
        }).ToList();

        return ApiResponse<List<ProductDto>>.Ok(dtos);
    }

    public async Task<ApiResponse<SaleOrderDto>> CreateSaleAsync(CreateSaleRequest request)
    {
        await _featureFlags.EnsureEnabledAsync("POS");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();
        var cashierId = _tenantProvider.CurrentUserId ?? throw new UnauthorizedAccessException();

        // Idempotency check
        if (request.ClientIdempotencyKey != null)
        {
            var existing = await _uow.SaleOrders.FirstOrDefaultAsync(o =>
                o.ClientIdempotencyKey == request.ClientIdempotencyKey);
            if (existing != null)
                return ApiResponse<SaleOrderDto>.Ok(await MapSaleOrderDtoAsync(existing), "Sale already processed (idempotent).");
        }

        await _uow.BeginTransactionAsync();
        try
        {
            var vatConfig = await _uow.PlatformConfigs.FirstOrDefaultAsync(c => c.Key == "DefaultVatRate");
            decimal vatRate = 14m;
            if (vatConfig != null && decimal.TryParse(vatConfig.Value, out var cfgVat))
                vatRate = cfgVat;

            // Build order
            var order = new SaleOrder
            {
                TenantId = tenantId,
                OrderNumber = await GenerateOrderNumberAsync(tenantId),
                BranchId = request.BranchId,
                CustomerId = request.CustomerId,
                CashierId = cashierId,
                Status = SaleStatus.Completed,
                PaymentMethod = request.PaymentMethod,
                DiscountAmount = request.DiscountAmount,
                IsOffline = request.IsOffline,
                ClientIdempotencyKey = request.ClientIdempotencyKey,
                SyncedAt = request.IsOffline ? null : DateTime.UtcNow
            };

            decimal subTotal = 0;
            decimal totalVat = 0;
            var orderItems = new List<SaleOrderItem>();

            foreach (var lineReq in request.Items)
            {
                var product = await _uow.Products.GetByIdAsync(lineReq.ProductId);
                if (product == null)
                {
                    await _uow.RollbackTransactionAsync();
                    return ApiResponse<SaleOrderDto>.Fail($"Product {lineReq.ProductId} not found.");
                }

                var unitPrice = lineReq.OverridePrice ?? product.SalePrice;
                var lineSubTotal = unitPrice * lineReq.Quantity;
                var lineVat = product.HasVat ? lineSubTotal * (vatRate / 100) : 0;
                var lineTotal = lineSubTotal + lineVat - lineReq.DiscountAmount;

                subTotal += lineSubTotal;
                totalVat += lineVat;

                orderItems.Add(new SaleOrderItem
                {
                    TenantId = tenantId,
                    SaleOrderId = order.Id,
                    ProductId = product.Id,
                    ProductName = product.Name,
                    ProductBarcode = product.Barcode,
                    Quantity = lineReq.Quantity,
                    UnitPrice = unitPrice,
                    VatRate = product.HasVat ? vatRate : 0,
                    VatAmount = lineVat,
                    DiscountAmount = lineReq.DiscountAmount,
                    LineTotal = lineTotal
                });

                // Deduct stock
                if (product.TrackStock && !request.IsOffline)
                {
                    var stockItem = await _uow.StockItems.FirstOrDefaultAsync(s =>
                        s.TenantId == tenantId && s.ProductId == product.Id && s.BranchId == request.BranchId);

                    if (stockItem == null || stockItem.AvailableQuantity < lineReq.Quantity)
                    {
                        await _uow.RollbackTransactionAsync();
                        return ApiResponse<SaleOrderDto>.Fail($"Insufficient stock for product: {product.Name}");
                    }

                    var qtyBefore = stockItem.Quantity;
                    stockItem.Quantity -= lineReq.Quantity;
                    stockItem.UpdatedAt = DateTime.UtcNow;
                    stockItem.Version++;
                    _uow.StockItems.Update(stockItem);

                    await _uow.StockMovements.AddAsync(new StockMovement
                    {
                        TenantId = tenantId,
                        StockItemId = stockItem.Id,
                        ProductId = product.Id,
                        BranchId = request.BranchId,
                        MovementType = StockMovementType.Sale,
                        Quantity = -lineReq.Quantity,
                        QuantityBefore = qtyBefore,
                        QuantityAfter = stockItem.Quantity,
                        Reference = order.OrderNumber,
                        SaleOrderId = order.Id
                    });
                }
            }

            order.SubTotal = subTotal;
            order.VatAmount = totalVat;
            order.TotalAmount = subTotal + totalVat - request.DiscountAmount;
            order.AmountPaid = request.AmountPaid;
            order.Change = Math.Max(0, request.AmountPaid - order.TotalAmount);

            await _uow.SaleOrders.AddAsync(order);
            foreach (var item in orderItems) await _uow.SaleOrderItems.AddAsync(item);

            // Update customer stats
            if (request.CustomerId.HasValue)
            {
                var customer = await _uow.Customers.GetByIdAsync(request.CustomerId.Value, tenantId);
                if (customer != null)
                {
                    customer.TotalSpent += order.TotalAmount;
                    customer.LoyaltyPoints += Math.Floor(order.TotalAmount / 10); // 1 point per 10 EGP
                    customer.UpdatedAt = DateTime.UtcNow;
                    customer.Version++;
                    _uow.Customers.Update(customer);
                }
            }

            await _uow.SaveChangesAsync();
            await _uow.CommitTransactionAsync();

            var dto = await MapSaleOrderDtoAsync(order, orderItems);
            return ApiResponse<SaleOrderDto>.Ok(dto, "Sale completed.");
        }
        catch (Exception ex)
        {
            await _uow.RollbackTransactionAsync();
            _logger.LogError(ex, "Sale creation failed for tenant {TenantId}", tenantId);
            return ApiResponse<SaleOrderDto>.Fail("Failed to process sale.");
        }
    }

    public async Task<ApiResponse<List<SaleOrderDto>>> GetSalesAsync(Guid branchId, DateTime? fromDate, DateTime? toDate)
    {
        await _featureFlags.EnsureEnabledAsync("POS");
        var from = fromDate ?? DateTime.UtcNow.Date;
        var to = toDate ?? DateTime.UtcNow.Date.AddDays(1);

        var sales = await _uow.SaleOrders.FindAsync(o =>
            o.BranchId == branchId &&
            !o.IsDeleted &&
            o.CreatedAt >= from &&
            o.CreatedAt < to);

        var dtos = new List<SaleOrderDto>();
        foreach (var o in sales.OrderByDescending(o => o.CreatedAt))
        {
            dtos.Add(await MapSaleOrderDtoAsync(o));
        }

        return ApiResponse<List<SaleOrderDto>>.Ok(dtos);
    }

    public async Task<ApiResponse<SaleOrderDto>> GetSaleByIdAsync(Guid saleId)
    {
        await _featureFlags.EnsureEnabledAsync("POS");
        var order = await _uow.SaleOrders.GetByIdAsync(saleId);
        if (order == null) return ApiResponse<SaleOrderDto>.Fail("Sale not found.");
        return ApiResponse<SaleOrderDto>.Ok(await MapSaleOrderDtoAsync(order));
    }

    public async Task<ApiResponse<SaleOrderDto>> RefundSaleAsync(Guid saleId, RefundRequest request)
    {
        await _featureFlags.EnsureEnabledAsync("POS");
        var tenantId = _tenantProvider.TenantId ?? throw new UnauthorizedAccessException();
        var processedBy = _tenantProvider.CurrentUserId ?? throw new UnauthorizedAccessException();

        var order = await _uow.SaleOrders.GetByIdAsync(saleId);
        if (order == null) return ApiResponse<SaleOrderDto>.Fail("Sale not found.");
        if (order.Status == SaleStatus.Refunded) return ApiResponse<SaleOrderDto>.Fail("Sale already fully refunded.");
        if (request.RefundAmount > order.TotalAmount) return ApiResponse<SaleOrderDto>.Fail("Refund amount exceeds sale total.");

        await _uow.BeginTransactionAsync();
        try
        {
            var refund = new SaleRefund
            {
                TenantId = tenantId,
                SaleOrderId = saleId,
                RefundAmount = request.RefundAmount,
                Reason = request.Reason,
                ProcessedBy = processedBy
            };
            await _uow.SaleRefunds.AddAsync(refund);

            order.Status = request.RefundAmount >= order.TotalAmount ? SaleStatus.Refunded : SaleStatus.PartialRefund;
            order.UpdatedAt = DateTime.UtcNow;
            order.Version++;
            _uow.SaleOrders.Update(order);

            await _uow.SaveChangesAsync();
            await _uow.CommitTransactionAsync();

            return ApiResponse<SaleOrderDto>.Ok(await MapSaleOrderDtoAsync(order), "Refund processed.");
        }
        catch
        {
            await _uow.RollbackTransactionAsync();
            return ApiResponse<SaleOrderDto>.Fail("Refund processing failed.");
        }
    }

    // ─── Helpers ───────────────────────────────────────────────

    private async Task<string> GenerateOrderNumberAsync(Guid tenantId)
    {
        var count = await _uow.SaleOrders.CountAsync(o => true);
        return $"ORD-{DateTime.UtcNow:yyyyMMdd}-{(count + 1):D5}";
    }

    private async Task<SaleOrderDto> MapSaleOrderDtoAsync(SaleOrder order, List<SaleOrderItem>? items = null)
    {
        items ??= (await _uow.SaleOrderItems.FindAsync(i => i.SaleOrderId == order.Id)).ToList();
        var branch = await _uow.Branches.GetByIdAsync(order.BranchId);
        ApplicationUser? cashier = await _uow.Users.GetByIdAsync(order.CashierId);
        Customer? customer = order.CustomerId.HasValue ? await _uow.Customers.GetByIdAsync(order.CustomerId.Value) : null;

        return new SaleOrderDto
        {
            Id = order.Id,
            OrderNumber = order.OrderNumber,
            BranchId = order.BranchId,
            BranchName = branch?.Name ?? "",
            CustomerId = order.CustomerId,
            CustomerName = customer?.Name,
            CashierName = cashier?.FullName ?? "",
            Status = order.Status,
            StatusName = order.Status.ToString(),
            PaymentMethod = order.PaymentMethod,
            SubTotal = order.SubTotal,
            VatAmount = order.VatAmount,
            DiscountAmount = order.DiscountAmount,
            TotalAmount = order.TotalAmount,
            AmountPaid = order.AmountPaid,
            Change = order.Change,
            IsOffline = order.IsOffline,
            CreatedAt = order.CreatedAt,
            UpdatedAt = order.UpdatedAt,
            Version = order.Version,
            TenantId = order.TenantId,
            Items = items.Select(i => new SaleOrderItemDto
            {
                ProductId = i.ProductId,
                ProductName = i.ProductName,
                ProductBarcode = i.ProductBarcode,
                Quantity = i.Quantity,
                UnitPrice = i.UnitPrice,
                VatRate = i.VatRate,
                VatAmount = i.VatAmount,
                DiscountAmount = i.DiscountAmount,
                LineTotal = i.LineTotal
            }).ToList()
        };
    }
}
