using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MesterX.Domain.Entities;
using MesterX.Domain.Interfaces;

namespace MesterX.Application.Services;

// ═══════════════════════════════════════════════════════════════════════════
// DTOs — Rental Module
// ═══════════════════════════════════════════════════════════════════════════

public record RentalAssetDto(
    Guid   Id,
    string AssetCode,
    string Name,
    AssetCategory Category,
    string? SubCategory,
    string? Brand,
    string? Size,
    string? Color,
    RentalPricingModel PricingModel,
    decimal RentalPricePerDay,
    decimal SalePrice,
    decimal DepositAmount,
    decimal LatePenaltyPerDay,
    int     MaxRentalDays,
    AssetStatus Status,
    AssetCondition Condition,
    string? Barcode,
    string? PrimaryImageUrl,
    List<string> ImageUrls,
    bool IsListedOnMarketplace,
    int  TotalRentalCount,
    decimal TotalRevenue
);

public record CreateRentalAssetRequest(
    string Name,
    AssetCategory Category,
    string? SubCategory,
    string? Brand,
    string? Size,
    string? Color,
    string? Description,
    RentalPricingModel PricingModel,
    decimal RentalPricePerDay,
    decimal RentalPricePerHour,
    decimal SalePrice,
    decimal DepositAmount,
    decimal PurchaseCost,
    decimal LatePenaltyPerDay,
    int     MaxRentalDays,
    string? Barcode,
    string? PrimaryImageUrl,
    bool    IsListedOnMarketplace
);

public record RentalBookingDto(
    Guid   Id,
    string BookingNumber,
    Guid   CustomerId,
    string CustomerName,
    string? CustomerPhone,
    BookingType   BookingType,
    BookingStatus Status,
    DateTime PickupDate,
    DateTime ReturnDueDate,
    DateTime? ActualReturnDate,
    DateTime? EventDate,
    string? EventLocation,
    decimal SubTotal,
    decimal DiscountAmount,
    decimal TotalAmount,
    decimal DepositRequired,
    decimal DepositPaid,
    decimal AmountPaid,
    decimal AmountDue,
    int     LateDays,
    decimal LatePenaltyTotal,
    bool    PenaltyWaived,
    bool    ContractSigned,
    List<RentalBookingItemDto> Items,
    List<RentalPaymentDto>     Payments,
    string? Notes
);

public record RentalBookingItemDto(
    Guid   AssetId,
    string AssetName,
    string AssetCode,
    int    Quantity,
    decimal UnitPrice,
    decimal DepositAmount,
    decimal LineTotal,
    bool    IsReturned,
    string? ConditionAtReturn
);

public record RentalPaymentDto(
    Guid   Id,
    decimal Amount,
    RentalPaymentMethod  PaymentMethod,
    RentalPaymentPurpose Purpose,
    DateTime PaymentDate,
    bool IsRefunded
);

public record CreateBookingRequest(
    Guid   CustomerId,
    BookingType BookingType,
    DateTime PickupDate,
    DateTime ReturnDueDate,
    DateTime? EventDate,
    string? EventLocation,
    string? Notes,
    List<CreateBookingItemRequest> Items,
    decimal DiscountAmount = 0
);

public record CreateBookingItemRequest(
    Guid    AssetId,
    int     Quantity,
    decimal? OverridePrice
);

public record AddRentalPaymentRequest(
    Guid   BookingId,
    decimal Amount,
    RentalPaymentMethod  PaymentMethod,
    RentalPaymentPurpose Purpose,
    string? ExternalTransactionId,
    string? Notes
);

// ── Availability ──────────────────────────────────────────────────────────

public record AssetAvailabilityDto(
    Guid AssetId,
    List<BlockedPeriodDto> BlockedPeriods
);

public record BlockedPeriodDto(DateTime Start, DateTime End, string Reason);

// ═══════════════════════════════════════════════════════════════════════════
// RENTAL ASSET SERVICE
// ═══════════════════════════════════════════════════════════════════════════

public interface IRentalAssetService
{
    Task<ApiResponse<RentalAssetDto>> CreateAsync(Guid tenantId, Guid userId, CreateRentalAssetRequest req, CancellationToken ct = default);
    Task<ApiResponse<RentalAssetDto>> GetByIdAsync(Guid tenantId, Guid id, CancellationToken ct = default);
    Task<ApiResponse<PagedResult<RentalAssetDto>>> ListAsync(Guid tenantId, int page, int pageSize, AssetCategory? category, AssetStatus? status, string? search, CancellationToken ct = default);
    Task<ApiResponse<bool>> UpdateStatusAsync(Guid tenantId, Guid id, AssetStatus newStatus, CancellationToken ct = default);
    Task<ApiResponse<AssetAvailabilityDto>> GetAvailabilityAsync(Guid tenantId, Guid id, DateTime from, DateTime to, CancellationToken ct = default);
    Task<ApiResponse<bool>> CheckAvailabilityAsync(Guid tenantId, Guid assetId, DateTime pickupDate, DateTime returnDate, Guid? excludeBookingId, CancellationToken ct = default);
}

public class RentalAssetService : IRentalAssetService
{
    private readonly IRentalUnitOfWork _uow;
    private readonly ILogger<RentalAssetService> _log;

    public RentalAssetService(IRentalUnitOfWork uow, ILogger<RentalAssetService> log)
    {
        _uow = uow;
        _log = log;
    }

    public async Task<ApiResponse<RentalAssetDto>> CreateAsync(
        Guid tenantId, Guid userId, CreateRentalAssetRequest req, CancellationToken ct = default)
    {
        // ── License check ─────────────────────────────────────────────────
        var tenant = await _uow.Tenants.GetByIdAsync(tenantId, ct);
        if (tenant is null) return Fail<RentalAssetDto>("Tenant not found");

        var modules = (TenantModules)tenant.ActiveModules;
        if (!modules.HasFlag(TenantModules.Rental))
            return Fail<RentalAssetDto>("RENTAL_MODULE_DISABLED", "الوحدة غير مفعّلة لهذا الحساب");

        // Optional: check MaxRentalAssets limit
        // var license = await _uow.Licenses.FirstOrDefaultAsync(l => l.TenantId == tenantId && l.Status == LicenseStatus.Active, ct);
        // var plan = license is not null ? await _uow.Plans.GetByIdAsync(license.PlanId, ct) : null;
        // if (plan?.MaxRentalAssets > 0) { ... count check ... }

        // ── Duplicate barcode check ───────────────────────────────────────
        if (!string.IsNullOrWhiteSpace(req.Barcode))
        {
            var exists = await _uow.RentalAssets.AnyAsync(
                a => a.TenantId == tenantId && a.Barcode == req.Barcode, ct);
            if (exists) return Fail<RentalAssetDto>("DUPLICATE_BARCODE", "الباركود مستخدم مسبقاً");
        }

        // ── Generate sequential asset code ────────────────────────────────
        var prefix = req.Category switch
        {
            AssetCategory.WeddingDress => "WD",
            AssetCategory.Suit         => "SU",
            AssetCategory.Accessory    => "AC",
            AssetCategory.Decoration   => "DC",
            AssetCategory.Electronics  => "EL",
            AssetCategory.Furniture    => "FN",
            _                          => "AS"
        };

        var count = await _uow.RentalAssets.CountAsync(
            a => a.TenantId == tenantId && a.Category == req.Category, ct);
        var code = $"{prefix}-{(count + 1):D4}";

        var asset = new RentalAsset
        {
            TenantId           = tenantId,
            AssetCode          = code,
            Name               = req.Name,
            Category           = req.Category,
            SubCategory        = req.SubCategory,
            Brand              = req.Brand,
            Size               = req.Size,
            Color              = req.Color,
            Description        = req.Description,
            PricingModel       = req.PricingModel,
            RentalPricePerDay  = req.RentalPricePerDay,
            RentalPricePerHour = req.RentalPricePerHour,
            SalePrice          = req.SalePrice,
            DepositAmount      = req.DepositAmount,
            PurchaseCost       = req.PurchaseCost,
            LatePenaltyPerDay  = req.LatePenaltyPerDay,
            MaxRentalDays      = req.MaxRentalDays,
            Barcode            = req.Barcode,
            PrimaryImageUrl    = req.PrimaryImageUrl,
            IsListedOnMarketplace = req.IsListedOnMarketplace,
            CreatedBy          = userId
        };

        _uow.RentalAssets.Add(asset);
        await _uow.SaveChangesAsync(ct);

        _log.LogInformation("RentalAsset {Code} created for tenant {TenantId}", code, tenantId);

        return Ok(MapAsset(asset, []));
    }

    public async Task<ApiResponse<RentalAssetDto>> GetByIdAsync(Guid tenantId, Guid id, CancellationToken ct = default)
    {
        var asset = await _uow.RentalAssets.Query()
            .Include(a => a.Images)
            .FirstOrDefaultAsync(a => a.Id == id && a.TenantId == tenantId, ct);

        if (asset is null) return Fail<RentalAssetDto>("NOT_FOUND", "الأصل غير موجود");

        var imageUrls = asset.Images.OrderBy(i => i.SortOrder).Select(i => i.ImageUrl).ToList();
        return Ok(MapAsset(asset, imageUrls));
    }

    public async Task<ApiResponse<PagedResult<RentalAssetDto>>> ListAsync(
        Guid tenantId, int page, int pageSize,
        AssetCategory? category, AssetStatus? status, string? search,
        CancellationToken ct = default)
    {
        var q = _uow.RentalAssets.Query()
            .Where(a => a.TenantId == tenantId)
            .Include(a => a.Images);

        if (category.HasValue) q = q.Where(a => a.Category == category);
        if (status.HasValue)   q = q.Where(a => a.Status   == status);
        if (!string.IsNullOrWhiteSpace(search))
            q = q.Where(a => a.Name.Contains(search) ||
                              a.AssetCode.Contains(search) ||
                              (a.Barcode != null && a.Barcode.Contains(search)));

        var total = await q.CountAsync(ct);
        var items = await q.OrderByDescending(a => a.CreatedAt)
                           .Skip((page - 1) * pageSize)
                           .Take(pageSize)
                           .ToListAsync(ct);

        var dtos = items.Select(a =>
            MapAsset(a, a.Images.OrderBy(i => i.SortOrder).Select(i => i.ImageUrl).ToList())
        ).ToList();

        return Ok(new PagedResult<RentalAssetDto>(dtos, total, page, pageSize,
            (int)Math.Ceiling(total / (double)pageSize)));
    }

    public async Task<ApiResponse<bool>> UpdateStatusAsync(
        Guid tenantId, Guid id, AssetStatus newStatus, CancellationToken ct = default)
    {
        var asset = await _uow.RentalAssets.FirstOrDefaultAsync(
            a => a.Id == id && a.TenantId == tenantId, ct);
        if (asset is null) return Fail<bool>("NOT_FOUND");

        asset.Status    = newStatus;
        asset.UpdatedAt = DateTime.UtcNow;
        _uow.RentalAssets.Update(asset);
        await _uow.SaveChangesAsync(ct);
        return Ok(true);
    }

    public async Task<ApiResponse<AssetAvailabilityDto>> GetAvailabilityAsync(
        Guid tenantId, Guid id, DateTime from, DateTime to, CancellationToken ct = default)
    {
        var bookings = await _uow.RentalBookingItems.Query()
            .Include(bi => bi.Booking)
            .Where(bi =>
                bi.AssetId == id &&
                bi.Booking.TenantId == tenantId &&
                bi.Booking.Status != BookingStatus.Cancelled &&
                bi.Booking.PickupDate < to &&
                bi.Booking.ReturnDueDate > from)
            .Select(bi => new BlockedPeriodDto(
                bi.Booking.PickupDate,
                bi.Booking.ReturnDueDate,
                $"محجوز — {bi.Booking.BookingNumber}"))
            .ToListAsync(ct);

        return Ok(new AssetAvailabilityDto(id, bookings));
    }

    public async Task<ApiResponse<bool>> CheckAvailabilityAsync(
        Guid tenantId, Guid assetId, DateTime pickupDate, DateTime returnDate,
        Guid? excludeBookingId, CancellationToken ct = default)
    {
        var conflict = await _uow.RentalBookingItems.Query()
            .Include(bi => bi.Booking)
            .AnyAsync(bi =>
                bi.AssetId == assetId &&
                bi.Booking.TenantId == tenantId &&
                bi.Booking.Status != BookingStatus.Cancelled &&
                (excludeBookingId == null || bi.BookingId != excludeBookingId) &&
                bi.Booking.PickupDate    < returnDate &&
                bi.Booking.ReturnDueDate > pickupDate,
            ct);

        return Ok(!conflict);
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private static RentalAssetDto MapAsset(RentalAsset a, List<string> imageUrls) => new(
        a.Id, a.AssetCode, a.Name, a.Category, a.SubCategory, a.Brand, a.Size, a.Color,
        a.PricingModel, a.RentalPricePerDay, a.SalePrice, a.DepositAmount,
        a.LatePenaltyPerDay, a.MaxRentalDays, a.Status, a.Condition,
        a.Barcode, a.PrimaryImageUrl, imageUrls,
        a.IsListedOnMarketplace, a.TotalRentalCount, a.TotalRevenue
    );

    private static ApiResponse<T> Ok<T>(T data)   => new(true,  Data: data);
    private static ApiResponse<T> Fail<T>(string msg) => new(false, msg);
    private static ApiResponse<T> Fail<T>(string code, string msg) => new(false, msg, ErrorCode: code);
}

// ═══════════════════════════════════════════════════════════════════════════
// RENTAL BOOKING SERVICE
// ═══════════════════════════════════════════════════════════════════════════

public interface IRentalBookingService
{
    Task<ApiResponse<RentalBookingDto>> CreateAsync(Guid tenantId, Guid userId, CreateBookingRequest req, CancellationToken ct = default);
    Task<ApiResponse<RentalBookingDto>> GetByIdAsync(Guid tenantId, Guid id, CancellationToken ct = default);
    Task<ApiResponse<PagedResult<RentalBookingDto>>> ListAsync(Guid tenantId, int page, int pageSize, BookingStatus? status, DateTime? from, DateTime? to, CancellationToken ct = default);
    Task<ApiResponse<bool>> ConfirmAsync(Guid tenantId, Guid bookingId, Guid userId, CancellationToken ct = default);
    Task<ApiResponse<bool>> MarkPickedUpAsync(Guid tenantId, Guid bookingId, Guid userId, CancellationToken ct = default);
    Task<ApiResponse<bool>> MarkReturnedAsync(Guid tenantId, Guid bookingId, Guid userId, CancellationToken ct = default);
    Task<ApiResponse<bool>> CancelAsync(Guid tenantId, Guid bookingId, Guid userId, CancellationToken ct = default);
    Task<ApiResponse<RentalPaymentDto>> AddPaymentAsync(Guid tenantId, Guid userId, AddRentalPaymentRequest req, CancellationToken ct = default);
    Task<ApiResponse<bool>> WaivePenaltyAsync(Guid tenantId, Guid bookingId, Guid userId, CancellationToken ct = default);
}

public class RentalBookingService : IRentalBookingService
{
    private readonly IRentalUnitOfWork _uow;
    private readonly IRentalAssetService _assets;
    private readonly ILogger<RentalBookingService> _log;

    public RentalBookingService(
        IRentalUnitOfWork uow,
        IRentalAssetService assets,
        ILogger<RentalBookingService> log)
    {
        _uow    = uow;
        _assets = assets;
        _log    = log;
    }

    public async Task<ApiResponse<RentalBookingDto>> CreateAsync(
        Guid tenantId, Guid userId, CreateBookingRequest req, CancellationToken ct = default)
    {
        // ── Validate dates ────────────────────────────────────────────────
        if (req.ReturnDueDate <= req.PickupDate)
            return Fail<RentalBookingDto>("INVALID_DATES", "تاريخ الإرجاع يجب أن يكون بعد تاريخ الاستلام");

        // ── Validate customer ─────────────────────────────────────────────
        var customer = await _uow.Customers.FirstOrDefaultAsync(
            c => c.Id == req.CustomerId && c.TenantId == tenantId, ct);
        if (customer is null)
            return Fail<RentalBookingDto>("CUSTOMER_NOT_FOUND");

        if (customer.IsBlacklisted)
            return Fail<RentalBookingDto>("CUSTOMER_BLACKLISTED", $"العميل ممنوع: {customer.BlacklistReason}");

        // ── Check availability for all assets ─────────────────────────────
        foreach (var item in req.Items)
        {
            var avail = await _assets.CheckAvailabilityAsync(
                tenantId, item.AssetId, req.PickupDate, req.ReturnDueDate, null, ct);
            if (!avail.Data)
                return Fail<RentalBookingDto>("ASSET_NOT_AVAILABLE",
                    $"الأصل {item.AssetId} غير متاح في هذه الفترة");
        }

        // ── Calculate totals ──────────────────────────────────────────────
        var rentalDays = (req.ReturnDueDate.Date - req.PickupDate.Date).Days;
        if (rentalDays < 1) rentalDays = 1;

        decimal subTotal        = 0m;
        decimal depositRequired = 0m;
        var     bookingItems    = new List<RentalBookingItem>();

        foreach (var itemReq in req.Items)
        {
            var asset = await _uow.RentalAssets.FirstOrDefaultAsync(
                a => a.Id == itemReq.AssetId && a.TenantId == tenantId, ct);
            if (asset is null)
                return Fail<RentalBookingDto>("ASSET_NOT_FOUND", $"الأصل {itemReq.AssetId} غير موجود");

            var unitPrice = itemReq.OverridePrice ?? (req.BookingType == BookingType.Sale
                ? asset.SalePrice
                : asset.PricingModel == RentalPricingModel.PerDay
                    ? asset.RentalPricePerDay * rentalDays
                    : asset.RentalPricePerDay);

            var lineTotal = unitPrice * itemReq.Quantity;
            subTotal        += lineTotal;
            depositRequired += asset.DepositAmount * itemReq.Quantity;

            bookingItems.Add(new RentalBookingItem
            {
                TenantId      = tenantId,
                AssetId       = asset.Id,
                Quantity       = itemReq.Quantity,
                UnitPrice     = unitPrice,
                DepositAmount = asset.DepositAmount,
                LineTotal     = lineTotal,
                CreatedBy     = userId
            });
        }

        // ── Tenant VAT rate ───────────────────────────────────────────────
        var tenant    = await _uow.Tenants.GetByIdAsync(tenantId, ct);
        var vatRate   = tenant?.VatRate ?? 0m;
        var afterDisc = subTotal - req.DiscountAmount;
        var vatAmt    = afterDisc * vatRate;
        var total     = afterDisc + vatAmt;

        // ── Generate booking number ───────────────────────────────────────
        var count  = await _uow.RentalBookings.CountAsync(b => b.TenantId == tenantId, ct);
        var bkNum  = $"BK-{DateTime.UtcNow.Year}{(count + 1):D4}";

        // ── Persist ───────────────────────────────────────────────────────
        await _uow.BeginTransactionAsync(ct);
        try
        {
            var booking = new RentalBooking
            {
                TenantId        = tenantId,
                BookingNumber   = bkNum,
                CustomerId      = req.CustomerId,
                BookingType     = req.BookingType,
                Status          = BookingStatus.Pending,
                PickupDate      = req.PickupDate,
                ReturnDueDate   = req.ReturnDueDate,
                EventDate       = req.EventDate,
                EventLocation   = req.EventLocation,
                SubTotal        = subTotal,
                DiscountAmount  = req.DiscountAmount,
                VatAmount       = vatAmt,
                TotalAmount     = total,
                DepositRequired = depositRequired,
                HandledByUserId = userId,
                Notes           = req.Notes,
                CreatedBy       = userId
            };

            _uow.RentalBookings.Add(booking);
            await _uow.SaveChangesAsync(ct);

            // Link items
            foreach (var bi in bookingItems)
            {
                bi.BookingId = booking.Id;
                _uow.RentalBookingItems.Add(bi);

                // Reserve asset
                var asset = await _uow.RentalAssets.GetByIdAsync(bi.AssetId, ct);
                if (asset is not null)
                {
                    asset.Status = AssetStatus.Reserved;
                    _uow.RentalAssets.Update(asset);
                }
            }

            await _uow.SaveChangesAsync(ct);
            await _uow.CommitTransactionAsync(ct);

            _log.LogInformation("Booking {Number} created for tenant {TenantId}", bkNum, tenantId);
            return Ok(await LoadBookingDtoAsync(tenantId, booking.Id, ct));
        }
        catch (Exception ex)
        {
            await _uow.RollbackTransactionAsync(ct);
            _log.LogError(ex, "Failed to create booking");
            return Fail<RentalBookingDto>("CREATE_FAILED", "فشل إنشاء الحجز");
        }
    }

    public async Task<ApiResponse<RentalBookingDto>> GetByIdAsync(
        Guid tenantId, Guid id, CancellationToken ct = default)
    {
        var dto = await LoadBookingDtoAsync(tenantId, id, ct);
        return dto.Id == Guid.Empty
            ? Fail<RentalBookingDto>("NOT_FOUND")
            : Ok(dto);
    }

    public async Task<ApiResponse<PagedResult<RentalBookingDto>>> ListAsync(
        Guid tenantId, int page, int pageSize,
        BookingStatus? status, DateTime? from, DateTime? to,
        CancellationToken ct = default)
    {
        var q = _uow.RentalBookings.Query()
            .Where(b => b.TenantId == tenantId);

        if (status.HasValue) q = q.Where(b => b.Status == status);
        if (from.HasValue)   q = q.Where(b => b.PickupDate >= from.Value);
        if (to.HasValue)     q = q.Where(b => b.PickupDate <= to.Value);

        var total = await q.CountAsync(ct);
        var ids   = await q.OrderByDescending(b => b.CreatedAt)
                            .Skip((page - 1) * pageSize)
                            .Take(pageSize)
                            .Select(b => b.Id)
                            .ToListAsync(ct);

        var dtos = new List<RentalBookingDto>();
        foreach (var id in ids)
            dtos.Add(await LoadBookingDtoAsync(tenantId, id, ct));

        return Ok(new PagedResult<RentalBookingDto>(dtos, total, page, pageSize,
            (int)Math.Ceiling(total / (double)pageSize)));
    }

    public async Task<ApiResponse<bool>> ConfirmAsync(
        Guid tenantId, Guid bookingId, Guid userId, CancellationToken ct = default)
        => await TransitionStatus(tenantId, bookingId, userId,
               BookingStatus.Pending, BookingStatus.Confirmed, ct);

    public async Task<ApiResponse<bool>> MarkPickedUpAsync(
        Guid tenantId, Guid bookingId, Guid userId, CancellationToken ct = default)
    {
        var result = await TransitionStatus(tenantId, bookingId, userId,
            BookingStatus.Confirmed, BookingStatus.PickedUp, ct);

        if (result.Data)
        {
            // Update assets to Rented
            var items = await _uow.RentalBookingItems.FindAsync(bi => bi.BookingId == bookingId, ct);
            foreach (var item in items)
            {
                var asset = await _uow.RentalAssets.GetByIdAsync(item.AssetId, ct);
                if (asset is not null)
                {
                    asset.Status      = AssetStatus.Rented;
                    asset.LastRentedAt = DateTime.UtcNow;
                    asset.TotalRentalCount++;
                    _uow.RentalAssets.Update(asset);
                }
            }
            await _uow.SaveChangesAsync(ct);
        }
        return result;
    }

    public async Task<ApiResponse<bool>> MarkReturnedAsync(
        Guid tenantId, Guid bookingId, Guid userId, CancellationToken ct = default)
    {
        var booking = await _uow.RentalBookings.FirstOrDefaultAsync(
            b => b.Id == bookingId && b.TenantId == tenantId, ct);
        if (booking is null) return Fail<bool>("NOT_FOUND");

        // Calculate late penalty
        var actualReturn = DateTime.UtcNow;
        var lateDays     = Math.Max(0, (actualReturn.Date - booking.ReturnDueDate.Date).Days);

        booking.Status           = BookingStatus.Returned;
        booking.ActualReturnDate = actualReturn;
        booking.LateDays         = lateDays;
        booking.UpdatedBy        = userId;
        booking.UpdatedAt        = DateTime.UtcNow;

        if (lateDays > 0 && !booking.PenaltyWaived)
        {
            // Sum penalty from all items
            var items = await _uow.RentalBookingItems.Query()
                .Include(bi => bi.Asset)
                .Where(bi => bi.BookingId == bookingId)
                .ToListAsync(ct);

            booking.LatePenaltyTotal = items.Sum(bi =>
                bi.Asset.LatePenaltyPerDay * lateDays * bi.Quantity);
        }

        _uow.RentalBookings.Update(booking);

        // Set assets back to Available
        var bookingItems = await _uow.RentalBookingItems.FindAsync(bi => bi.BookingId == bookingId, ct);
        foreach (var bi in bookingItems)
        {
            bi.IsReturned  = true;
            bi.ReturnedAt  = actualReturn;
            _uow.RentalBookingItems.Update(bi);

            var asset = await _uow.RentalAssets.GetByIdAsync(bi.AssetId, ct);
            if (asset is not null)
            {
                asset.Status      = AssetStatus.Available;
                asset.TotalRevenue += bi.LineTotal;
                _uow.RentalAssets.Update(asset);
            }
        }

        await _uow.SaveChangesAsync(ct);
        return Ok(true);
    }

    public async Task<ApiResponse<bool>> CancelAsync(
        Guid tenantId, Guid bookingId, Guid userId, CancellationToken ct = default)
    {
        var booking = await _uow.RentalBookings.FirstOrDefaultAsync(
            b => b.Id == bookingId && b.TenantId == tenantId, ct);
        if (booking is null) return Fail<bool>("NOT_FOUND");

        if (booking.Status is BookingStatus.PickedUp or BookingStatus.Returned)
            return Fail<bool>("CANNOT_CANCEL", "لا يمكن إلغاء حجز تم استلامه");

        booking.Status    = BookingStatus.Cancelled;
        booking.UpdatedBy = userId;
        booking.UpdatedAt = DateTime.UtcNow;
        _uow.RentalBookings.Update(booking);

        // Release reserved assets
        var items = await _uow.RentalBookingItems.FindAsync(bi => bi.BookingId == bookingId, ct);
        foreach (var bi in items)
        {
            var asset = await _uow.RentalAssets.GetByIdAsync(bi.AssetId, ct);
            if (asset is not null && asset.Status == AssetStatus.Reserved)
            {
                asset.Status = AssetStatus.Available;
                _uow.RentalAssets.Update(asset);
            }
        }

        await _uow.SaveChangesAsync(ct);
        return Ok(true);
    }

    public async Task<ApiResponse<RentalPaymentDto>> AddPaymentAsync(
        Guid tenantId, Guid userId, AddRentalPaymentRequest req, CancellationToken ct = default)
    {
        var booking = await _uow.RentalBookings.FirstOrDefaultAsync(
            b => b.Id == req.BookingId && b.TenantId == tenantId, ct);
        if (booking is null) return Fail<RentalPaymentDto>("BOOKING_NOT_FOUND");

        var payment = new RentalPayment
        {
            TenantId              = tenantId,
            BookingId             = req.BookingId,
            Amount                = req.Amount,
            PaymentMethod         = req.PaymentMethod,
            Purpose               = req.Purpose,
            ExternalTransactionId = req.ExternalTransactionId,
            Notes                 = req.Notes,
            RecordedBy            = userId,
            CreatedBy             = userId
        };

        _uow.RentalPayments.Add(payment);

        // Update booking totals
        if (req.Purpose == RentalPaymentPurpose.Deposit)
            booking.DepositPaid += req.Amount;
        else
            booking.AmountPaid += req.Amount;

        booking.UpdatedAt = DateTime.UtcNow;
        _uow.RentalBookings.Update(booking);

        await _uow.SaveChangesAsync(ct);

        return Ok(new RentalPaymentDto(
            payment.Id, payment.Amount, payment.PaymentMethod,
            payment.Purpose, payment.PaymentDate, payment.IsRefunded));
    }

    public async Task<ApiResponse<bool>> WaivePenaltyAsync(
        Guid tenantId, Guid bookingId, Guid userId, CancellationToken ct = default)
    {
        var booking = await _uow.RentalBookings.FirstOrDefaultAsync(
            b => b.Id == bookingId && b.TenantId == tenantId, ct);
        if (booking is null) return Fail<bool>("NOT_FOUND");

        booking.PenaltyWaived   = true;
        booking.PenaltyWaivedBy = userId;
        booking.LatePenaltyTotal = 0m;
        booking.UpdatedBy       = userId;
        booking.UpdatedAt       = DateTime.UtcNow;

        _uow.RentalBookings.Update(booking);
        await _uow.SaveChangesAsync(ct);
        return Ok(true);
    }

    // ── Internal helpers ──────────────────────────────────────────────────

    private async Task<RentalBookingDto> LoadBookingDtoAsync(
        Guid tenantId, Guid bookingId, CancellationToken ct)
    {
        var booking = await _uow.RentalBookings.Query()
            .Include(b => b.Customer)
            .Include(b => b.Items).ThenInclude(i => i.Asset)
            .Include(b => b.Payments)
            .FirstOrDefaultAsync(b => b.Id == bookingId && b.TenantId == tenantId, ct);

        if (booking is null) return new RentalBookingDto(
            Guid.Empty, "", Guid.Empty, "", null,
            BookingType.Rental, BookingStatus.Pending,
            DateTime.MinValue, DateTime.MinValue, null, null, null,
            0,0,0,0,0,0,0,0,0,false,false,[],[],null);

        return new RentalBookingDto(
            booking.Id, booking.BookingNumber,
            booking.CustomerId, booking.Customer.Name, booking.Customer.Phone,
            booking.BookingType, booking.Status,
            booking.PickupDate, booking.ReturnDueDate,
            booking.ActualReturnDate, booking.EventDate, booking.EventLocation,
            booking.SubTotal, booking.DiscountAmount, booking.TotalAmount,
            booking.DepositRequired, booking.DepositPaid, booking.AmountPaid,
            booking.AmountDue,
            booking.LateDays, booking.LatePenaltyTotal, booking.PenaltyWaived,
            booking.ContractSigned,
            booking.Items.Select(i => new RentalBookingItemDto(
                i.AssetId, i.Asset.Name, i.Asset.AssetCode,
                i.Quantity, i.UnitPrice, i.DepositAmount, i.LineTotal,
                i.IsReturned, i.ConditionAtReturn)).ToList(),
            booking.Payments.Select(p => new RentalPaymentDto(
                p.Id, p.Amount, p.PaymentMethod, p.Purpose,
                p.PaymentDate, p.IsRefunded)).ToList(),
            booking.Notes
        );
    }

    private async Task<ApiResponse<bool>> TransitionStatus(
        Guid tenantId, Guid bookingId, Guid userId,
        BookingStatus from, BookingStatus to, CancellationToken ct)
    {
        var booking = await _uow.RentalBookings.FirstOrDefaultAsync(
            b => b.Id == bookingId && b.TenantId == tenantId, ct);
        if (booking is null) return Fail<bool>("NOT_FOUND");
        if (booking.Status != from)
            return Fail<bool>("INVALID_STATE",
                $"الحجز في حالة {booking.Status} وليس {from}");

        booking.Status    = to;
        booking.UpdatedBy = userId;
        booking.UpdatedAt = DateTime.UtcNow;
        _uow.RentalBookings.Update(booking);
        await _uow.SaveChangesAsync(ct);
        return Ok(true);
    }

    private static ApiResponse<T> Ok<T>(T data)                    => new(true,  Data: data);
    private static ApiResponse<T> Fail<T>(string msg)              => new(false, msg);
    private static ApiResponse<T> Fail<T>(string code, string msg) => new(false, msg, ErrorCode: code);
}

// ═══════════════════════════════════════════════════════════════════════════
// MODULE ACTIVATION SERVICE
// ═══════════════════════════════════════════════════════════════════════════
// يُستدعى من Platform Admin لتفعيل/إيقاف وحدة الإيجار لتينانت معين

public interface IRentalModuleService
{
    Task<ApiResponse<bool>> ActivateRentalModuleAsync(Guid tenantId, Guid adminUserId, CancellationToken ct = default);
    Task<ApiResponse<bool>> DeactivateRentalModuleAsync(Guid tenantId, Guid adminUserId, CancellationToken ct = default);
    Task<bool> IsRentalActiveAsync(Guid tenantId, CancellationToken ct = default);
}

public class RentalModuleService : IRentalModuleService
{
    private readonly IRentalUnitOfWork _uow;

    public RentalModuleService(IRentalUnitOfWork uow) => _uow = uow;

    public async Task<ApiResponse<bool>> ActivateRentalModuleAsync(
        Guid tenantId, Guid adminUserId, CancellationToken ct = default)
    {
        var tenant = await _uow.Tenants.GetByIdAsync(tenantId, ct);
        if (tenant is null) return new(false, "Tenant not found");

        var modules = (TenantModules)tenant.ActiveModules;
        modules |= TenantModules.Rental;
        tenant.ActiveModules = (int)modules;
        tenant.UpdatedBy     = adminUserId;
        tenant.UpdatedAt     = DateTime.UtcNow;
        _uow.Tenants.Update(tenant);
        await _uow.SaveChangesAsync(ct);
        return new(true, Data: true);
    }

    public async Task<ApiResponse<bool>> DeactivateRentalModuleAsync(
        Guid tenantId, Guid adminUserId, CancellationToken ct = default)
    {
        var tenant = await _uow.Tenants.GetByIdAsync(tenantId, ct);
        if (tenant is null) return new(false, "Tenant not found");

        var modules = (TenantModules)tenant.ActiveModules;
        modules &= ~TenantModules.Rental;
        tenant.ActiveModules = (int)modules;
        tenant.UpdatedBy     = adminUserId;
        tenant.UpdatedAt     = DateTime.UtcNow;
        _uow.Tenants.Update(tenant);
        await _uow.SaveChangesAsync(ct);
        return new(true, Data: true);
    }

    public async Task<bool> IsRentalActiveAsync(Guid tenantId, CancellationToken ct = default)
    {
        var tenant = await _uow.Tenants.GetByIdAsync(tenantId, ct);
        if (tenant is null) return false;
        return ((TenantModules)tenant.ActiveModules).HasFlag(TenantModules.Rental);
    }
}
