using System.Threading.Tasks;

namespace MesterX.Application.Services;

public interface IFeatureFlagService
{
    Task<bool> IsEnabledAsync(string featureKey);
    Task EnsureEnabledAsync(string featureKey);
}
