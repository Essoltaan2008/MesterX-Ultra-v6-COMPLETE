using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MesterX.Application.DTOs;
using MesterX.Domain.Entities;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace MesterX.Application.Services;

public interface IVendorService
{
    Task<ApiResponse<VendorDto>> GetVendorAsync(Guid vendorId);
    Task<ApiResponse<List<VendorDto>>> SearchVendorsAsync(Guid tenantId, VendorType? type, string? search, int page, int pageSize);
    Task<ApiResponse<VendorDetailDto>> GetVendorDetailAsync(Guid vendorId);
}

public class VendorAppService : IVendorService
{
    private readonly IUnitOfWork _uow;
    private readonly ILogger<VendorAppService> _logger;

    public VendorAppService(IUnitOfWork uow, ILogger<VendorAppService> logger)
    {
        _uow = uow;
        _logger = logger;
    }

    public async Task<ApiResponse<VendorDto>> GetVendorAsync(Guid vendorId)
    {
        try
        {
            var vendor = await _uow.Vendors.GetByIdAsync(vendorId);
            if (vendor == null || vendor.IsDeleted) return ApiResponse<VendorDto>.Fail("Vendor not found.");

            return ApiResponse<VendorDto>.Ok(MapToDto(vendor));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "GetVendor failed");
            return ApiResponse<VendorDto>.Fail(ex.Message);
        }
    }

    public async Task<ApiResponse<List<VendorDto>>> SearchVendorsAsync(Guid tenantId, VendorType? type, string? search, int page, int pageSize)
    {
        try
        {
            var vendors = await _uow.Vendors.FindAsync(v =>
                v.TenantId == tenantId && !v.IsDeleted && v.IsActive && v.IsVerified &&
                (type == null || v.VendorType == type) &&
                (string.IsNullOrEmpty(search) || v.BusinessName.Contains(search))
            );

            var result = vendors
                .OrderByDescending(v => v.Rating)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(MapToDto)
                .ToList();

            return ApiResponse<List<VendorDto>>.Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "SearchVendors failed");
            return ApiResponse<List<VendorDto>>.Fail(ex.Message);
        }
    }

    public async Task<ApiResponse<VendorDetailDto>> GetVendorDetailAsync(Guid vendorId)
    {
        try
        {
            var vendor = await _uow.Vendors.GetByIdAsync(vendorId);
            if (vendor == null || vendor.IsDeleted) return ApiResponse<VendorDetailDto>.Fail("Vendor not found.");

            var services = await _uow.VendorServices.FindAsync(s => s.VendorId == vendorId && !s.IsDeleted && s.IsActive);
            var reviews = await _uow.VendorReviews.FindAsync(r => r.VendorId == vendorId && !r.IsDeleted);

            var detail = new VendorDetailDto
            {
                Id = vendor.Id,
                BusinessName = vendor.BusinessName,
                Bio = vendor.Bio ?? "",
                Rating = vendor.Rating,
                ReviewCount = vendor.ReviewCount,
                LogoUrl = vendor.LogoUrl,
                CoverImageUrl = vendor.CoverImageUrl,
                Address = vendor.Address,
                City = vendor.City,
                Latitude = vendor.Latitude,
                Longitude = vendor.Longitude,
                Services = services.Select(s => new VendorServiceDto
                {
                    Id = s.Id,
                    Name = s.Name,
                    Description = s.Description ?? "",
                    BasePrice = s.BasePrice,
                    ImageUrl = s.ImageUrl
                }).ToList(),
                Reviews = reviews.Select(r => new VendorReviewDto
                {
                    Id = r.Id,
                    CustomerName = "Customer",
                    Rating = r.Rating,
                    Review = r.Review,
                    CreatedAt = r.CreatedAt
                }).ToList()
            };

            return ApiResponse<VendorDetailDto>.Ok(detail);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "GetVendorDetail failed");
            return ApiResponse<VendorDetailDto>.Fail(ex.Message);
        }
    }

    private VendorDto MapToDto(Vendor v) => new VendorDto
    {
        Id = v.Id,
        BusinessName = v.BusinessName,
        VendorType = v.VendorType.ToString(),
        Rating = v.Rating,
        ReviewCount = v.ReviewCount,
        LogoUrl = v.LogoUrl,
        Address = v.Address,
        IsVerified = v.IsVerified,
        IsActive = v.IsActive,
        CreatedAt = v.CreatedAt
    };
}

public interface IBookingService
{
    Task<ApiResponse<BookingDto>> CreateBookingAsync(Guid tenantId, Guid customerId, CreateBookingRequest request);
    Task<ApiResponse<List<BookingDto>>> GetCustomerBookingsAsync(Guid customerId);
    Task<ApiResponse<BookingDto>> GetBookingAsync(Guid bookingId);
}

public class BookingAppService : IBookingService
{
    private readonly IUnitOfWork _uow;
    private readonly ILogger<BookingAppService> _logger;

    public BookingAppService(IUnitOfWork uow, ILogger<BookingAppService> logger)
    {
        _uow = uow;
        _logger = logger;
    }

    public async Task<ApiResponse<BookingDto>> CreateBookingAsync(Guid tenantId, Guid customerId, CreateBookingRequest request)
    {
        try
        {
            var vendor = await _uow.Vendors.GetByIdAsync(request.VendorId);
            if (vendor == null) return ApiResponse<BookingDto>.Fail("Vendor not found.");

            var booking = new Booking
            {
                TenantId = tenantId,
                BookingNumber = $"BK-{DateTime.UtcNow:yyyyMMddHHmm}-{new Random().Next(1000, 9999)}",
                VendorId = request.VendorId,
                CustomerId = customerId,
                EventDate = request.EventDate,
                EstimatedGuests = request.EstimatedGuests,
                Status = BookingStatus.Pending,
                Notes = request.Notes
            };

            decimal total = 0;
            var services = new List<MesterX.Domain.Entities.BookingService>();

            foreach (var sReq in request.Services)
            {
                var vService = await _uow.VendorServices.GetByIdAsync(sReq.VendorServiceId);
                if (vService != null)
                {
                    total += vService.BasePrice * sReq.Quantity;
                    services.Add(new MesterX.Domain.Entities.BookingService
                    {
                        TenantId = tenantId,
                        VendorServiceId = vService.Id,
                        ServiceName = vService.Name,
                        ServicePrice = vService.BasePrice,
                        Quantity = sReq.Quantity,
                        LineTotal = vService.BasePrice * sReq.Quantity
                    });
                }
            }

            booking.TotalPrice = total;
            booking.RemainingAmount = total;

            await _uow.BeginTransactionAsync();
            await _uow.Bookings.AddAsync(booking);
            await _uow.SaveChangesAsync();

            foreach (var s in services)
            {
                s.BookingId = booking.Id;
                await _uow.BookingServices.AddAsync(s);
            }

            await _uow.SaveChangesAsync();
            await _uow.CommitTransactionAsync();

            return ApiResponse<BookingDto>.Ok(MapToDto(booking));
        }
        catch (Exception ex)
        {
            await _uow.RollbackTransactionAsync();
            _logger.LogError(ex, "CreateBooking failed");
            return ApiResponse<BookingDto>.Fail(ex.Message);
        }
    }

    public async Task<ApiResponse<List<BookingDto>>> GetCustomerBookingsAsync(Guid customerId)
    {
        var bookings = await _uow.Bookings.Query()
            .Include(b => b.Vendor)
            .Where(b => b.CustomerId == customerId && !b.IsDeleted)
            .ToListAsync();

        return ApiResponse<List<BookingDto>>.Ok(bookings.Select(MapToDto).ToList());
    }

    public async Task<ApiResponse<BookingDto>> GetBookingAsync(Guid bookingId)
    {
        var booking = await _uow.Bookings.Query()
            .Include(b => b.Vendor)
            .Include(b => b.Services)
            .FirstOrDefaultAsync(b => b.Id == bookingId);

        if (booking == null) return ApiResponse<BookingDto>.Fail("Booking not found.");
        return ApiResponse<BookingDto>.Ok(MapToDto(booking));
    }

    private BookingDto MapToDto(Booking b) => new BookingDto
    {
        Id = b.Id,
        BookingNumber = b.BookingNumber,
        VendorId = b.VendorId,
        VendorName = b.Vendor?.BusinessName ?? "Unknown",
        EventDate = b.EventDate,
        Status = b.Status.ToString(),
        TotalPrice = b.TotalPrice,
        DepositAmount = b.DepositAmount,
        RemainingAmount = b.RemainingAmount,
        CreatedAt = b.CreatedAt
    };
}
