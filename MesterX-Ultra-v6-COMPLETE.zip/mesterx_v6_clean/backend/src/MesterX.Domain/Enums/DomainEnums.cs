namespace MesterX.Domain.Enums;

public enum TenantStatus : short { Trial = 0, Active = 1, Suspended = 2, Cancelled = 3 }
public enum BillingCycle : short { Monthly = 0, Annual = 1 }
public enum SubscriptionStatus : short { Trial = 0, Active = 1, PastDue = 2, Cancelled = 3 }
public enum OrderStatus : short { Pending = 0, Confirmed = 1, Preparing = 2, ReadyForPickup = 3, OutForDelivery = 4, Delivered = 5, Cancelled = 6, Refunded = 7 }
public enum PurchaseOrderStatus : short { Draft = 0, Sent = 1, Received = 2, PartiallyReceived = 3, Cancelled = 4 }
public enum DeliveryStatus : short { Pending = 0, AssignedToDriver = 1, PickedUp = 2, InTransit = 3, Delivered = 4, FailedDelivery = 5, Returned = 6 }
public enum DriverStatus : short { Offline = 0, Online = 1, Busy = 2, Suspended = 3 }
public enum ExpenseCategory : short { Rent = 0, Salaries = 1, Utilities = 2, Marketing = 3, Supplies = 4, Maintenance = 5, Delivery = 6, Other = 7 }
public enum SupplierStatus : short { Active = 0, Inactive = 1, Blacklisted = 2 }
public enum CustomerSegment : short { New = 0, Regular = 1, VIP = 2, Inactive = 3 }
public enum SyncOperation : short { Insert = 0, Update = 1, Delete = 2 }
