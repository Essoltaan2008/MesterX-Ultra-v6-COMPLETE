using System.Linq.Expressions;
using MesterX.Domain.Entities.Audit;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.Marketplace;
using MesterX.Domain.Entities.Platform;
using MesterX.Domain.Entities.Pos;
using MesterX.Domain.Entities.Sync;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Interfaces;

// ════════════════════════════════════════════════════════════════════════════
// Generic Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IRepository<T> where T : class
{
    Task<T?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<T?> GetByIdAsync(Guid id, Guid tenantId, CancellationToken ct = default);
    Task<IEnumerable<T>> GetAllAsync(Guid tenantId, CancellationToken ct = default);
    Task<IEnumerable<T>> FindAsync(Expression<Func<T, bool>> predicate, CancellationToken ct = default);
    Task<T?> FirstOrDefaultAsync(Expression<Func<T, bool>> predicate, CancellationToken ct = default);
    Task<bool> AnyAsync(Expression<Func<T, bool>> predicate, CancellationToken ct = default);
    Task<int> CountAsync(Expression<Func<T, bool>> predicate, CancellationToken ct = default);
    IQueryable<T> Query();
    Task AddAsync(T entity, CancellationToken ct = default);
    Task AddRangeAsync(IEnumerable<T> entities, CancellationToken ct = default);
    void Update(T entity);
    void SoftDelete(T entity, Guid deletedBy);
    void Remove(T entity);
}

// ════════════════════════════════════════════════════════════════════════════
// Unit of Work — كل الـ repositories في مكان واحد
// ════════════════════════════════════════════════════════════════════════════
public interface IUnitOfWork : IDisposable, IAsyncDisposable
{
    // ── Core ──────────────────────────────────────────────────────────────
    IRepository<Tenant>               Tenants              { get; }
    IRepository<Branch>               Branches             { get; }
    IRepository<ApplicationUser>      Users                { get; }
    IRepository<ApplicationRole>      Roles                { get; }
    IRepository<ApplicationPermission> Permissions         { get; }
    IRepository<FeatureFlag>          FeatureFlags         { get; }
    IRepository<RefreshToken>         RefreshTokens        { get; }
    IRepository<Category>             Categories           { get; }
    IRepository<Customer>             Customers            { get; }
    IRepository<Supplier>             Suppliers            { get; }
    IRepository<Expense>              Expenses             { get; }

    // ── Licensing ─────────────────────────────────────────────────────────
    IRepository<License>              Licenses             { get; }
    IRepository<DeviceRegistration>   DeviceRegistrations  { get; }

    // ── POS / Inventory ───────────────────────────────────────────────────
    IRepository<Product>              Products             { get; }
    IRepository<StockItem>            StockItems           { get; }
    IRepository<StockMovement>        StockMovements       { get; }
    IRepository<SaleOrder>            SaleOrders           { get; }
    IRepository<SaleOrderItem>        SaleOrderItems       { get; }
    IRepository<SaleRefund>           SaleRefunds          { get; }
    IRepository<Payment>              Payments             { get; }
    IRepository<PurchaseOrder>        PurchaseOrders       { get; }
    IRepository<PurchaseOrderItem>    PurchaseOrderItems   { get; }

    // ── Marketplace / Vendor ──────────────────────────────────────────────
    IRepository<Vendor>               Vendors              { get; }
    IRepository<VendorCategory>       VendorCategories     { get; }
    IRepository<VendorService>        VendorServices       { get; }
    IRepository<VendorAvailability>   VendorAvailabilities { get; }
    IRepository<Booking>              Bookings             { get; }
    IRepository<BookingPayment>       BookingPayments      { get; }
    IRepository<VendorReview>         VendorReviews        { get; }
    IRepository<VendorPayment>        VendorPayments       { get; }

    // ── Sync & Audit ──────────────────────────────────────────────────────
    IRepository<SyncQueue>            SyncQueue            { get; }
    IRepository<SyncLog>              SyncLogs             { get; }
    IRepository<AuditLog>             AuditLogs            { get; }
    IRepository<PlatformConfig>       PlatformConfigs      { get; }

    // ── Transactions ──────────────────────────────────────────────────────
    Task<int> SaveChangesAsync(CancellationToken ct = default);
    Task BeginTransactionAsync(CancellationToken ct = default);
    Task CommitTransactionAsync(CancellationToken ct = default);
    Task RollbackTransactionAsync(CancellationToken ct = default);
}

// ════════════════════════════════════════════════════════════════════════════
// Supporting Interfaces
// ════════════════════════════════════════════════════════════════════════════
public interface ICurrentUserService
{
    Guid? UserId        { get; }
    Guid? TenantId      { get; }
    string? Email       { get; }
    string? Role        { get; }
    bool IsAuthenticated { get; }
    bool IsInRole(string role);
}

public interface IDateTimeService
{
    DateTime UtcNow   { get; }
    DateTime CairoNow { get; }
    DateOnly Today    { get; }
}

public interface IAuditService
{
    Task LogAsync(
        Guid tenantId,
        Guid? userId,
        AuditAction action,
        string entityType,
        Guid? entityId          = null,
        string? oldValues       = null,
        string? newValues       = null,
        bool isSuccess          = true,
        string? errorMessage    = null,
        CancellationToken ct    = default);
}
