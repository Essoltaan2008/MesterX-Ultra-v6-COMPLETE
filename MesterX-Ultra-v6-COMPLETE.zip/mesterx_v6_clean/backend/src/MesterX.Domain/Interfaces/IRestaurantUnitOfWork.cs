using System.Linq.Expressions;
using MesterX.Domain.Entities;
using MesterX.Domain.Entities.Restaurant;
using MesterX.Domain.Entities.Core;


namespace MesterX.Domain.Interfaces;

// ─── يُضاف لـ IRepository<T> الموجود — مفيش تغيير ─────────────────────────

/// <summary>
/// Unit of Work منفصل خاص بالـ Restaurant Module.
/// يشارك نفس الـ DbContext مع الـ IUnitOfWork الأصلي
/// لكنه مستقل تماماً — لا تعديل على IUnitOfWork الأصلي.
/// </summary>
public interface IRestaurantUnitOfWork : IDisposable
{
    // ── Menu ──────────────────────────────────────────────────────────────
    IRepository<RestaurantCategory>    Categories      { get; }
    IRepository<RestaurantMenuItem>    MenuItems       { get; }
    IRepository<MenuItemVariant>       Variants        { get; }
    IRepository<MenuModifierGroup>     ModifierGroups  { get; }
    IRepository<MenuModifier>          Modifiers       { get; }
    IRepository<BranchMenuOverride>    MenuOverrides   { get; }
    IRepository<BranchItemAvailability> ItemAvailability { get; }

    // ── Floor & Tables ────────────────────────────────────────────────────
    IRepository<FloorPlan>           FloorPlans    { get; }
    IRepository<RestaurantTable>     Tables        { get; }
    IRepository<TableSession>        Sessions      { get; }
    IRepository<SessionPayment>      Payments      { get; }
    IRepository<TableReservation>    Reservations  { get; }

    // ── Orders ────────────────────────────────────────────────────────────
    IRepository<DineInOrder>         Orders        { get; }
    IRepository<DineInOrderItem>     OrderItems    { get; }
    IRepository<OrderItemModifier>   OrderModifiers{ get; }

    // ── Kitchen ───────────────────────────────────────────────────────────
    IRepository<KitchenStation>      Stations       { get; }
    IRepository<KitchenTicket>       Tickets        { get; }
    IRepository<KitchenTicketItem>   TicketItems    { get; }

    // ── Shared (من الـ Core — للقراءة فقط داخل الـ Module) ───────────────
    IRepository<Branch>              Branches       { get; }
    IRepository<Tenant>              Tenants        { get; }

    // ── Persistence ───────────────────────────────────────────────────────
    Task<int> SaveChangesAsync(CancellationToken ct = default);
    Task BeginTransactionAsync(CancellationToken ct = default);
    Task CommitTransactionAsync(CancellationToken ct = default);
    Task RollbackTransactionAsync(CancellationToken ct = default);
}
