// ═══════════════════════════════════════════════════════════════════════════
// PATCHES لـ IRepository.cs و UnitOfWork.cs
// ═══════════════════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────────────────
// [A] في IUnitOfWork — أضف بعد آخر سطر IRepository:
// ─────────────────────────────────────────────────────────────────────────
using MesterX.Domain.Entities;
using MesterX.Domain.Interfaces;

namespace MesterX.Domain.Interfaces;

// Extension interface — الـ IoC Container سيحقن IRentalUnitOfWork منفصلاً
// هذا يتيح للـ RentalService الوصول لـ Repos الإيجار دون تعديل IUnitOfWork الأصلي.
// فائدة: لو مش عايز تشغّل Rental، ما تحقنش IRentalUnitOfWork — صفر تأثير.

public interface IRentalUnitOfWork : IDisposable
{
    // ── Rental Repositories ───────────────────────────────────────────────
    IRepository<RentalAsset>        RentalAssets        { get; }
    IRepository<RentalAssetImage>   RentalAssetImages   { get; }
    IRepository<RentalBooking>      RentalBookings      { get; }
    IRepository<RentalBookingItem>  RentalBookingItems  { get; }
    IRepository<RentalPayment>      RentalPayments      { get; }
    IRepository<DamageReport>       DamageReports       { get; }
    IRepository<MaintenanceLog>     MaintenanceLogs     { get; }
    IRepository<MarketplaceListing> MarketplaceListings { get; }

    // ── Shared (read-only access) ─────────────────────────────────────────
    // نحتاج قراءة Tenants/Customers/Users/Plans لكن الـ write يمر عبر IUnitOfWork
    IRepository<Tenant>   Tenants   { get; }
    IRepository<Customer> Customers { get; }
    IRepository<User>     Users     { get; }
    IRepository<Plan>     Plans     { get; }
    IRepository<License>  Licenses  { get; }
    IRepository<AuditLog> AuditLogs { get; }

    Task<int> SaveChangesAsync(CancellationToken ct = default);
    Task BeginTransactionAsync(CancellationToken ct = default);
    Task CommitTransactionAsync(CancellationToken ct = default);
    Task RollbackTransactionAsync(CancellationToken ct = default);
}
