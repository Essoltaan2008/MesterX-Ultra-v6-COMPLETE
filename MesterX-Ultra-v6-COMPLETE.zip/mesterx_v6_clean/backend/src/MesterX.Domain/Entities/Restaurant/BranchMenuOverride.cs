using System;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;

namespace MesterX.Domain.Entities.Restaurant;

public class BranchMenuOverride : BaseEntity
{
    public Guid BranchId { get; set; }
    public virtual Branch Branch { get; set; } = null!;

    public Guid MenuItemId { get; set; }
    public virtual RestaurantMenuItem MenuItem { get; set; } = null!;

    public decimal? OverridePrice { get; set; }
    public bool IsHiddenInBranch { get; set; }
}
