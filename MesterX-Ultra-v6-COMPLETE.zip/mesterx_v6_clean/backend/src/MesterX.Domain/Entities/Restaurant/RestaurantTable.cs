using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;

namespace MesterX.Domain.Entities.Restaurant;

public class RestaurantTable : BaseEntity
{
    public Guid BranchId { get; set; }
    public virtual Branch Branch { get; set; } = null!;

    public Guid FloorPlanId { get; set; }
    public virtual FloorPlan FloorPlan { get; set; } = null!;

    public string TableNumber { get; set; } = string.Empty;
    public int Capacity { get; set; } = 4;
    public TableShape Shape { get; set; } = TableShape.Square;
    public TableStatus Status { get; set; } = TableStatus.Available;

    public int PosX { get; set; }
    public int PosY { get; set; }
    public int Width { get; set; } = 80;
    public int Height { get; set; } = 80;
    public int Rotation { get; set; }

    public bool IsActive { get; set; } = true;

    public string? QrToken { get; set; }
    public string? QrCodeUrl { get; set; }

    public virtual ICollection<TableSession> Sessions { get; set; } = [];
    public virtual ICollection<TableReservation> Reservations { get; set; } = [];
}
