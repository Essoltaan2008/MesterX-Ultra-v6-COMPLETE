using System;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Restaurant;

public class KitchenTicketItem : BaseEntity
{
    public Guid KitchenTicketId { get; set; }
    public virtual KitchenTicket Ticket { get; set; } = null!;

    public Guid OrderItemId { get; set; }
    public virtual DineInOrderItem OrderItem { get; set; } = null!;

    public string ItemName { get; set; } = string.Empty;
    public int Quantity { get; set; } = 1;

    public string? Modifiers { get; set; }
    public string? SpecialInstructions { get; set; }

    public OrderItemStatus Status { get; set; } = OrderItemStatus.Pending;
    public DateTime? DoneAt { get; set; }
}
