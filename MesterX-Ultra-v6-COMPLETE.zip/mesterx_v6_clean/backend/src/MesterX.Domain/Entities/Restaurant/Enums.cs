namespace MesterX.Domain.Entities.Restaurant;

public enum TableShape { Square, Round, Long }
public enum TableStatus { Available, Occupied, Reserved, Cleaning, Blocked }
public enum SessionStatus { Active, BillSent, Closed }

public enum DineInOrderStatus
{
    QRDraft,
    QRPendingConfirm,
    Draft,
    SentToKitchen,
    Preparing,
    Ready,
    Delivered,
    Cancelled
}

public enum DineInOrderSource { Waiter, QRSelf, Cashier }
public enum OrderItemStatus { Pending, Preparing, Ready, Delivered, Cancelled }
public enum KitchenTicketStatus { New, Seen, Preparing, Done }

public enum MenuItemAvailability { Available, SoldOut, Hidden }
public enum ReservationStatus { Pending, Confirmed, Seated, NoShow, Cancelled }
