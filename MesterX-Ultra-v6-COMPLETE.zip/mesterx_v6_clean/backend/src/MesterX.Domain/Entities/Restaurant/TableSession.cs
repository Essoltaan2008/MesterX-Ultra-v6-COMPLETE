using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.Auth;

namespace MesterX.Domain.Entities.Restaurant;

public class TableSession : BaseEntity
{
    public Guid BranchId { get; set; }
    public virtual Branch Branch { get; set; } = null!;

    public Guid TableId { get; set; }
    public virtual RestaurantTable Table { get; set; } = null!;

    public SessionStatus Status { get; set; } = SessionStatus.Active;
    public int GuestCount { get; set; } = 1;

    public DateTime OpenedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ClosedAt { get; set; }

    public Guid? OpenedByUserId { get; set; }
    public virtual ApplicationUser? OpenedBy { get; set; }

    public Guid? CustomerId { get; set; }
    public virtual Customer? Customer { get; set; }

    public decimal SubTotal { get; set; }
    public decimal ServiceCharge { get; set; }
    public decimal VatAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal AmountPaid { get; set; }

    public decimal Remaining => Math.Max(0, TotalAmount - AmountPaid);

    public DateTime? BillRequestedAt { get; set; }
    public Guid? BillRequestedBy { get; set; }

    public virtual ICollection<DineInOrder> Orders { get; set; } = [];
    public virtual ICollection<SessionPayment> Payments { get; set; } = [];
}
