using System;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Enums;

namespace MesterX.Domain.Entities.Restaurant;

public class SessionPayment : BaseEntity
{
    public Guid BranchId { get; set; }

    public Guid TableSessionId { get; set; }
    public virtual TableSession Session { get; set; } = null!;

    public decimal Amount { get; set; }
    public PaymentMethod PaymentMethod { get; set; }
    public DateTime PaidAt { get; set; } = DateTime.UtcNow;

    public Guid? ReceivedBy { get; set; }
    public string? Reference { get; set; }
}
