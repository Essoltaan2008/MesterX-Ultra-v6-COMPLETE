using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Restaurant;

public class KitchenTicket : BaseEntity
{
    public Guid BranchId { get; set; }

    public Guid DineInOrderId { get; set; }
    public virtual DineInOrder Order { get; set; } = null!;

    public Guid KitchenStationId { get; set; }
    public virtual KitchenStation Station { get; set; } = null!;

    public string TicketNumber { get; set; } = string.Empty;
    public string TableNumber { get; set; } = string.Empty;

    public KitchenTicketStatus Status { get; set; } = KitchenTicketStatus.New;

    public DateTime CreatedAtKitchen { get; set; } = DateTime.UtcNow;
    public DateTime? SeenAt { get; set; }
    public DateTime? PreparingAt { get; set; }
    public DateTime? DoneAt { get; set; }

    public bool IsPrinted { get; set; }
    public DateTime? PrintedAt { get; set; }

    public int? PrepSeconds =>
        DoneAt.HasValue
            ? (int)(DoneAt.Value - CreatedAtKitchen).TotalSeconds
            : null;

    public virtual ICollection<KitchenTicketItem> Items { get; set; } = [];
}
