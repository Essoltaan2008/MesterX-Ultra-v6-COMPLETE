using System.Collections.Generic;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Restaurant;

public class RestaurantCategory : BaseEntity
{
    public string NameAr { get; set; } = string.Empty;
    public string NameEn { get; set; } = string.Empty;
    public string? ImageUrl { get; set; }
    public string? Color { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;

    public virtual ICollection<RestaurantMenuItem> Items { get; set; } = [];
}
