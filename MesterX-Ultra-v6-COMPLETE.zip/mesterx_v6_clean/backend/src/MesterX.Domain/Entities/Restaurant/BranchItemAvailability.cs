using System;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;

namespace MesterX.Domain.Entities.Restaurant;

public class BranchItemAvailability : BaseEntity
{
    public Guid BranchId { get; set; }
    public virtual Branch Branch { get; set; } = null!;

    public Guid MenuItemId { get; set; }
    public virtual RestaurantMenuItem MenuItem { get; set; } = null!;

    public MenuItemAvailability Status { get; set; } = MenuItemAvailability.Available;
    public DateTime? AvailableAgainAt { get; set; }
    public string? Reason { get; set; }
    public Guid? MarkedBy { get; set; }
}
