using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;

namespace MesterX.Domain.Entities.Restaurant;

public class KitchenStation : BaseEntity
{
    public Guid BranchId { get; set; }
    public virtual Branch Branch { get; set; } = null!;

    public string Name { get; set; } = string.Empty;
    public string? Color { get; set; }
    public bool HasKdsScreen { get; set; }
    public bool HasPrinter { get; set; }
    public string? PrinterName { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;

    public string SignalRGroup => $"kitchen-{TenantId}-{BranchId}-{Id}";

    public virtual ICollection<KitchenTicket> Tickets { get; set; } = [];
}

