using System;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;

namespace MesterX.Domain.Entities.Restaurant;

public class TableReservation : BaseEntity
{
    public Guid BranchId { get; set; }
    public virtual Branch Branch { get; set; } = null!;

    public Guid TableId { get; set; }
    public virtual RestaurantTable Table { get; set; } = null!;

    public string GuestName { get; set; } = string.Empty;
    public string? GuestPhone { get; set; }
    public int GuestCount { get; set; } = 2;

    public DateTime ReservationAt { get; set; }
    public int DurationMins { get; set; } = 90;

    public ReservationStatus Status { get; set; } = ReservationStatus.Pending;

    public string? Notes { get; set; }
    public DateTime? ConfirmedAt { get; set; }
    public DateTime? SeatedAt { get; set; }
    public DateTime? CancelledAt { get; set; }
    public Guid? HandledBy { get; set; }
}
