using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Restaurant;

public class DineInOrderItem : BaseEntity
{
    public Guid DineInOrderId { get; set; }
    public virtual DineInOrder Order { get; set; } = null!;

    public Guid MenuItemId { get; set; }
    public virtual RestaurantMenuItem MenuItem { get; set; } = null!;

    public string ItemNameAr { get; set; } = string.Empty;
    public string ItemNameEn { get; set; } = string.Empty;

    public Guid? VariantId { get; set; }
    public virtual MenuItemVariant? Variant { get; set; }
    public string? VariantName { get; set; }

    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal { get; set; }

    public OrderItemStatus Status { get; set; }

    public Guid? KitchenStationId { get; set; }
    public virtual KitchenStation? KitchenStation { get; set; }

    public string? SpecialInstructions { get; set; }

    public virtual ICollection<OrderItemModifier> Modifiers { get; set; } = [];
}
