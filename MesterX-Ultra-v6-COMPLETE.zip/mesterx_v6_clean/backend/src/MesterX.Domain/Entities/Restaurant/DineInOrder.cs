using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.Auth;

namespace MesterX.Domain.Entities.Restaurant;

public class DineInOrder : BaseEntity
{
    public string OrderNumber { get; set; } = string.Empty;

    public Guid BranchId { get; set; }
    public virtual Branch Branch { get; set; } = null!;

    public Guid TableSessionId { get; set; }
    public virtual TableSession Session { get; set; } = null!;

    public DineInOrderSource OrderSource { get; set; }
    public DineInOrderStatus Status { get; set; }

    public Guid? WaiterId { get; set; }
    public virtual ApplicationUser? Waiter { get; set; }

    public Guid? ConfirmedByUserId { get; set; }
    public DateTime? ConfirmedAt { get; set; }

    public string? GuestName { get; set; }

    public decimal SubTotal { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TotalAmount { get; set; }

    public DateTime OrderedAt { get; set; } = DateTime.UtcNow;
    public DateTime? KitchenSentAt { get; set; }
    public DateTime? ReadyAt { get; set; }
    public DateTime? DeliveredAt { get; set; }
    public DateTime? CancelledAt { get; set; }

    public string? Notes { get; set; }
    public string? CancelReason { get; set; }

    public int EstimatedPrepMins { get; set; }

    public bool NeedsWaiterConfirm => Status == DineInOrderStatus.QRPendingConfirm;
    public bool IsQROrder => OrderSource == DineInOrderSource.QRSelf;

    public virtual ICollection<DineInOrderItem> Items { get; set; } = [];
    public virtual ICollection<KitchenTicket> Tickets { get; set; } = [];
}
