using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;

namespace MesterX.Domain.Entities.Restaurant;

public class RestaurantMenuItem : BaseEntity
{
    public Guid CategoryId { get; set; }
    public virtual RestaurantCategory Category { get; set; } = null!;

    public string NameAr { get; set; } = string.Empty;
    public string NameEn { get; set; } = string.Empty;
    public string? DescriptionAr { get; set; }
    public string? ImageUrl { get; set; }

    public decimal BasePrice { get; set; }
    public int PrepTimeMinutes { get; set; } = 10;
    public bool IsFeatured { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }

    public Guid? DefaultKitchenStationId { get; set; }

    public virtual ICollection<MenuItemVariant> Variants { get; set; } = [];
    public virtual ICollection<MenuModifierGroup> ModifierGroups { get; set; } = [];
    public virtual ICollection<BranchMenuOverride> BranchOverrides { get; set; } = [];
    public virtual ICollection<BranchItemAvailability> Availabilities { get; set; } = [];
}
