using System;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Restaurant;

public class OrderItemModifier : BaseEntity
{
    public Guid OrderItemId { get; set; }
    public virtual DineInOrderItem OrderItem { get; set; } = null!;

    public Guid ModifierId { get; set; }
    public virtual MenuModifier Modifier { get; set; } = null!;

    public string NameAr { get; set; } = string.Empty;
    public string NameEn { get; set; } = string.Empty;
    public decimal ExtraPrice { get; set; }
}
