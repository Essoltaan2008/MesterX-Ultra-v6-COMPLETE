using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;

namespace MesterX.Domain.Entities.Restaurant;

public class FloorPlan : BaseEntity
{
    public Guid BranchId { get; set; }
    public virtual Branch Branch { get; set; } = null!;

    public string Name { get; set; } = string.Empty;
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
    public int CanvasWidth { get; set; } = 1200;
    public int CanvasHeight { get; set; } = 800;
    public string? BackgroundImageUrl { get; set; }

    public virtual ICollection<RestaurantTable> Tables { get; set; } = [];
}
