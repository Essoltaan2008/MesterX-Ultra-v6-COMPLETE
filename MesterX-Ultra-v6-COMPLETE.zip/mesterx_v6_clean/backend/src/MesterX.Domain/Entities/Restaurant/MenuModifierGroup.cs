using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Restaurant;

public class MenuModifierGroup : BaseEntity
{
    public Guid MenuItemId { get; set; }
    public virtual RestaurantMenuItem MenuItem { get; set; } = null!;

    public string NameAr { get; set; } = string.Empty;
    public string NameEn { get; set; } = string.Empty;

    public bool IsRequired { get; set; }
    public bool AllowMultiple { get; set; } = true;
    public int MaxSelections { set; get; } = 10;
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;

    public virtual ICollection<MenuModifier> Modifiers { get; set; } = [];
}
