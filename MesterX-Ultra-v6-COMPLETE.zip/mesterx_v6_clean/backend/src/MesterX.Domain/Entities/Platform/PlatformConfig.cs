using System;

namespace MesterX.Domain.Entities.Platform;

public class PlatformConfig
{
    public Guid Id { get; set; }
    public required string Key { get; set; }
    public required string Value { get; set; }
    public string? Description { get; set; }
    public bool IsPublic { get; set; }
    public DateTime UpdatedAt { get; set; }
}
