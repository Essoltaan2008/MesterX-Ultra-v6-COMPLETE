namespace MesterX.Domain.Enums;

public enum UserRole : short
{
    SuperAdmin = 0,
    TenantAdmin = 1,
    Manager = 2,
    Cashier = 3,
    Viewer = 4
}

public enum PlanType : short
{
    Basic = 0,
    Trial = 1,
    ProMonthly = 2,
    Lifetime = 3,
    Enterprise = 4
}

public enum LicenseStatus : short
{
    Active = 0,
    Expired = 1,
    Suspended = 2,
    Downgraded = 3
}

public enum SaleStatus : short
{
    Pending = 0,
    Completed = 1,
    PartialRefund = 2,
    Refunded = 3,
    Voided = 4
}

public enum PaymentMethod : short
{
    Cash = 0,
    Card = 1,
    Wallet = 2,
    Mixed = 3
}

public enum StockMovementType : short
{
    Purchase = 0,
    Sale = 1,
    Adjustment = 2,
    Return = 3,
    Transfer = 4,
    PhysicalCount = 5
}

public enum SyncEntityType : short
{
    SaleOrder = 0,
    Customer = 1,
    Product = 2,
    StockAdjustment = 3,
    StockMovement = 4
}

public enum SyncStatus : short
{
    Pending = 0,
    Processing = 1,
    Completed = 2,
    Conflict = 3,
    Failed = 4
}

public enum ConflictStrategy : short
{
    ServerWins = 0,
    ClientWins = 1,
    Manual = 2
}

public enum AuditAction : short
{
    Create = 0,
    Update = 1,
    Delete = 2,
    Read = 3,
    Login = 4,
    Logout = 5,
    LicenseActivate = 6,
    LicenseDowngrade = 7,
    SyncPush = 8,
    SyncPull = 9
}

public enum VendorType : short
{
    Photographer = 0,
    Videographer = 1,
    Hall = 2,
    Catering = 3,
    Decoration = 4,
    Car = 5,
    DressRental = 6,
    MakeUp = 7,
    Flowers = 8,
    Music = 9,
    Other = 10
}

public enum BookingStatus : short
{
    Pending = 0,
    Confirmed = 1,
    InProgress = 2,
    Completed = 3,
    Cancelled = 4,
    Refunded = 5
}

public enum BookingEventType : short
{
    Created = 0,
    Confirmed = 1,
    DepositPaid = 2,
    FullyPaid = 3,
    ContractSigned = 4,
    Cancelled = 5,
    Completed = 6,
    MessageSent = 7,
    ReviewAdded = 8
}

public enum PaymentType : short
{
    Deposit = 0,
    FullPayment = 1,
    Refund = 2,
    VendorCommission = 3
}

public enum PaymentStatus : short
{
    Pending = 0,
    Processing = 1,
    Completed = 2,
    Failed = 3,
    Refunded = 4
}
