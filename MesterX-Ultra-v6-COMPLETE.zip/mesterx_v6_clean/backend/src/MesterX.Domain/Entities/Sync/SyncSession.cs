using System;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Sync;

public class SyncSession : BaseEntity
{
    public Guid DeviceId { get; set; }
    public string DeviceName { get; set; } = "";
    public DateTime LastSyncedAt { get; set; }
    public int ItemsPushed { get; set; }
    public int ItemsPulled { get; set; }
    public int ConflictsDetected { get; set; }
    public bool IsSuccess { get; set; } = true;
    public string? ErrorSummary { get; set; }
}
