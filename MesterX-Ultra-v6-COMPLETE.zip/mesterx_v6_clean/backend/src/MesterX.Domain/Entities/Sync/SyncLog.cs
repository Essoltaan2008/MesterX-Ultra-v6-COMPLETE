using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Sync;

public class SyncLog : BaseEntity
{
    public Guid? UserId                 { get; set; }
    public Guid? BranchId              { get; set; }
    public DateTime SyncStartedAt      { get; set; }
    public DateTime? SyncCompletedAt   { get; set; }
    public int RecordsPushed           { get; set; }
    public int RecordsPulled           { get; set; }
    public int ConflictsDetected       { get; set; }
    public int ConflictsResolved       { get; set; }
    public bool IsSuccess              { get; set; }
    public string? ErrorMessage        { get; set; }
    public string? ClientVersion       { get; set; }
}
