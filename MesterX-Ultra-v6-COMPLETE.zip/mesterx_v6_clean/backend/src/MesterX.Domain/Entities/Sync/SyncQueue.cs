using System;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Sync;

public class SyncQueue : BaseEntity
{
    public SyncEntityType EntityType { get; set; }
    public Guid EntityId { get; set; }
    public string Payload { get; set; } = "{}";
    public SyncStatus Status { get; set; }
    public required string IdempotencyKey { get; set; }
    public ConflictStrategy ConflictStrategy { get; set; }
    public bool HasConflict { get; set; }
    public string? ConflictDetails { get; set; }
    public int RetryCount { get; set; }
    public DateTime? ProcessedAt { get; set; }
    public string? ErrorMessage { get; set; }
    public int ClientVersion { get; set; } = 1;
    public int? ServerVersion { get; set; }
}
