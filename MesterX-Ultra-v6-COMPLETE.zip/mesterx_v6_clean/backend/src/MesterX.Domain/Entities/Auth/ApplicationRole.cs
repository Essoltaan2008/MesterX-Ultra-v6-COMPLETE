using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;

namespace MesterX.Domain.Entities.Auth;

public class ApplicationRole : BaseEntity
{
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsSystemRole { get; set; }

    public virtual Tenant Tenant { get; set; } = null!;
    public virtual ICollection<ApplicationPermission> Permissions { get; set; } = [];
    public virtual ICollection<ApplicationUser> Users { get; set; } = [];
}
