using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;

namespace MesterX.Domain.Entities.Auth;

public class ApplicationPermission : BaseEntity
{
    public required string Name { get; set; }
    public required string Code { get; set; }
    public string? Description { get; set; }
    public required string Module { get; set; }

    public virtual Tenant Tenant { get; set; } = null!;
    public virtual ICollection<ApplicationRole> Roles { get; set; } = [];
}
