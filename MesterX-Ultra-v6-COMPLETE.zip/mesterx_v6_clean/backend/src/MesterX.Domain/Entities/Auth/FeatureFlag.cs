using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Auth;

public class FeatureFlag : BaseEntity
{
    public required string ModuleName { get; set; }
    public required string Key { get; set; }
    public bool IsEnabled { get; set; }
    public string? Description { get; set; }
    public int MinPhase { get; set; } = 1;
}
