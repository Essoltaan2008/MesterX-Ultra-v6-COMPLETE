using System;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Auth;

public class RefreshToken : BaseEntity
{
    public Guid UserId { get; set; }
    public required string TokenHash { get; set; }
    public DateTime ExpiresAt { get; set; }
    public bool IsRevoked { get; set; }
    public string? CreatedByIp { get; set; }

    public virtual ApplicationUser User { get; set; } = null!;
}
