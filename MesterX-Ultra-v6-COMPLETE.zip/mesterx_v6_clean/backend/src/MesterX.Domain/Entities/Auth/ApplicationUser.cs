using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.POS;

namespace MesterX.Domain.Entities.Auth;

public class ApplicationUser : BaseEntity
{
    public required string Username { get; set; }
    public required string Email { get; set; }
    public required string PasswordHash { get; set; }
    public required string FullName { get; set; }
    public string? Phone { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? RoleId { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? LastLoginAt { get; set; }
    public string? LastLoginIp { get; set; }

    public virtual Tenant Tenant { get; set; } = null!;
    public virtual Branch? Branch { get; set; }
    public virtual ApplicationRole? Role { get; set; }
    public virtual ICollection<RefreshToken> RefreshTokens { get; set; } = [];
    public virtual ICollection<SaleOrder> SaleOrders { get; set; } = [];
}
