using System;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Rental;

public class RentalBookingItem : BaseEntity
{
    public Guid BookingId { get; set; }
    public virtual RentalBooking Booking { get; set; } = null!;

    public Guid AssetId { get; set; }
    public virtual RentalAsset Asset { get; set; } = null!;

    public int Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public decimal DepositAmount { get; set; }
    public decimal LineTotal { get; set; }

    public bool IsReturned { get; set; }
    public DateTime? ReturnedAt { get; set; }
    public string? ConditionAtPickup { get; set; }
    public string? ConditionAtReturn { get; set; }
}
