using System;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Rental;

public class MaintenanceLog : BaseEntity
{
    public Guid AssetId { get; set; }
    public virtual RentalAsset Asset { get; set; } = null!;

    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? TechnicianName { get; set; }

    public decimal Cost { get; set; }
    public DateTime ScheduledDate { get; set; }
    public DateTime? CompletedDate { get; set; }
    public bool IsCompleted { get; set; }

    public Guid? DamageReportId { get; set; }
    public virtual DamageReport? DamageReport { get; set; }
}
