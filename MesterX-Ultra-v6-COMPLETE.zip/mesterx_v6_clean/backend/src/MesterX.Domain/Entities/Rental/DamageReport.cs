using System;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Rental;

public class DamageReport : BaseEntity
{
    public Guid BookingId { get; set; }
    public virtual RentalBooking Booking { get; set; } = null!;

    public Guid AssetId { get; set; }
    public virtual RentalAsset Asset { get; set; } = null!;

    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }

    public DamageLevel DamageLevel { get; set; }
    public decimal CompensationAmount { get; set; }
    public bool CompensationPaid { get; set; }
    public DateTime? CompensationPaidAt { get; set; }

    public string DamageImagesJson { get; set; } = "[]";

    public bool RequiresMaintenance { get; set; }
    public Guid? ReportedBy { get; set; }
}
