using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.Auth;

namespace MesterX.Domain.Entities.Rental;

public class RentalBooking : BaseEntity
{
    public string BookingNumber { get; set; } = string.Empty;

    public Guid CustomerId { get; set; }
    public virtual Customer Customer { get; set; } = null!;

    public BookingType BookingType { get; set; } = BookingType.Rental;
    public BookingStatus Status { get; set; } = BookingStatus.Pending;

    public DateTime BookingDate { get; set; } = DateTime.UtcNow;
    public DateTime PickupDate { get; set; }
    public DateTime ReturnDueDate { get; set; }
    public DateTime? ActualReturnDate { get; set; }
    public DateTime? EventDate { get; set; }
    public string? EventLocation { get; set; }

    public decimal SubTotal { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal VatAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal DepositRequired { get; set; }
    public decimal DepositPaid { get; set; }
    public decimal AmountPaid { get; set; }

    public int LateDays { get; set; }
    public decimal LatePenaltyTotal { get; set; }
    public bool PenaltyWaived { get; set; }
    public Guid? PenaltyWaivedBy { get; set; }

    public bool ContractSigned { get; set; }
    public string? ContractPdfUrl { get; set; }

    public Guid? HandledByUserId { get; set; }
    public virtual ApplicationUser? HandledBy { get; set; }

    public string? Notes { get; set; }
    public bool IsOnlineBooking { get; set; }

    public virtual ICollection<RentalBookingItem> Items { get; set; } = [];
    public virtual ICollection<RentalPayment> Payments { get; set; } = [];
    public virtual ICollection<DamageReport> DamageReports { get; set; } = [];

    public decimal AmountDue => TotalAmount + LatePenaltyTotal - AmountPaid;
    public decimal DepositBalance => DepositPaid - DepositRequired;
    public bool IsOverdue => Status == BookingStatus.PickedUp && DateTime.UtcNow.Date > ReturnDueDate.Date;
}
