using System;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Rental;

public class MarketplaceListing : BaseEntity
{
    public Guid AssetId { get; set; }
    public virtual RentalAsset Asset { get; set; } = null!;

    public string? CustomDescription { get; set; }
    public string? CustomTags { get; set; }

    public bool IsVisible { get; set; } = true;
    public int ViewCount { get; set; }
    public double AverageRating { get; set; }
    public int ReviewCount { get; set; }
}
