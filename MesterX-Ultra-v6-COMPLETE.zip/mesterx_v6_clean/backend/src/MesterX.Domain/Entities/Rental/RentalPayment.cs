using System;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Rental;

public class RentalPayment : BaseEntity
{
    public Guid BookingId { get; set; }
    public virtual RentalBooking Booking { get; set; } = null!;

    public decimal Amount { get; set; }
    public RentalPaymentMethod PaymentMethod { get; set; }
    public RentalPaymentPurpose Purpose { get; set; }

    public DateTime PaymentDate { get; set; } = DateTime.UtcNow;

    public string? ExternalTransactionId { get; set; }
    public string? Notes { get; set; }

    public bool IsRefunded { get; set; }
    public DateTime? RefundedAt { get; set; }
    public Guid? RecordedBy { get; set; }
}
