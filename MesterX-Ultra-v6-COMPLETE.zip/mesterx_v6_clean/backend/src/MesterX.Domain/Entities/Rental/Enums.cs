namespace MesterX.Domain.Entities.Rental;

public enum AssetCategory { WeddingDress, Suit, Accessory, Decoration, Electronics, Furniture, Other }
public enum AssetStatus { Available, Rented, Reserved, Maintenance, Damaged, Retired }
public enum AssetCondition { Excellent, Good, Fair, Poor }
public enum RentalPricingModel { PerDay, PerHour, PerEvent, ForSale }
public enum BookingType { Rental, Sale }
public enum BookingStatus { Pending, Confirmed, PickedUp, Returned, Cancelled, Overdue }
public enum RentalPaymentPurpose { Deposit, RentalFee, LatePenalty, DamageComp, Refund, SalePayment }
public enum RentalPaymentMethod { Cash, Card, BankTransfer, MobileWallet, Credit }
public enum DamageLevel { Minor, Moderate, Severe, Totaled }
