using System;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Rental;

public class RentalAssetImage : BaseEntity
{
    public Guid AssetId { get; set; }
    public virtual RentalAsset Asset { get; set; } = null!;

    public string ImageUrl { get; set; } = string.Empty;
    public bool IsPrimary { get; set; }
    public int SortOrder { get; set; }
}
