using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Rental;

public class RentalAsset : BaseEntity
{
    public string AssetCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;

    public AssetCategory Category { get; set; }
    public string? SubCategory { get; set; }
    public string? Brand { get; set; }
    public string? Size { get; set; }
    public string? Color { get; set; }
    public string? Description { get; set; }

    public RentalPricingModel PricingModel { get; set; } = RentalPricingModel.PerDay;
    public decimal RentalPricePerDay { get; set; }
    public decimal RentalPricePerHour { get; set; }
    public decimal SalePrice { get; set; }
    public decimal DepositAmount { get; set; }
    public decimal PurchaseCost { get; set; }
    public decimal LatePenaltyPerDay { get; set; }
    public int MaxRentalDays { get; set; } = 7;

    public AssetStatus Status { get; set; } = AssetStatus.Available;
    public AssetCondition Condition { get; set; } = AssetCondition.Excellent;

    public string? Barcode { get; set; }
    public string? QrCodeUrl { get; set; }
    public string? PrimaryImageUrl { get; set; }

    public bool IsListedOnMarketplace { get; set; }

    public int TotalRentalCount { get; set; }
    public decimal TotalRevenue { get; set; }
    public DateTime? LastRentedAt { get; set; }

    public virtual ICollection<RentalAssetImage> Images { get; set; } = [];
    public virtual ICollection<RentalBookingItem> BookingItems { get; set; } = [];
    public virtual ICollection<MaintenanceLog> MaintenanceLogs { get; set; } = [];
    public virtual ICollection<DamageReport> DamageReports { get; set; } = [];
}
