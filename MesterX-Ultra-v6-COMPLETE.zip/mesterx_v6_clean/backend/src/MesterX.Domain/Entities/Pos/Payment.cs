using MesterX.Domain.Entities.Base;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Pos;

public class Payment : BaseEntity
{
    public Guid SaleOrderId            { get; set; }
    public PaymentMethod Method        { get; set; }
    public decimal Amount              { get; set; }
    public string? ReferenceNumber     { get; set; }  // Card auth / wallet tx
    public string? Notes               { get; set; }
    public PaymentStatus Status        { get; set; } = PaymentStatus.Completed;
    public DateTime PaidAt             { get; set; } = DateTime.UtcNow;

    public virtual SaleOrder SaleOrder { get; set; } = null!;
}

public class PaymentMethod_Config : BaseEntity
{
    public required string Name        { get; set; }
    public required string NameAr      { get; set; }
    public bool IsActive               { get; set; } = true;
    public bool RequiresReference      { get; set; }
    public decimal? MaxAmount          { get; set; }
    public int SortOrder               { get; set; }
}
