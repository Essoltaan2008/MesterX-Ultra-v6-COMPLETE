using System;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;

namespace MesterX.Domain.Entities.POS;

public class SaleOrderItem : BaseEntity
{
    public Guid SaleOrderId { get; set; }
    public Guid ProductId { get; set; }
    public required string ProductName { get; set; }
    public string? ProductBarcode { get; set; }
    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal VatRate { get; set; }
    public decimal VatAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal LineTotal { get; set; }

    public virtual SaleOrder SaleOrder { get; set; } = null!;
    public virtual Product Product { get; set; } = null!;
}
