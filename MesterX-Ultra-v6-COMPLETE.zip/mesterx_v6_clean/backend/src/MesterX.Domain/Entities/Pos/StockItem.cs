using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;

namespace MesterX.Domain.Entities.POS;

public class StockItem : BaseEntity
{
    public Guid ProductId { get; set; }
    public Guid BranchId { get; set; }
    public decimal Quantity { get; set; }
    public decimal ReservedQuantity { get; set; }
    public decimal AvailableQuantity => Quantity - ReservedQuantity;

    public virtual Product Product { get; set; } = null!;
    public virtual Branch Branch { get; set; } = null!;
    public virtual ICollection<StockMovement> Movements { get; set; } = [];
}
