using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.POS;

public class SaleOrder : BaseEntity
{
    public required string OrderNumber { get; set; }
    public Guid BranchId { get; set; }
    public Guid? CustomerId { get; set; }
    public Guid CashierId { get; set; }
    public SaleStatus Status { get; set; }
    public PaymentMethod PaymentMethod { get; set; }
    public decimal SubTotal { get; set; }
    public decimal VatAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal AmountPaid { get; set; }
    public decimal Change { get; set; }
    public string? Notes { get; set; }
    public bool IsOffline { get; set; }
    public string? ClientIdempotencyKey { get; set; }
    public DateTime? SyncedAt { get; set; }

    public virtual Tenant Tenant { get; set; } = null!;
    public virtual Branch Branch { get; set; } = null!;
    public virtual Customer? Customer { get; set; }
    public virtual ApplicationUser Cashier { get; set; } = null!;
    public virtual ICollection<SaleOrderItem> Items { get; set; } = [];
    public virtual ICollection<SaleRefund> Refunds { get; set; } = [];
}
