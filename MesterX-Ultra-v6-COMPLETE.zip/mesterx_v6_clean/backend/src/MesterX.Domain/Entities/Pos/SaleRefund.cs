using System;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.POS;

public class SaleRefund : BaseEntity
{
    public Guid SaleOrderId { get; set; }
    public decimal RefundAmount { get; set; }
    public required string Reason { get; set; }
    public Guid ProcessedBy { get; set; }

    public virtual SaleOrder SaleOrder { get; set; } = null!;
}
