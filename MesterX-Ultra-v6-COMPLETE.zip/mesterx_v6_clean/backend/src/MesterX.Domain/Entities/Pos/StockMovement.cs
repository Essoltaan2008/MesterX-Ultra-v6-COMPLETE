using System;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.POS;

public class StockMovement : BaseEntity
{
    public Guid StockItemId { get; set; }
    public Guid ProductId { get; set; }
    public Guid BranchId { get; set; }
    public StockMovementType MovementType { get; set; }
    public decimal Quantity { get; set; }
    public decimal QuantityBefore { get; set; }
    public decimal QuantityAfter { get; set; }
    public string? Reference { get; set; }
    public string? Notes { get; set; }
    public Guid? SaleOrderId { get; set; }

    public virtual StockItem StockItem { get; set; } = null!;
    public virtual Product Product { get; set; } = null!;
}
