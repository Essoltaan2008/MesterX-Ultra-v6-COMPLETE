using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Pos;

public class PurchaseOrder : BaseEntity
{
    public required string PONumber     { get; set; }
    public Guid SupplierId              { get; set; }
    public Guid BranchId                { get; set; }
    public PurchaseOrderStatus Status   { get; set; } = PurchaseOrderStatus.Draft;
    public DateTime OrderDate           { get; set; } = DateTime.UtcNow;
    public DateTime? ExpectedDate       { get; set; }
    public DateTime? ReceivedDate       { get; set; }
    public decimal TotalAmount          { get; set; }
    public decimal AmountPaid           { get; set; }
    public string? Notes                { get; set; }
    public Guid? CreatedByUserId        { get; set; }

    public decimal AmountDue => TotalAmount - AmountPaid;

    public virtual Supplier Supplier    { get; set; } = null!;
    public virtual Branch Branch        { get; set; } = null!;
    public virtual ICollection<PurchaseOrderItem> Items { get; set; } = [];
}

public class PurchaseOrderItem : BaseEntity
{
    public Guid PurchaseOrderId         { get; set; }
    public Guid ProductId               { get; set; }
    public decimal QuantityOrdered      { get; set; }
    public decimal QuantityReceived     { get; set; }
    public decimal UnitCost             { get; set; }
    public decimal LineTotal            { get; set; }
    public string? Notes                { get; set; }

    public virtual PurchaseOrder PurchaseOrder { get; set; } = null!;
    public virtual Product Product      { get; set; } = null!;
}
