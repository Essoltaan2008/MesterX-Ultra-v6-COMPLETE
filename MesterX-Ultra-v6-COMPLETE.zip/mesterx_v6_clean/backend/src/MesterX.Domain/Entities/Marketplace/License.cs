using System;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Marketplace;

public class License : BaseEntity
{
    public required string LicenseKeyHash { get; set; }
    public PlanType PlanType { get; set; }
    public LicenseStatus Status { get; set; }
    public DateTime ActivatedAt { get; set; }
    public DateTime? ExpiresAt { get; set; }
    public bool SyncAddonActive { get; set; }
    public DateTime? SyncAddonExpiresAt { get; set; }
    public string? DeviceFingerprintHash { get; set; }
    public int MaxBranches { get; set; } = 1;
    public int MaxUsers { get; set; } = 1;
    public int MaxProducts { get; set; } = 500;
    public DateTime? DowngradedAt { get; set; }
    public string? DowngradeReason { get; set; }

    public virtual Tenant Tenant { get; set; } = null!;
}
