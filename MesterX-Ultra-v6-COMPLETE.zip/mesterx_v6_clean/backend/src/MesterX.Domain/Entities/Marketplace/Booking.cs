using System;
using System.Collections.Generic;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Marketplace;

public class Booking : BaseEntity
{
    public Guid TenantId { get; set; }
    public required string BookingNumber { get; set; }
    public Guid VendorId { get; set; }
    public Guid CustomerId { get; set; }
    public DateTime EventDate { get; set; }
    public int EstimatedGuests { get; set; }
    public BookingStatus Status { get; set; } = BookingStatus.Pending;
    public decimal TotalPrice { get; set; }
    public decimal DepositAmount { get; set; }
    public decimal RemainingAmount { get; set; }
    public DateTime? DepositPaidAt { get; set; }
    public DateTime? FullPaidAt { get; set; }
    public string? Notes { get; set; }
    public string? VendorNotes { get; set; }
    public string? ContractUrl { get; set; }
    public DateTime? ContractSignedAt { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancellationReason { get; set; }

    public virtual Tenant Tenant { get; set; } = null!;
    public virtual Vendor Vendor { get; set; } = null!;
    public virtual Customer Customer { get; set; } = null!;
    public virtual ICollection<BookingService> Services { get; set; } = [];
    public virtual ICollection<BookingPayment> Payments { get; set; } = [];
    public virtual ICollection<BookingTimeline> Timeline { get; set; } = [];
}
