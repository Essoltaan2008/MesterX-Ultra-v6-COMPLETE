using System.Collections.Generic;

namespace MesterX.Domain.Entities.Marketplace;

public class VendorCategory : BaseEntity
{
    public required string Name { get; set; }
    public string? NameAr { get; set; }
    public string? Description { get; set; }
    public string? IconUrl { get; set; }
    public bool IsActive { get; set; } = true;

    public virtual Tenant Tenant { get; set; } = null!;
    public virtual ICollection<VendorService> Services { get; set; } = [];
}
