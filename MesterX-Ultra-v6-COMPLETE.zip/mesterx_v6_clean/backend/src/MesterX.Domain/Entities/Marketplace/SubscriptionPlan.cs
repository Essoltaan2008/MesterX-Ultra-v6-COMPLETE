using System;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Marketplace;

public class SubscriptionPlan
{
    public Guid Id { get; set; }
    public required string Name { get; set; }
    public PlanType PlanType { get; set; }
    public decimal Price { get; set; }
    public string Currency { get; set; } = "EGP";
    public int? DurationDays { get; set; }
    public int MaxBranches { get; set; } = 1;
    public int MaxUsers { get; set; } = 1;
    public int MaxProducts { get; set; } = 500;
    public bool AllowSync { get; set; }
    public bool AllowAdvancedReports { get; set; }
    public bool AllowApiAccess { get; set; }
    public bool AllowWhiteLabel { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}
