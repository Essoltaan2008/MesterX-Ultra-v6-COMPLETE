namespace MesterX.Domain.Entities.Marketplace;

public class BookingService : BaseEntity
{
    public Guid BookingId { get; set; }
    public Guid VendorServiceId { get; set; }
    public required string ServiceName { get; set; }
    public decimal ServicePrice { get; set; }
    public int Quantity { get; set; } = 1;
    public decimal LineTotal { get; set; }

    public virtual Booking Booking { get; set; } = null!;
    public virtual VendorService VendorService { get; set; } = null!;
}
