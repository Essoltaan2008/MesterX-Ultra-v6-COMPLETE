using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Marketplace;

public class BookingPayment : BaseEntity
{
    public Guid BookingId { get; set; }
    public decimal Amount { get; set; }
    public PaymentType PaymentType { get; set; }
    public PaymentStatus Status { get; set; } = PaymentStatus.Pending;
    public string? TransactionId { get; set; }
    public string? PaymentReference { get; set; }
    public DateTime? PaidAt { get; set; }
    public string? FailureReason { get; set; }

    public virtual Booking Booking { get; set; } = null!;
}
