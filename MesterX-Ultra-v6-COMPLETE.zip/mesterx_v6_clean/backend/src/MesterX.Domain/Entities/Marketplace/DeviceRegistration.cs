using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Marketplace;

namespace MesterX.Domain.Entities.Marketplace;

public class DeviceRegistration : BaseEntity
{
    public Guid LicenseId               { get; set; }
    public required string FingerprintHash { get; set; }   // SHA-256
    public required string DeviceName   { get; set; }
    public string? OS                   { get; set; }
    public string? AppVersion           { get; set; }
    public DateTime LastSeenAt          { get; set; } = DateTime.UtcNow;
    public bool IsRevoked               { get; set; }
    public DateTime? RevokedAt          { get; set; }

    public virtual License License      { get; set; } = null!;
}
