using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Marketplace;

public class VendorPayment : BaseEntity
{
    public Guid VendorId { get; set; }
    public decimal Amount { get; set; }
    public PaymentStatus Status { get; set; } = PaymentStatus.Pending;
    public string? BankAccountNumber { get; set; }
    public string? BankName { get; set; }
    public string? TransactionId { get; set; }
    public DateTime? ProcessedAt { get; set; }
    public string? Notes { get; set; }

    public virtual Vendor Vendor { get; set; } = null!;
}
