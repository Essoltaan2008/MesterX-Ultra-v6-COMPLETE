namespace MesterX.Domain.Entities.Marketplace;

public class VendorReview : BaseEntity
{
    public Guid VendorId { get; set; }
    public Guid BookingId { get; set; }
    public Guid CustomerId { get; set; }
    public decimal Rating { get; set; }
    public required string Review { get; set; }
    public bool IsVerified { get; set; }
    public int HelpfulCount { get; set; } = 0;

    public virtual Vendor Vendor { get; set; } = null!;
    public virtual Booking Booking { get; set; } = null!;
    public virtual Customer Customer { get; set; } = null!;
}
