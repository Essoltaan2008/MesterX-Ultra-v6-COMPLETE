using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Marketplace;

public class BookingTimeline : BaseEntity
{
    public Guid BookingId { get; set; }
    public BookingEventType EventType { get; set; }
    public required string Message { get; set; }
    public string? MetaData { get; set; }
    public Guid? TriggeredBy { get; set; }

    public virtual Booking Booking { get; set; } = null!;
}
