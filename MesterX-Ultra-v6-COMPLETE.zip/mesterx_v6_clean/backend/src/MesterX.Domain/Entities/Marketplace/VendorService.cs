using System.Collections.Generic;

namespace MesterX.Domain.Entities.Marketplace;

public class VendorService : BaseEntity
{
    public Guid VendorId { get; set; }
    public Guid? VendorCategoryId { get; set; }
    public required string Name { get; set; }
    public string? NameAr { get; set; }
    public string? Description { get; set; }
    public decimal BasePrice { get; set; }
    public string? ImageUrl { get; set; }
    public int MaxGuests { get; set; } = 1000;
    public int MinGuests { get; set; } = 1;
    public bool IsActive { get; set; } = true;
    public int BookingCount { get; set; } = 0;

    public virtual Vendor Vendor { get; set; } = null!;
    public virtual VendorCategory? Category { get; set; }
    public virtual ICollection<BookingService> Bookings { get; set; } = [];
}
