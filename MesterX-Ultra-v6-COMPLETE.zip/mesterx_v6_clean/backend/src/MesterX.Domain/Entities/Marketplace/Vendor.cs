using System;
using System.Collections.Generic;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Marketplace;

public class Vendor : BaseEntity
{
    public Guid OwnerId { get; set; }
    public Guid? VendorTypeId { get; set; }
    public required string BusinessName { get; set; }
    public string? NameAr { get; set; }
    public required string Email { get; set; }
    public required string Phone { get; set; }
    public VendorType VendorType { get; set; }
    public string? Description { get; set; }
    public string? Bio { get; set; }
    public decimal Rating { get; set; } = 0;
    public int ReviewCount { get; set; } = 0;
    public string? LogoUrl { get; set; }
    public string? CoverImageUrl { get; set; }
    public string? Address { get; set; }
    public string? City { get; set; }
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
    public bool IsVerified { get; set; }
    public DateTime? VerifiedAt { get; set; }
    public bool IsActive { get; set; } = true;
    public decimal CommissionRate { get; set; } = 15.00m;
    public decimal BankBalance { get; set; } = 0;
    public decimal WithdrawnAmount { get; set; } = 0;

    public virtual Tenant Tenant { get; set; } = null!;
    public virtual ApplicationUser Owner { get; set; } = null!;
    public virtual ICollection<VendorService> Services { get; set; } = [];
    public virtual ICollection<VendorAvailability> Availability { get; set; } = [];
    public virtual ICollection<Booking> Bookings { get; set; } = [];
    public virtual ICollection<VendorReview> Reviews { get; set; } = [];
    public virtual ICollection<VendorPayment> Payments { get; set; } = [];
}
