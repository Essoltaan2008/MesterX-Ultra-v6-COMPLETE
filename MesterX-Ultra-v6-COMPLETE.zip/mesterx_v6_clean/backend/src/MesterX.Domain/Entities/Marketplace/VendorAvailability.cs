namespace MesterX.Domain.Entities.Marketplace;

public class VendorAvailability : BaseEntity
{
    public Guid VendorId { get; set; }
    public DateTime AvailableDate { get; set; }
    public TimeSpan StartTime { get; set; }
    public TimeSpan EndTime { get; set; }
    public int MaxBookings { get; set; } = 1;
    public int BookedCount { get; set; } = 0;
    public bool IsBlocked { get; set; }
    public string? BlockReason { get; set; }

    public virtual Vendor Vendor { get; set; } = null!;
}
