using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Core;

public class Expense : BaseEntity
{
    public Guid BranchId                { get; set; }
    public required string Description  { get; set; }
    public ExpenseCategory Category     { get; set; } = ExpenseCategory.Other;
    public decimal Amount               { get; set; }
    public DateTime ExpenseDate         { get; set; } = DateTime.UtcNow;
    public string? ReceiptUrl           { get; set; }
    public string? Notes                { get; set; }
    public Guid? ApprovedBy             { get; set; }
    public DateTime? ApprovedAt         { get; set; }
    public Guid? RecordedByUserId       { get; set; }

    public virtual Branch Branch        { get; set; } = null!;
    public virtual ApplicationUser? RecordedBy { get; set; }
}
