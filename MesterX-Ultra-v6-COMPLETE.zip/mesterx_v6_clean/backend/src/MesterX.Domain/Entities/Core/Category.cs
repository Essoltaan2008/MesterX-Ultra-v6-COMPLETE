using System.Collections.Generic;
using MesterX.Domain.Entities.Base;

namespace MesterX.Domain.Entities.Core;

public class Category : BaseEntity
{
    public required string Name { get; set; }
    public string? Description { get; set; }
    public string? IconUrl { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }

    public virtual Tenant Tenant { get; set; } = null!;
    public virtual ICollection<Product> Products { get; set; } = [];
}
