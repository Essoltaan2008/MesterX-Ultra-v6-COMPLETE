using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Marketplace;
using MesterX.Domain.Entities.POS;

namespace MesterX.Domain.Entities.Core;

public class Tenant : BaseEntity
{
    public required string Name { get; set; }
    public required string Slug { get; set; }
    public string? LogoUrl { get; set; }
    public string? ContactEmail { get; set; }
    public string? ContactPhone { get; set; }
    public string? Address { get; set; }
    public string? TaxNumber { get; set; }
    public string Currency { get; set; } = "EGP";
    public decimal VatRate { get; set; } = 14.00m;
    public bool IsActive { get; set; } = true;

    public virtual ICollection<Branch> Branches { get; set; } = [];
    public virtual ICollection<ApplicationUser> Users { get; set; } = [];
    public virtual ICollection<License> Licenses { get; set; } = [];
    public virtual ICollection<Product> Products { get; set; } = [];
    public virtual ICollection<Customer> Customers { get; set; } = [];
    public virtual ICollection<SaleOrder> SaleOrders { get; set; } = [];
    public virtual ICollection<Category> Categories { get; set; } = [];
}
