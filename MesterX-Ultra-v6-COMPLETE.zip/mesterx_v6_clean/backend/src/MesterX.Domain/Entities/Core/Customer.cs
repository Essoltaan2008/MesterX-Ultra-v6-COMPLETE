using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.POS;

namespace MesterX.Domain.Entities.Core;

public class Customer : BaseEntity
{
    public required string Name { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? Address { get; set; }
    public decimal LoyaltyPoints { get; set; }
    public decimal TotalSpent { get; set; }
    public bool IsActive { get; set; } = true;

    public virtual Tenant Tenant { get; set; } = null!;
    public virtual ICollection<SaleOrder> SaleOrders { get; set; } = [];
}
