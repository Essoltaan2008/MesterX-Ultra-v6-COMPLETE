using System;
using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.POS;

namespace MesterX.Domain.Entities.Core;

public class Branch : BaseEntity
{
    public required string Name { get; set; }
    public string? Address { get; set; }
    public string? Phone { get; set; }
    public bool IsMain { get; set; }
    public bool IsActive { get; set; } = true;

    public virtual Tenant Tenant { get; set; } = null!;
    public virtual ICollection<ApplicationUser> Users { get; set; } = [];
    public virtual ICollection<StockItem> StockItems { get; set; } = [];
    public virtual ICollection<SaleOrder> SaleOrders { get; set; } = [];
}
