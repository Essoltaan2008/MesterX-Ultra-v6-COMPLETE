using System.Collections.Generic;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.POS;

namespace MesterX.Domain.Entities.Core;

public class Product : BaseEntity
{
    public System.Guid? CategoryId { get; set; }
    public required string Name { get; set; }
    public string? NameAr { get; set; }
    public string? Description { get; set; }
    public string? Barcode { get; set; }
    public string? Sku { get; set; }
    public decimal CostPrice { get; set; }
    public decimal SalePrice { get; set; }
    public bool HasVat { get; set; } = true;
    public string? ImageUrl { get; set; }
    public bool IsActive { get; set; } = true;
    public bool TrackStock { get; set; } = true;
    public int LowStockThreshold { get; set; } = 5;

    public virtual Tenant Tenant { get; set; } = null!;
    public virtual Category? Category { get; set; }
    public virtual ICollection<StockItem> StockItems { get; set; } = [];
    public virtual ICollection<StockMovement> StockMovements { get; set; } = [];
    public virtual ICollection<SaleOrderItem> SaleOrderItems { get; set; } = [];
}
