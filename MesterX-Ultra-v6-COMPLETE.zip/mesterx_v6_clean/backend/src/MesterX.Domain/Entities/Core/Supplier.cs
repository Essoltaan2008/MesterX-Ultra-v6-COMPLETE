using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Pos;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Core;

public class Supplier : BaseEntity
{
    public required string Name        { get; set; }
    public string? NameAr              { get; set; }
    public string? ContactPerson       { get; set; }
    public string? Phone               { get; set; }
    public string? Email               { get; set; }
    public string? Address             { get; set; }
    public string? TaxNumber           { get; set; }
    public string? BankAccount         { get; set; }
    public decimal CreditLimit         { get; set; }
    public decimal OutstandingBalance  { get; set; }
    public SupplierStatus Status       { get; set; } = SupplierStatus.Active;
    public string? Notes               { get; set; }

    public virtual ICollection<PurchaseOrder> PurchaseOrders { get; set; } = [];
}
