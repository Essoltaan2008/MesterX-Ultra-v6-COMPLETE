using MesterX.Domain.Entities.Audit;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.Marketplace;
using MesterX.Domain.Entities.Platform;
using MesterX.Domain.Entities.Pos;
using MesterX.Domain.Entities.Sync;
using MesterX.Domain.Interfaces;
using MesterX.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace MesterX.Infrastructure.Repositories;

// ════════════════════════════════════════════════════════════════════════════
// Generic Repository Implementation
// ════════════════════════════════════════════════════════════════════════════
public class Repository<T> : IRepository<T> where T : class
{
    protected readonly MesterXDbContext _db;
    protected readonly DbSet<T> _set;

    public Repository(MesterXDbContext db)
    {
        _db  = db;
        _set = db.Set<T>();
    }

    public async Task<T?> GetByIdAsync(Guid id, CancellationToken ct = default)
        => await _set.FindAsync([id], ct);

    public async Task<T?> GetByIdAsync(Guid id, Guid tenantId, CancellationToken ct = default)
        => await _set.FindAsync([id], ct);

    public async Task<IEnumerable<T>> GetAllAsync(Guid tenantId, CancellationToken ct = default)
        => await _set.ToListAsync(ct);

    public async Task<IEnumerable<T>> FindAsync(
        System.Linq.Expressions.Expression<Func<T, bool>> predicate,
        CancellationToken ct = default)
        => await _set.Where(predicate).ToListAsync(ct);

    public async Task<T?> FirstOrDefaultAsync(
        System.Linq.Expressions.Expression<Func<T, bool>> predicate,
        CancellationToken ct = default)
        => await _set.FirstOrDefaultAsync(predicate, ct);

    public async Task<bool> AnyAsync(
        System.Linq.Expressions.Expression<Func<T, bool>> predicate,
        CancellationToken ct = default)
        => await _set.AnyAsync(predicate, ct);

    public async Task<int> CountAsync(
        System.Linq.Expressions.Expression<Func<T, bool>> predicate,
        CancellationToken ct = default)
        => await _set.CountAsync(predicate, ct);

    public IQueryable<T> Query() => _set.AsQueryable();

    public async Task AddAsync(T entity, CancellationToken ct = default)
        => await _set.AddAsync(entity, ct);

    public async Task AddRangeAsync(IEnumerable<T> entities, CancellationToken ct = default)
        => await _set.AddRangeAsync(entities, ct);

    public void Update(T entity) => _set.Update(entity);

    public void SoftDelete(T entity, Guid deletedBy)
    {
        if (entity is Domain.Entities.Base.BaseEntity b)
        {
            b.IsDeleted  = true;
            b.DeletedAt  = DateTime.UtcNow;
            b.DeletedBy  = deletedBy;
            _set.Update(entity);
        }
    }

    public void Remove(T entity) => _set.Remove(entity);
}

// ════════════════════════════════════════════════════════════════════════════
// Unit of Work Implementation
// ════════════════════════════════════════════════════════════════════════════
public class UnitOfWork : IUnitOfWork
{
    private readonly MesterXDbContext _db;
    private IDbContextTransaction? _transaction;

    public UnitOfWork(MesterXDbContext db) => _db = db;

    // ── Core ──────────────────────────────────────────────────────────────
    public IRepository<Tenant>               Tenants              => new Repository<Tenant>(_db);
    public IRepository<Branch>               Branches             => new Repository<Branch>(_db);
    public IRepository<ApplicationUser>      Users                => new Repository<ApplicationUser>(_db);
    public IRepository<ApplicationRole>      Roles                => new Repository<ApplicationRole>(_db);
    public IRepository<ApplicationPermission> Permissions         => new Repository<ApplicationPermission>(_db);
    public IRepository<FeatureFlag>          FeatureFlags         => new Repository<FeatureFlag>(_db);
    public IRepository<RefreshToken>         RefreshTokens        => new Repository<RefreshToken>(_db);
    public IRepository<Category>             Categories           => new Repository<Category>(_db);
    public IRepository<Customer>             Customers            => new Repository<Customer>(_db);
    public IRepository<Supplier>             Suppliers            => new Repository<Supplier>(_db);
    public IRepository<Expense>              Expenses             => new Repository<Expense>(_db);

    // ── Licensing ─────────────────────────────────────────────────────────
    public IRepository<License>              Licenses             => new Repository<License>(_db);
    public IRepository<DeviceRegistration>   DeviceRegistrations  => new Repository<DeviceRegistration>(_db);

    // ── POS / Inventory ───────────────────────────────────────────────────
    public IRepository<Product>              Products             => new Repository<Product>(_db);
    public IRepository<StockItem>            StockItems           => new Repository<StockItem>(_db);
    public IRepository<StockMovement>        StockMovements       => new Repository<StockMovement>(_db);
    public IRepository<SaleOrder>            SaleOrders           => new Repository<SaleOrder>(_db);
    public IRepository<SaleOrderItem>        SaleOrderItems       => new Repository<SaleOrderItem>(_db);
    public IRepository<SaleRefund>           SaleRefunds          => new Repository<SaleRefund>(_db);
    public IRepository<Payment>              Payments             => new Repository<Payment>(_db);
    public IRepository<PurchaseOrder>        PurchaseOrders       => new Repository<PurchaseOrder>(_db);
    public IRepository<PurchaseOrderItem>    PurchaseOrderItems   => new Repository<PurchaseOrderItem>(_db);

    // ── Marketplace ───────────────────────────────────────────────────────
    public IRepository<Vendor>               Vendors              => new Repository<Vendor>(_db);
    public IRepository<VendorCategory>       VendorCategories     => new Repository<VendorCategory>(_db);
    public IRepository<VendorService>        VendorServices       => new Repository<VendorService>(_db);
    public IRepository<VendorAvailability>   VendorAvailabilities => new Repository<VendorAvailability>(_db);
    public IRepository<Booking>              Bookings             => new Repository<Booking>(_db);
    public IRepository<BookingPayment>       BookingPayments      => new Repository<BookingPayment>(_db);
    public IRepository<VendorReview>         VendorReviews        => new Repository<VendorReview>(_db);
    public IRepository<VendorPayment>        VendorPayments       => new Repository<VendorPayment>(_db);

    // ── Sync & Audit ──────────────────────────────────────────────────────
    public IRepository<SyncQueue>            SyncQueue            => new Repository<SyncQueue>(_db);
    public IRepository<SyncLog>              SyncLogs             => new Repository<SyncLog>(_db);
    public IRepository<AuditLog>             AuditLogs            => new Repository<AuditLog>(_db);
    public IRepository<PlatformConfig>       PlatformConfigs      => new Repository<PlatformConfig>(_db);

    // ── Transactions ──────────────────────────────────────────────────────
    public async Task<int> SaveChangesAsync(CancellationToken ct = default)
        => await _db.SaveChangesAsync(ct);

    public async Task BeginTransactionAsync(CancellationToken ct = default)
        => _transaction = await _db.Database.BeginTransactionAsync(ct);

    public async Task CommitTransactionAsync(CancellationToken ct = default)
    {
        if (_transaction is null) return;
        await _transaction.CommitAsync(ct);
        await _transaction.DisposeAsync();
        _transaction = null;
    }

    public async Task RollbackTransactionAsync(CancellationToken ct = default)
    {
        if (_transaction is null) return;
        await _transaction.RollbackAsync(ct);
        await _transaction.DisposeAsync();
        _transaction = null;
    }

    public void Dispose() => _db.Dispose();
    public async ValueTask DisposeAsync() => await _db.DisposeAsync();
}
