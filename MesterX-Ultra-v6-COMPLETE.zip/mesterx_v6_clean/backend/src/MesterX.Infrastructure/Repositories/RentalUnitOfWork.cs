using MesterX.Domain.Entities;
using MesterX.Domain.Interfaces;
using MesterX.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Storage;

namespace MesterX.Infrastructure.Repositories;

// ═══════════════════════════════════════════════════════════════════════════
// RENTAL UNIT OF WORK
// ═══════════════════════════════════════════════════════════════════════════
// نفس DbContext الموجود — لا نعمل DbContext جديد.
// هذا يضمن أن transactions تشمل POS + Rental في نفس الوقت لو احتجنا.
// ═══════════════════════════════════════════════════════════════════════════

public class RentalUnitOfWork : IRentalUnitOfWork
{
    private readonly MesterXDbContext _db;
    private IDbContextTransaction? _tx;

    public RentalUnitOfWork(MesterXDbContext db)
    {
        _db = db;

        // ── Rental Repos ──────────────────────────────────────────────────
        RentalAssets        = new Repository<RentalAsset>(db);
        RentalAssetImages   = new Repository<RentalAssetImage>(db);
        RentalBookings      = new Repository<RentalBooking>(db);
        RentalBookingItems  = new Repository<RentalBookingItem>(db);
        RentalPayments      = new Repository<RentalPayment>(db);
        DamageReports       = new Repository<DamageReport>(db);
        MaintenanceLogs     = new Repository<MaintenanceLog>(db);
        MarketplaceListings = new Repository<MarketplaceListing>(db);

        // ── Shared (read) ─────────────────────────────────────────────────
        Tenants   = new Repository<Tenant>(db);
        Customers = new Repository<Customer>(db);
        Users     = new Repository<User>(db);
        Plans     = new Repository<Plan>(db);
        Licenses  = new Repository<License>(db);
        AuditLogs = new Repository<AuditLog>(db);
    }

    // ── Rental ────────────────────────────────────────────────────────────
    public IRepository<RentalAsset>        RentalAssets        { get; }
    public IRepository<RentalAssetImage>   RentalAssetImages   { get; }
    public IRepository<RentalBooking>      RentalBookings      { get; }
    public IRepository<RentalBookingItem>  RentalBookingItems  { get; }
    public IRepository<RentalPayment>      RentalPayments      { get; }
    public IRepository<DamageReport>       DamageReports       { get; }
    public IRepository<MaintenanceLog>     MaintenanceLogs     { get; }
    public IRepository<MarketplaceListing> MarketplaceListings { get; }

    // ── Shared ────────────────────────────────────────────────────────────
    public IRepository<Tenant>   Tenants   { get; }
    public IRepository<Customer> Customers { get; }
    public IRepository<User>     Users     { get; }
    public IRepository<Plan>     Plans     { get; }
    public IRepository<License>  Licenses  { get; }
    public IRepository<AuditLog> AuditLogs { get; }

    // ── Persistence ───────────────────────────────────────────────────────
    public Task<int> SaveChangesAsync(CancellationToken ct = default)
        => _db.SaveChangesAsync(ct);

    public async Task BeginTransactionAsync(CancellationToken ct = default)
        => _tx = await _db.Database.BeginTransactionAsync(ct);

    public async Task CommitTransactionAsync(CancellationToken ct = default)
    {
        if (_tx is not null) await _tx.CommitAsync(ct);
    }

    public async Task RollbackTransactionAsync(CancellationToken ct = default)
    {
        if (_tx is not null) await _tx.RollbackAsync(ct);
    }

    public void Dispose()
    {
        _tx?.Dispose();
        // لا نعمل Dispose لـ _db هنا — هو Scoped وسيُتخلص منه بالـ DI Container
    }
}
