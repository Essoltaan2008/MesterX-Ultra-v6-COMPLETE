using System.Data.Common;
using MesterX.Application.Services;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Npgsql;
using System.Threading;
using System.Threading.Tasks;

namespace MesterX.Infrastructure.Data;

public class TenantRLSInterceptor : DbConnectionInterceptor
{
    private readonly ITenantProvider _tenantProvider;

    public TenantRLSInterceptor(ITenantProvider tenantProvider)
    {
        _tenantProvider = tenantProvider;
    }

    public override void ConnectionOpened(DbConnection connection, ConnectionEndEventData eventData)
    {
        SetTenantId(connection);
        base.ConnectionOpened(connection, eventData);
    }

    public override async Task ConnectionOpenedAsync(DbConnection connection, ConnectionEndEventData eventData, CancellationToken cancellationToken = default)
    {
        await SetTenantIdAsync(connection);
        await base.ConnectionOpenedAsync(connection, eventData, cancellationToken);
    }

    private void SetTenantId(DbConnection connection)
    {
        var tenantId = _tenantProvider.TenantId;
        if (tenantId.HasValue)
        {
            using var command = connection.CreateCommand();
            command.CommandText = $"SET app.current_tenant_id = '{tenantId.Value}';";
            command.ExecuteNonQuery();
        }
    }

    private async Task SetTenantIdAsync(DbConnection connection)
    {
        var tenantId = _tenantProvider.TenantId;
        if (tenantId.HasValue)
        {
            using var command = connection.CreateCommand();
            command.CommandText = $"SET app.current_tenant_id = '{tenantId.Value}';";
            await command.ExecuteNonQueryAsync();
        }
    }
}
