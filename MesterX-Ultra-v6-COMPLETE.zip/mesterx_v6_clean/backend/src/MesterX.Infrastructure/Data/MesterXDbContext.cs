using MesterX.Domain.Entities.Audit;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.Marketplace;
using MesterX.Domain.Entities.Platform;
using MesterX.Domain.Entities.Pos;
using MesterX.Domain.Entities.Restaurant;
using MesterX.Domain.Entities.Sync;
using MesterX.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace MesterX.Infrastructure.Data;

public class MesterXDbContext : DbContext
{
    public MesterXDbContext(DbContextOptions<MesterXDbContext> options) : base(options) { }

    // ─── Core ──────────────────────────────────────────────────────────────
    public DbSet<Tenant>              Tenants              => Set<Tenant>();
    public DbSet<Branch>              Branches             => Set<Branch>();
    public DbSet<ApplicationUser>     Users                => Set<ApplicationUser>();
    public DbSet<ApplicationRole>     Roles                => Set<ApplicationRole>();
    public DbSet<ApplicationPermission> Permissions        => Set<ApplicationPermission>();
    public DbSet<FeatureFlag>         FeatureFlags         => Set<FeatureFlag>();
    public DbSet<RefreshToken>        RefreshTokens        => Set<RefreshToken>();
    public DbSet<Category>            Categories           => Set<Category>();
    public DbSet<Customer>            Customers            => Set<Customer>();
    public DbSet<Supplier>            Suppliers            => Set<Supplier>();
    public DbSet<Expense>             Expenses             => Set<Expense>();

    // ─── Licensing ─────────────────────────────────────────────────────────
    public DbSet<License>             Licenses             => Set<License>();
    public DbSet<DeviceRegistration>  DeviceRegistrations  => Set<DeviceRegistration>();

    // ─── POS / Inventory ───────────────────────────────────────────────────
    public DbSet<Product>             Products             => Set<Product>();
    public DbSet<StockItem>           StockItems           => Set<StockItem>();
    public DbSet<StockMovement>       StockMovements       => Set<StockMovement>();
    public DbSet<SaleOrder>           SaleOrders           => Set<SaleOrder>();
    public DbSet<SaleOrderItem>       SaleOrderItems       => Set<SaleOrderItem>();
    public DbSet<SaleRefund>          SaleRefunds          => Set<SaleRefund>();
    public DbSet<Payment>             Payments             => Set<Payment>();
    public DbSet<PurchaseOrder>       PurchaseOrders       => Set<PurchaseOrder>();
    public DbSet<PurchaseOrderItem>   PurchaseOrderItems   => Set<PurchaseOrderItem>();

    // ─── Marketplace / Vendor ──────────────────────────────────────────────
    public DbSet<Vendor>              Vendors              => Set<Vendor>();
    public DbSet<VendorCategory>      VendorCategories     => Set<VendorCategory>();
    public DbSet<VendorService>       VendorServices       => Set<VendorService>();
    public DbSet<VendorAvailability>  VendorAvailabilities => Set<VendorAvailability>();
    public DbSet<Booking>             Bookings             => Set<Booking>();
    public DbSet<BookingPayment>      BookingPayments      => Set<BookingPayment>();
    public DbSet<BookingService>      BookingServices      => Set<BookingService>();
    public DbSet<BookingTimeline>     BookingTimelines     => Set<BookingTimeline>();
    public DbSet<VendorReview>        VendorReviews        => Set<VendorReview>();
    public DbSet<VendorPayment>       VendorPayments       => Set<VendorPayment>();

    // ─── Restaurant ────────────────────────────────────────────────────────
    public DbSet<RestaurantCategory>      RestaurantCategories     => Set<RestaurantCategory>();
    public DbSet<RestaurantMenuItem>      RestaurantMenuItems      => Set<RestaurantMenuItem>();
    public DbSet<MenuItemVariant>         MenuItemVariants         => Set<MenuItemVariant>();
    public DbSet<MenuModifierGroup>       MenuModifierGroups       => Set<MenuModifierGroup>();
    public DbSet<MenuModifier>            MenuModifiers            => Set<MenuModifier>();
    public DbSet<BranchMenuOverride>      BranchMenuOverrides      => Set<BranchMenuOverride>();
    public DbSet<BranchItemAvailability>  BranchItemAvailability   => Set<BranchItemAvailability>();
    public DbSet<FloorPlan>               FloorPlans               => Set<FloorPlan>();
    public DbSet<RestaurantTable>         RestaurantTables         => Set<RestaurantTable>();
    public DbSet<TableSession>            TableSessions            => Set<TableSession>();
    public DbSet<SessionPayment>          SessionPayments          => Set<SessionPayment>();
    public DbSet<TableReservation>        TableReservations        => Set<TableReservation>();
    public DbSet<KitchenStation>          KitchenStations          => Set<KitchenStation>();
    public DbSet<DineInOrder>             DineInOrders             => Set<DineInOrder>();
    public DbSet<DineInOrderItem>         DineInOrderItems         => Set<DineInOrderItem>();
    public DbSet<OrderItemModifier>       OrderItemModifiers       => Set<OrderItemModifier>();
    public DbSet<KitchenTicket>           KitchenTickets           => Set<KitchenTicket>();
    public DbSet<KitchenTicketItem>       KitchenTicketItems       => Set<KitchenTicketItem>();

    // ─── Sync & Audit ──────────────────────────────────────────────────────
    public DbSet<SyncQueue>           SyncQueue            => Set<SyncQueue>();
    public DbSet<SyncLog>             SyncLogs             => Set<SyncLog>();
    public DbSet<AuditLog>            AuditLogs            => Set<AuditLog>();
    public DbSet<PlatformConfig>      PlatformConfigs      => Set<PlatformConfig>();

    // ════════════════════════════════════════════════════════════════════════
    protected override void OnModelCreating(ModelBuilder m)
    {
        base.OnModelCreating(m);

        // ─── Tenant ────────────────────────────────────────────────────────
        m.Entity<Tenant>(e =>
        {
            e.ToTable("tenants");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.Slug).IsUnique();
            e.Property(x => x.VatRate).HasColumnType("decimal(5,4)").HasDefaultValue(0.14m);
            e.Property(x => x.Currency).HasMaxLength(10).HasDefaultValue("EGP");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── Branch ────────────────────────────────────────────────────────
        m.Entity<Branch>(e =>
        {
            e.ToTable("branches");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TenantId);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── ApplicationUser ───────────────────────────────────────────────
        m.Entity<ApplicationUser>(e =>
        {
            e.ToTable("users");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.Email).IsUnique();
            e.HasIndex(x => x.TenantId);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── License ───────────────────────────────────────────────────────
        m.Entity<License>(e =>
        {
            e.ToTable("licenses");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TenantId);
            e.HasIndex(x => x.LicenseKeyHash).IsUnique();
            e.Property(x => x.AmountPaid).HasColumnType("decimal(12,2)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── DeviceRegistration ────────────────────────────────────────────
        m.Entity<DeviceRegistration>(e =>
        {
            e.ToTable("device_registrations");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.LicenseId, x.FingerprintHash }).IsUnique();
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── Category ──────────────────────────────────────────────────────
        m.Entity<Category>(e =>
        {
            e.ToTable("categories");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TenantId);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── Customer ──────────────────────────────────────────────────────
        m.Entity<Customer>(e =>
        {
            e.ToTable("customers");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TenantId);
            e.HasIndex(x => new { x.TenantId, x.Phone });
            e.Property(x => x.TotalPurchases).HasColumnType("decimal(14,2)");
            e.Property(x => x.CreditLimit).HasColumnType("decimal(12,2)");
            e.Property(x => x.OutstandingBalance).HasColumnType("decimal(12,2)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── Supplier ──────────────────────────────────────────────────────
        m.Entity<Supplier>(e =>
        {
            e.ToTable("suppliers");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TenantId);
            e.Property(x => x.CreditLimit).HasColumnType("decimal(12,2)");
            e.Property(x => x.OutstandingBalance).HasColumnType("decimal(12,2)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── Expense ───────────────────────────────────────────────────────
        m.Entity<Expense>(e =>
        {
            e.ToTable("expenses");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TenantId);
            e.HasIndex(x => x.ExpenseDate);
            e.Property(x => x.Amount).HasColumnType("decimal(12,2)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── Product ───────────────────────────────────────────────────────
        m.Entity<Product>(e =>
        {
            e.ToTable("products");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.TenantId, x.SKU }).IsUnique();
            e.HasIndex(x => x.Barcode);
            e.HasIndex(x => x.TenantId);
            e.Property(x => x.CostPrice).HasColumnType("decimal(12,2)");
            e.Property(x => x.SellPrice).HasColumnType("decimal(12,2)");
            e.Property(x => x.VatRate).HasColumnType("decimal(5,4)").HasDefaultValue(0.14m);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── StockItem ─────────────────────────────────────────────────────
        m.Entity<StockItem>(e =>
        {
            e.ToTable("stock_items");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.ProductId, x.BranchId }).IsUnique();
            e.HasIndex(x => x.TenantId);
            e.Property(x => x.Quantity).HasColumnType("decimal(12,4)");
            e.Property(x => x.ReservedQuantity).HasColumnType("decimal(12,4)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── StockMovement ─────────────────────────────────────────────────
        m.Entity<StockMovement>(e =>
        {
            e.ToTable("stock_movements");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TenantId);
            e.HasIndex(x => x.CreatedAt);
            e.Property(x => x.QuantityBefore).HasColumnType("decimal(12,4)");
            e.Property(x => x.QuantityChange).HasColumnType("decimal(12,4)");
            e.Property(x => x.QuantityAfter).HasColumnType("decimal(12,4)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── SaleOrder ─────────────────────────────────────────────────────
        m.Entity<SaleOrder>(e =>
        {
            e.ToTable("sale_orders");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.OrderNumber).IsUnique();
            e.HasIndex(x => x.TenantId);
            e.HasIndex(x => x.BranchId);
            e.HasIndex(x => x.CreatedAt);
            e.Property(x => x.SubTotal).HasColumnType("decimal(14,2)");
            e.Property(x => x.VatAmount).HasColumnType("decimal(12,2)");
            e.Property(x => x.DiscountAmount).HasColumnType("decimal(12,2)");
            e.Property(x => x.TotalAmount).HasColumnType("decimal(14,2)");
            e.Property(x => x.AmountPaid).HasColumnType("decimal(14,2)");
            e.Property(x => x.ChangeGiven).HasColumnType("decimal(12,2)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── SaleOrderItem ─────────────────────────────────────────────────
        m.Entity<SaleOrderItem>(e =>
        {
            e.ToTable("sale_order_items");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.SaleOrderId);
            e.HasIndex(x => x.TenantId);
            e.Property(x => x.Quantity).HasColumnType("decimal(12,4)");
            e.Property(x => x.UnitPrice).HasColumnType("decimal(12,2)");
            e.Property(x => x.VatAmount).HasColumnType("decimal(12,2)");
            e.Property(x => x.DiscountAmount).HasColumnType("decimal(12,2)");
            e.Property(x => x.LineTotal).HasColumnType("decimal(14,2)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── Payment ───────────────────────────────────────────────────────
        m.Entity<Payment>(e =>
        {
            e.ToTable("payments");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.SaleOrderId);
            e.HasIndex(x => x.TenantId);
            e.Property(x => x.Amount).HasColumnType("decimal(12,2)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── PurchaseOrder ─────────────────────────────────────────────────
        m.Entity<PurchaseOrder>(e =>
        {
            e.ToTable("purchase_orders");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.PONumber).IsUnique();
            e.HasIndex(x => x.TenantId);
            e.Property(x => x.TotalAmount).HasColumnType("decimal(14,2)");
            e.Property(x => x.AmountPaid).HasColumnType("decimal(12,2)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<PurchaseOrderItem>(e =>
        {
            e.ToTable("purchase_order_items");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.PurchaseOrderId);
            e.Property(x => x.QuantityOrdered).HasColumnType("decimal(12,4)");
            e.Property(x => x.QuantityReceived).HasColumnType("decimal(12,4)");
            e.Property(x => x.UnitCost).HasColumnType("decimal(12,2)");
            e.Property(x => x.LineTotal).HasColumnType("decimal(14,2)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── Marketplace / Vendor ──────────────────────────────────────────
        m.Entity<Vendor>(e =>
        {
            e.ToTable("vendors");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TenantId);
            e.HasIndex(x => x.Status);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<VendorCategory>(e => { e.ToTable("vendor_categories"); e.HasKey(x => x.Id); e.HasQueryFilter(x => !x.IsDeleted); });
        m.Entity<VendorService>(e =>  { e.ToTable("vendor_services");   e.HasKey(x => x.Id); e.Property(x => x.BasePrice).HasColumnType("decimal(12,2)"); e.HasQueryFilter(x => !x.IsDeleted); });
        m.Entity<VendorAvailability>(e => { e.ToTable("vendor_availabilities"); e.HasKey(x => x.Id); e.HasQueryFilter(x => !x.IsDeleted); });
        m.Entity<VendorReview>(e => { e.ToTable("vendor_reviews"); e.HasKey(x => x.Id); e.HasQueryFilter(x => !x.IsDeleted); });
        m.Entity<VendorPayment>(e => { e.ToTable("vendor_payments"); e.HasKey(x => x.Id); e.Property(x => x.Amount).HasColumnType("decimal(12,2)"); e.HasQueryFilter(x => !x.IsDeleted); });

        m.Entity<Booking>(e =>
        {
            e.ToTable("bookings");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TenantId);
            e.HasIndex(x => x.VendorId);
            e.HasIndex(x => x.Status);
            e.Property(x => x.TotalPrice).HasColumnType("decimal(14,2)");
            e.Property(x => x.DepositAmount).HasColumnType("decimal(12,2)");
            e.Property(x => x.RemainingAmount).HasColumnType("decimal(12,2)");
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<BookingPayment>(e => { e.ToTable("booking_payments"); e.HasKey(x => x.Id); e.HasQueryFilter(x => !x.IsDeleted); });
        m.Entity<BookingService>(e => { e.ToTable("booking_services"); e.HasKey(x => x.Id); e.HasQueryFilter(x => !x.IsDeleted); });
        m.Entity<BookingTimeline>(e => { e.ToTable("booking_timeline"); e.HasKey(x => x.Id); e.HasQueryFilter(x => !x.IsDeleted); });

        // ─── Sync ──────────────────────────────────────────────────────────
        m.Entity<SyncQueue>(e =>
        {
            e.ToTable("sync_queue");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.TenantId, x.IdempotencyKey }).IsUnique();
            e.HasIndex(x => x.Status);
            e.HasIndex(x => x.TenantId);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<SyncLog>(e =>
        {
            e.ToTable("sync_logs");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TenantId);
            e.HasIndex(x => x.SyncStartedAt);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ─── Audit ─────────────────────────────────────────────────────────
        m.Entity<AuditLog>(e =>
        {
            e.ToTable("audit_logs");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TenantId);
            e.HasIndex(x => x.UserId);
            e.HasIndex(x => x.CreatedAt);
        });

        // ─── PlatformConfig ────────────────────────────────────────────────
        m.Entity<PlatformConfig>(e =>
        {
            e.ToTable("platform_configs");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.Key).IsUnique();
        });

        // ─── Restaurant Module ─────────────────────────────────────────────
        m.ConfigureRestaurantSchema();
    }

    // ─── Auto Timestamps ───────────────────────────────────────────────────
    public override async Task<int> SaveChangesAsync(CancellationToken ct = default)
    {
        var now = DateTime.UtcNow;
        foreach (var entry in ChangeTracker.Entries<BaseEntity>())
        {
            switch (entry.State)
            {
                case Microsoft.EntityFrameworkCore.EntityState.Added:
                    entry.Entity.CreatedAt = now;
                    entry.Entity.UpdatedAt = now;
                    break;
                case Microsoft.EntityFrameworkCore.EntityState.Modified:
                    entry.Entity.UpdatedAt = now;
                    entry.Entity.Version++;
                    break;
            }
        }
        return await base.SaveChangesAsync(ct);
    }
}
