using Microsoft.EntityFrameworkCore;
using MesterX.Domain.Entities;

namespace MesterX.Infrastructure.Data;

// ═══════════════════════════════════════════════════════════════════════════
// RENTAL EF CONFIGURATION
// ═══════════════════════════════════════════════════════════════════════════
// هذا الملف يُضاف كـ static extension method على MesterXDbContext.
// في OnModelCreating اتصل به هكذا:
//
//     protected override void OnModelCreating(ModelBuilder m)
//     {
//         base.OnModelCreating(m);
//         m.ConfigurePosSchema();     // الكود الموجود
//         m.ConfigureRentalSchema();  // ← أضف هذا السطر فقط
//     }
//
// وفي DbContext أضف الـ DbSets التالية:
//
//     public DbSet<RentalAsset>       RentalAssets      => Set<RentalAsset>();
//     public DbSet<RentalAssetImage>  RentalAssetImages => Set<RentalAssetImage>();
//     public DbSet<RentalBooking>     RentalBookings    => Set<RentalBooking>();
//     public DbSet<RentalBookingItem> RentalBookingItems => Set<RentalBookingItem>();
//     public DbSet<RentalPayment>     RentalPayments    => Set<RentalPayment>();
//     public DbSet<DamageReport>      DamageReports     => Set<DamageReport>();
//     public DbSet<MaintenanceLog>    MaintenanceLogs   => Set<MaintenanceLog>();
//     public DbSet<MarketplaceListing> MarketplaceListings => Set<MarketplaceListing>();
// ═══════════════════════════════════════════════════════════════════════════

public static class RentalDbConfiguration
{
    public static void ConfigureRentalSchema(this ModelBuilder m)
    {
        // ── RENTAL ASSETS ──────────────────────────────────────────────────
        m.Entity<RentalAsset>(e =>
        {
            // schema منفصل = لا تضارب مع أي جدول موجود
            e.ToTable("rental_assets", "rental");
            e.HasKey(x => x.Id);

            e.HasIndex(x => new { x.TenantId, x.AssetCode }).IsUnique();
            e.HasIndex(x => new { x.TenantId, x.Status });
            e.HasIndex(x => new { x.TenantId, x.Category });
            e.HasIndex(x => x.Barcode).HasFilter("barcode IS NOT NULL");

            e.Property(x => x.Name).HasMaxLength(200);
            e.Property(x => x.AssetCode).HasMaxLength(30);
            e.Property(x => x.RentalPricePerDay).HasColumnType("decimal(12,2)");
            e.Property(x => x.RentalPricePerHour).HasColumnType("decimal(12,2)");
            e.Property(x => x.SalePrice).HasColumnType("decimal(12,2)");
            e.Property(x => x.DepositAmount).HasColumnType("decimal(12,2)");
            e.Property(x => x.PurchaseCost).HasColumnType("decimal(12,2)");
            e.Property(x => x.LatePenaltyPerDay).HasColumnType("decimal(12,2)");
            e.Property(x => x.TotalRevenue).HasColumnType("decimal(14,2)");

            // Global query filter — soft delete + tenant isolation
            e.HasQueryFilter(x => !x.IsDeleted);

            e.HasOne<Tenant>().WithMany()
             .HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Cascade);
        });

        // ── RENTAL ASSET IMAGES ────────────────────────────────────────────
        m.Entity<RentalAssetImage>(e =>
        {
            e.ToTable("rental_asset_images", "rental");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.AssetId);

            e.HasOne(x => x.Asset).WithMany(a => a.Images)
             .HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Cascade);

            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ── RENTAL BOOKINGS ────────────────────────────────────────────────
        m.Entity<RentalBooking>(e =>
        {
            e.ToTable("rental_bookings", "rental");
            e.HasKey(x => x.Id);

            e.HasIndex(x => new { x.TenantId, x.BookingNumber }).IsUnique();
            e.HasIndex(x => new { x.TenantId, x.Status });
            e.HasIndex(x => new { x.TenantId, x.CustomerId });
            e.HasIndex(x => new { x.TenantId, x.PickupDate });
            e.HasIndex(x => new { x.TenantId, x.ReturnDueDate });

            e.Property(x => x.BookingNumber).HasMaxLength(30);
            e.Property(x => x.SubTotal).HasColumnType("decimal(12,2)");
            e.Property(x => x.DiscountAmount).HasColumnType("decimal(12,2)");
            e.Property(x => x.VatAmount).HasColumnType("decimal(12,2)");
            e.Property(x => x.TotalAmount).HasColumnType("decimal(12,2)");
            e.Property(x => x.DepositRequired).HasColumnType("decimal(12,2)");
            e.Property(x => x.DepositPaid).HasColumnType("decimal(12,2)");
            e.Property(x => x.AmountPaid).HasColumnType("decimal(12,2)");
            e.Property(x => x.LatePenaltyTotal).HasColumnType("decimal(12,2)");

            // Computed props = لا يُحفظوا في DB
            e.Ignore(x => x.AmountDue);
            e.Ignore(x => x.DepositBalance);
            e.Ignore(x => x.IsOverdue);

            // Customer — يرجع لجدول customers في public schema
            // لا يوجد FK conflict لأن Customer.Id هو Guid فريد عالمياً
            e.HasOne(x => x.Customer).WithMany(c => c.RentalBookings)
             .HasForeignKey(x => x.CustomerId).OnDelete(DeleteBehavior.Restrict);

            e.HasOne(x => x.HandledBy).WithMany()
             .HasForeignKey(x => x.HandledByUserId).OnDelete(DeleteBehavior.SetNull);

            e.HasOne<Tenant>().WithMany()
             .HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Cascade);

            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ── RENTAL BOOKING ITEMS ───────────────────────────────────────────
        m.Entity<RentalBookingItem>(e =>
        {
            e.ToTable("rental_booking_items", "rental");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.BookingId);
            e.HasIndex(x => x.AssetId);

            e.Property(x => x.UnitPrice).HasColumnType("decimal(12,2)");
            e.Property(x => x.DepositAmount).HasColumnType("decimal(12,2)");
            e.Property(x => x.LineTotal).HasColumnType("decimal(12,2)");

            e.HasOne(x => x.Booking).WithMany(b => b.Items)
             .HasForeignKey(x => x.BookingId).OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.Asset).WithMany(a => a.BookingItems)
             .HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Restrict);

            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ── RENTAL PAYMENTS ────────────────────────────────────────────────
        m.Entity<RentalPayment>(e =>
        {
            e.ToTable("rental_payments", "rental");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.BookingId);
            e.HasIndex(x => new { x.TenantId, x.PaymentDate });

            e.Property(x => x.Amount).HasColumnType("decimal(12,2)");

            e.HasOne(x => x.Booking).WithMany(b => b.Payments)
             .HasForeignKey(x => x.BookingId).OnDelete(DeleteBehavior.Cascade);

            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ── DAMAGE REPORTS ─────────────────────────────────────────────────
        m.Entity<DamageReport>(e =>
        {
            e.ToTable("damage_reports", "rental");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.BookingId);
            e.HasIndex(x => x.AssetId);

            e.Property(x => x.CompensationAmount).HasColumnType("decimal(12,2)");

            e.HasOne(x => x.Booking).WithMany(b => b.DamageReports)
             .HasForeignKey(x => x.BookingId).OnDelete(DeleteBehavior.Restrict);

            e.HasOne(x => x.Asset).WithMany(a => a.DamageReports)
             .HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Restrict);

            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ── MAINTENANCE LOGS ───────────────────────────────────────────────
        m.Entity<MaintenanceLog>(e =>
        {
            e.ToTable("maintenance_logs", "rental");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.AssetId);
            e.HasIndex(x => new { x.TenantId, x.IsCompleted });

            e.Property(x => x.Cost).HasColumnType("decimal(12,2)");

            e.HasOne(x => x.Asset).WithMany(a => a.MaintenanceLogs)
             .HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.DamageReport).WithMany()
             .HasForeignKey(x => x.DamageReportId).OnDelete(DeleteBehavior.SetNull);

            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ── MARKETPLACE LISTINGS ───────────────────────────────────────────
        m.Entity<MarketplaceListing>(e =>
        {
            e.ToTable("marketplace_listings", "rental");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.TenantId, x.IsVisible });
            e.HasIndex(x => x.AssetId).IsUnique(); // كل أصل له listing واحد

            e.HasOne(x => x.Asset).WithMany()
             .HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Cascade);

            e.HasQueryFilter(x => !x.IsDeleted);
        });
    }
}
