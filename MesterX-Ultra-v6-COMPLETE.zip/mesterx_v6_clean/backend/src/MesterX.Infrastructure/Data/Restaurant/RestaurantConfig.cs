using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using MesterX.Domain.Entities;
using MesterX.Domain.Interfaces;

namespace MesterX.Infrastructure.Data;

// ═══════════════════════════════════════════════════════════════════════════
// RESTAURANT SCHEMA CONFIGURATION
// يُستدعى من MesterXDbContext.OnModelCreating
// ═══════════════════════════════════════════════════════════════════════════

public static class RestaurantSchemaConfig
{
    public static void ConfigureRestaurantSchema(this ModelBuilder m)
    {
        // ── Menu ─────────────────────────────────────────────────────────

        m.Entity<RestaurantCategory>(e =>
        {
            e.ToTable("restaurant_categories", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.TenantId, x.SortOrder });
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<RestaurantMenuItem>(e =>
        {
            e.ToTable("restaurant_menu_items", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.TenantId, x.CategoryId, x.SortOrder });
            e.HasIndex(x => new { x.TenantId, x.IsActive });
            e.Property(x => x.BasePrice).HasColumnType("decimal(10,2)");
            e.HasOne(x => x.Category).WithMany(c => c.Items)
             .HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<MenuItemVariant>(e =>
        {
            e.ToTable("restaurant_menu_item_variants", "restaurant");
            e.HasKey(x => x.Id);
            e.Property(x => x.PriceDelta).HasColumnType("decimal(10,2)");
            e.HasOne(x => x.MenuItem).WithMany(i => i.Variants)
             .HasForeignKey(x => x.MenuItemId).OnDelete(DeleteBehavior.Cascade);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<MenuModifierGroup>(e =>
        {
            e.ToTable("restaurant_modifier_groups", "restaurant");
            e.HasKey(x => x.Id);
            e.HasOne(x => x.MenuItem).WithMany(i => i.ModifierGroups)
             .HasForeignKey(x => x.MenuItemId).OnDelete(DeleteBehavior.Cascade);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<MenuModifier>(e =>
        {
            e.ToTable("restaurant_modifiers", "restaurant");
            e.HasKey(x => x.Id);
            e.Property(x => x.ExtraPrice).HasColumnType("decimal(10,2)");
            e.HasOne(x => x.Group).WithMany(g => g.Modifiers)
             .HasForeignKey(x => x.ModifierGroupId).OnDelete(DeleteBehavior.Cascade);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<BranchMenuOverride>(e =>
        {
            e.ToTable("restaurant_branch_menu_overrides", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.BranchId, x.MenuItemId }).IsUnique();
            e.Property(x => x.OverridePrice).HasColumnType("decimal(10,2)");
            e.HasOne(x => x.MenuItem).WithMany(i => i.BranchOverrides)
             .HasForeignKey(x => x.MenuItemId).OnDelete(DeleteBehavior.Cascade);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<BranchItemAvailability>(e =>
        {
            e.ToTable("restaurant_item_availability", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.BranchId, x.MenuItemId }).IsUnique();
            e.HasIndex(x => new { x.BranchId, x.Status });
            e.HasOne(x => x.MenuItem).WithMany(i => i.Availabilities)
             .HasForeignKey(x => x.MenuItemId).OnDelete(DeleteBehavior.Cascade);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ── Floor Plans & Tables ──────────────────────────────────────────

        m.Entity<FloorPlan>(e =>
        {
            e.ToTable("restaurant_floor_plans", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.BranchId, x.SortOrder });
            e.HasOne(x => x.Branch).WithMany()
             .HasForeignKey(x => x.BranchId).OnDelete(DeleteBehavior.Restrict);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<RestaurantTable>(e =>
        {
            e.ToTable("restaurant_tables", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.BranchId, x.TableNumber }).IsUnique();
            e.HasIndex(x => new { x.BranchId, x.Status });
            e.HasIndex(x => x.QrToken).IsUnique().HasFilter("qr_token IS NOT NULL");
            e.HasOne(x => x.Branch).WithMany()
             .HasForeignKey(x => x.BranchId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.FloorPlan).WithMany(f => f.Tables)
             .HasForeignKey(x => x.FloorPlanId).OnDelete(DeleteBehavior.Restrict);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<TableSession>(e =>
        {
            e.ToTable("restaurant_table_sessions", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.BranchId, x.Status });
            e.HasIndex(x => new { x.TableId, x.Status });
            foreach (var col in new[] { "SubTotal","ServiceCharge","VatAmount","TotalAmount","AmountPaid" })
                e.Property(col).HasColumnType("decimal(12,2)");
            e.Ignore(x => x.Remaining);
            e.HasOne(x => x.Table).WithMany(t => t.Sessions)
             .HasForeignKey(x => x.TableId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.OpenedBy).WithMany()
             .HasForeignKey(x => x.OpenedByUserId).OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.Customer).WithMany()
             .HasForeignKey(x => x.CustomerId).OnDelete(DeleteBehavior.SetNull);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<SessionPayment>(e =>
        {
            e.ToTable("restaurant_session_payments", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.TableSessionId);
            e.Property(x => x.Amount).HasColumnType("decimal(12,2)");
            e.HasOne(x => x.Session).WithMany(s => s.Payments)
             .HasForeignKey(x => x.TableSessionId).OnDelete(DeleteBehavior.Cascade);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<TableReservation>(e =>
        {
            e.ToTable("restaurant_reservations", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.BranchId, x.ReservationAt });
            e.HasIndex(x => new { x.TableId, x.ReservationAt });
            e.HasOne(x => x.Table).WithMany(t => t.Reservations)
             .HasForeignKey(x => x.TableId).OnDelete(DeleteBehavior.Restrict);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ── Kitchen ───────────────────────────────────────────────────────

        m.Entity<KitchenStation>(e =>
        {
            e.ToTable("restaurant_kitchen_stations", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.BranchId, x.IsActive });
            e.Ignore(x => x.SignalRGroup);
            e.HasOne(x => x.Branch).WithMany()
             .HasForeignKey(x => x.BranchId).OnDelete(DeleteBehavior.Restrict);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ── Orders ────────────────────────────────────────────────────────

        m.Entity<DineInOrder>(e =>
        {
            e.ToTable("restaurant_dinein_orders", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.BranchId, x.OrderNumber }).IsUnique();
            e.HasIndex(x => new { x.BranchId, x.Status });
            e.HasIndex(x => x.TableSessionId);
            e.Property(x => x.SubTotal).HasColumnType("decimal(12,2)");
            e.Property(x => x.DiscountAmount).HasColumnType("decimal(12,2)");
            e.Property(x => x.TotalAmount).HasColumnType("decimal(12,2)");
            e.Ignore(x => x.NeedsWaiterConfirm);
            e.Ignore(x => x.IsQROrder);
            e.HasOne(x => x.Session).WithMany(s => s.Orders)
             .HasForeignKey(x => x.TableSessionId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Waiter).WithMany()
             .HasForeignKey(x => x.WaiterId).OnDelete(DeleteBehavior.SetNull);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<DineInOrderItem>(e =>
        {
            e.ToTable("restaurant_order_items", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.DineInOrderId);
            e.Property(x => x.UnitPrice).HasColumnType("decimal(10,2)");
            e.Property(x => x.LineTotal).HasColumnType("decimal(10,2)");
            e.HasOne(x => x.Order).WithMany(o => o.Items)
             .HasForeignKey(x => x.DineInOrderId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.MenuItem).WithMany()
             .HasForeignKey(x => x.MenuItemId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Variant).WithMany()
             .HasForeignKey(x => x.VariantId).OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.KitchenStation).WithMany()
             .HasForeignKey(x => x.KitchenStationId).OnDelete(DeleteBehavior.SetNull);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<OrderItemModifier>(e =>
        {
            e.ToTable("restaurant_order_item_modifiers", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.OrderItemId);
            e.Property(x => x.ExtraPrice).HasColumnType("decimal(10,2)");
            e.HasOne(x => x.OrderItem).WithMany(i => i.Modifiers)
             .HasForeignKey(x => x.OrderItemId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Modifier).WithMany()
             .HasForeignKey(x => x.ModifierId).OnDelete(DeleteBehavior.Restrict);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        // ── Kitchen Tickets ───────────────────────────────────────────────

        m.Entity<KitchenTicket>(e =>
        {
            e.ToTable("restaurant_kitchen_tickets", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.KitchenStationId, x.Status });
            e.HasIndex(x => x.DineInOrderId);
            e.Ignore(x => x.PrepSeconds);
            e.HasOne(x => x.Order).WithMany(o => o.Tickets)
             .HasForeignKey(x => x.DineInOrderId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Station).WithMany(s => s.Tickets)
             .HasForeignKey(x => x.KitchenStationId).OnDelete(DeleteBehavior.Restrict);
            e.HasQueryFilter(x => !x.IsDeleted);
        });

        m.Entity<KitchenTicketItem>(e =>
        {
            e.ToTable("restaurant_kitchen_ticket_items", "restaurant");
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.KitchenTicketId);
            e.HasOne(x => x.Ticket).WithMany(t => t.Items)
             .HasForeignKey(x => x.KitchenTicketId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.OrderItem).WithMany()
             .HasForeignKey(x => x.OrderItemId).OnDelete(DeleteBehavior.Restrict);
            e.HasQueryFilter(x => !x.IsDeleted);
        });
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// RESTAURANT UNIT OF WORK
// يستخدم نفس MesterXDbContext — مفيش DbContext جديد
// ═══════════════════════════════════════════════════════════════════════════

namespace MesterX.Infrastructure.Repositories;

public class RestaurantUnitOfWork : IRestaurantUnitOfWork
{
    private readonly MesterXDbContext _db;
    private IDbContextTransaction? _tx;

    public RestaurantUnitOfWork(MesterXDbContext db)
    {
        _db = db;

        Categories       = new Repository<RestaurantCategory>(db);
        MenuItems        = new Repository<RestaurantMenuItem>(db);
        Variants         = new Repository<MenuItemVariant>(db);
        ModifierGroups   = new Repository<MenuModifierGroup>(db);
        Modifiers        = new Repository<MenuModifier>(db);
        MenuOverrides    = new Repository<BranchMenuOverride>(db);
        ItemAvailability = new Repository<BranchItemAvailability>(db);

        FloorPlans    = new Repository<FloorPlan>(db);
        Tables        = new Repository<RestaurantTable>(db);
        Sessions      = new Repository<TableSession>(db);
        Payments      = new Repository<SessionPayment>(db);
        Reservations  = new Repository<TableReservation>(db);

        Orders         = new Repository<DineInOrder>(db);
        OrderItems     = new Repository<DineInOrderItem>(db);
        OrderModifiers = new Repository<OrderItemModifier>(db);

        Stations    = new Repository<KitchenStation>(db);
        Tickets     = new Repository<KitchenTicket>(db);
        TicketItems = new Repository<KitchenTicketItem>(db);

        Branches = new Repository<Branch>(db);
        Tenants  = new Repository<Tenant>(db);
    }

    public IRepository<RestaurantCategory>    Categories       { get; }
    public IRepository<RestaurantMenuItem>    MenuItems        { get; }
    public IRepository<MenuItemVariant>       Variants         { get; }
    public IRepository<MenuModifierGroup>     ModifierGroups   { get; }
    public IRepository<MenuModifier>          Modifiers        { get; }
    public IRepository<BranchMenuOverride>    MenuOverrides    { get; }
    public IRepository<BranchItemAvailability> ItemAvailability{ get; }

    public IRepository<FloorPlan>             FloorPlans    { get; }
    public IRepository<RestaurantTable>       Tables        { get; }
    public IRepository<TableSession>          Sessions      { get; }
    public IRepository<SessionPayment>        Payments      { get; }
    public IRepository<TableReservation>      Reservations  { get; }

    public IRepository<DineInOrder>           Orders        { get; }
    public IRepository<DineInOrderItem>       OrderItems    { get; }
    public IRepository<OrderItemModifier>     OrderModifiers{ get; }

    public IRepository<KitchenStation>        Stations    { get; }
    public IRepository<KitchenTicket>         Tickets     { get; }
    public IRepository<KitchenTicketItem>     TicketItems { get; }

    public IRepository<Branch>                Branches    { get; }
    public IRepository<Tenant>                Tenants     { get; }

    public Task<int> SaveChangesAsync(CancellationToken ct = default)
        => _db.SaveChangesAsync(ct);

    public async Task BeginTransactionAsync(CancellationToken ct = default)
        => _tx = await _db.Database.BeginTransactionAsync(ct);

    public async Task CommitTransactionAsync(CancellationToken ct = default)
        => await (_tx?.CommitAsync(ct) ?? Task.CompletedTask);

    public async Task RollbackTransactionAsync(CancellationToken ct = default)
        => await (_tx?.RollbackAsync(ct) ?? Task.CompletedTask);

    public void Dispose() => _tx?.Dispose();
}
