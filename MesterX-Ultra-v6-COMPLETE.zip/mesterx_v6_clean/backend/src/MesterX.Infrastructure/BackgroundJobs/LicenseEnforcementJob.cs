using System;
using Microsoft.Extensions.DependencyInjection;
using System.Threading;
using System.Threading.Tasks;
using MesterX.Domain.Interfaces;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace MesterX.Infrastructure.BackgroundJobs;

public class LicenseEnforcementJob : BackgroundService
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<LicenseEnforcementJob> _logger;

    public LicenseEnforcementJob(IServiceProvider serviceProvider, ILogger<LicenseEnforcementJob> logger)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("LicenseEnforcementJob started");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using (var scope = _serviceProvider.CreateScope())
                {
                    var uow = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();

                    // Check for expired licenses and downgrade them
                    var now = DateTime.UtcNow;
                    var licenses = await uow.Licenses.FindAsync(l => l.ExpiresAt < now && !l.IsDeleted);

                    foreach (var license in licenses)
                    {
                        license.Status = Domain.Enums.LicenseStatus.Expired;
                        license.UpdatedAt = now;
                        uow.Licenses.Update(license);
                    }

                    await uow.SaveChangesAsync();
                }

                // Run every hour
                await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in LicenseEnforcementJob");
                await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
            }
        }

        _logger.LogInformation("LicenseEnforcementJob stopped");
    }
}
