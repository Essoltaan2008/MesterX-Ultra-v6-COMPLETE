using MesterX.Application.Common.Interfaces;
using MesterX.Infrastructure.Services;
using Microsoft.Extensions.DependencyInjection;

namespace MesterX.Infrastructure.Extensions;

/// <summary>
/// يُضاف في Program.cs: builder.Services.AddBusinessServices();
/// يسجّل كل الـ Business Services الأساسية
/// </summary>
public static class ServiceExtensions
{
    public static IServiceCollection AddBusinessServices(this IServiceCollection services)
    {
        services.AddScoped<IProductService,      ProductService>();
        services.AddScoped<IOrderService,        OrderService>();
        services.AddScoped<ICustomerService,     CustomerService>();
        services.AddScoped<ISubscriptionService, SubscriptionService>();
        services.AddScoped<IPlatformService,     PlatformService>();
        services.AddScoped<IDeliveryService,     DeliveryService>();

        return services;
    }
}
