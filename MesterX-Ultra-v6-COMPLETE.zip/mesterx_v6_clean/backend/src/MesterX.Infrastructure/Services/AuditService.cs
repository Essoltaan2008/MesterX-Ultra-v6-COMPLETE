using MesterX.Domain.Entities.Audit;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;
using MesterX.Infrastructure.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace MesterX.Infrastructure.Services;

// ════════════════════════════════════════════════════════════════════════════
// AuditService — يكتب فعلياً في جدول audit_logs
// ════════════════════════════════════════════════════════════════════════════
public class AuditService : IAuditService
{
    private readonly MesterXDbContext _db;
    private readonly IHttpContextAccessor _http;
    private readonly ILogger<AuditService> _log;

    public AuditService(
        MesterXDbContext db,
        IHttpContextAccessor http,
        ILogger<AuditService> log)
    {
        _db   = db;
        _http = http;
        _log  = log;
    }

    public async Task LogAsync(
        Guid tenantId,
        Guid? userId,
        AuditAction action,
        string entityType,
        Guid? entityId       = null,
        string? oldValues    = null,
        string? newValues    = null,
        bool isSuccess       = true,
        string? errorMessage = null,
        CancellationToken ct = default)
    {
        try
        {
            var ctx = _http.HttpContext;
            var ipAddress  = ctx?.Connection.RemoteIpAddress?.ToString();
            var userAgent  = ctx?.Request.Headers.UserAgent.ToString();

            var log = new AuditLog
            {
                Id          = Guid.NewGuid(),
                TenantId    = tenantId,
                UserId      = userId,
                Action      = action,
                EntityType  = entityType,
                EntityId    = entityId,
                OldValues   = oldValues,
                NewValues   = newValues,
                IsSuccess   = isSuccess,
                ErrorMessage= errorMessage,
                IpAddress   = ipAddress,
                UserAgent   = userAgent,
                CreatedAt   = DateTime.UtcNow,
                UpdatedAt   = DateTime.UtcNow,
                Version     = 1
            };

            _db.AuditLogs.Add(log);
            await _db.SaveChangesAsync(ct);
        }
        catch (Exception ex)
        {
            // Audit نفسه ما يسببش crash — نلوغه بس
            _log.LogError(ex, "Failed to write audit log for {Action} on {Entity}", action, entityType);
        }
    }
}
