using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MesterX.Application.Common.Interfaces;
using MesterX.Domain.Entities;
using MesterX.Domain.Enums;

namespace MesterX.Infrastructure.Services.Products;

/// <summary>
/// CRUD المنتجات + إدارة المخزون لكل فرع.
/// Business rules مستخرجة من v1 ومعاد تنفيذها لـ v6 Clean Architecture.
/// </summary>
public class ProductService : IProductService
{
    private readonly MesterXDbContext _db;
    private readonly ILogger<ProductService> _logger;

    public ProductService(MesterXDbContext db, ILogger<ProductService> logger)
    {
        _db = db;
        _logger = logger;
    }

    // ── Create ────────────────────────────────────────────────────────────────
    public async Task<ProductDto> CreateProductAsync(
        Guid tenantId, CreateProductRequest req, CancellationToken ct = default)
    {
        // SKU uniqueness per tenant
        if (req.SKU is not null &&
            await _db.Products.AnyAsync(
                p => p.TenantId == tenantId && p.SKU == req.SKU && !p.IsDeleted, ct))
            throw new InvalidOperationException($"الـ SKU '{req.SKU}' مستخدم بالفعل لمنتج آخر.");

        // Barcode uniqueness per tenant
        if (req.Barcode is not null &&
            await _db.Products.AnyAsync(
                p => p.TenantId == tenantId && p.Barcode == req.Barcode && !p.IsDeleted, ct))
            throw new InvalidOperationException($"الباركود '{req.Barcode}' مستخدم بالفعل لمنتج آخر.");

        // Validate branch belongs to tenant (if specified)
        if (req.BranchId.HasValue)
        {
            var branchExists = await _db.Branches.AnyAsync(
                b => b.Id == req.BranchId && b.TenantId == tenantId && !b.IsDeleted, ct);
            if (!branchExists)
                throw new KeyNotFoundException("الفرع المحدد غير موجود أو لا ينتمي لهذه الشركة.");
        }

        var product = new Product
        {
            TenantId          = tenantId,
            BranchId          = req.BranchId,
            CategoryId        = req.CategoryId,
            Name              = req.Name.Trim(),
            Description       = req.Description?.Trim(),
            Price             = req.Price,
            Cost              = req.Cost,
            ComparePrice      = req.ComparePrice,
            SKU               = req.SKU?.Trim().ToUpper(),
            Barcode           = req.Barcode?.Trim(),
            Type              = req.Type,
            TrackInventory    = req.TrackInventory,
            IsActive          = req.IsActive,
            IsAvailableOnline = req.IsAvailableOnline,
            RentalDailyRate   = req.RentalDailyRate,
            RentalDeposit     = req.RentalDeposit
        };

        _db.Products.Add(product);
        await _db.SaveChangesAsync(ct);

        // ── خلق inventory record لكل فرع نشط ──────────────────────────────
        if (req.TrackInventory)
        {
            var branches = await _db.Branches
                .Where(b => b.TenantId == tenantId && b.IsActive && !b.IsDeleted &&
                            (req.BranchId == null || b.Id == req.BranchId))
                .ToListAsync(ct);

            foreach (var branch in branches)
            {
                _db.Inventories.Add(new Inventory
                {
                    TenantId    = tenantId,
                    ProductId   = product.Id,
                    BranchId    = branch.Id,
                    Quantity    = req.InitialStock,
                    MinQuantity = 5,
                    MaxQuantity = 1000
                });
            }
            await _db.SaveChangesAsync(ct);
        }

        _logger.LogInformation(
            "Product '{Name}' (ID: {Id}) created for tenant {TenantId}",
            product.Name, product.Id, tenantId);

        return await GetProductAsync(tenantId, product.Id, ct);
    }

    // ── Get Single ────────────────────────────────────────────────────────────
    public async Task<ProductDto> GetProductAsync(
        Guid tenantId, Guid productId, CancellationToken ct = default)
    {
        var product = await _db.Products
            .Include(p => p.Category)
            .Include(p => p.Inventories)
            .FirstOrDefaultAsync(
                p => p.Id == productId && p.TenantId == tenantId && !p.IsDeleted, ct)
            ?? throw new KeyNotFoundException("المنتج غير موجود.");

        return MapToDto(product);
    }

    // ── Get Paged ─────────────────────────────────────────────────────────────
    public async Task<PagedResult<ProductDto>> GetProductsAsync(
        Guid tenantId, Guid? branchId, Guid? categoryId,
        string? search, int page, int pageSize, CancellationToken ct = default)
    {
        var query = _db.Products
            .Include(p => p.Category)
            .Include(p => p.Inventories)
            .Where(p => p.TenantId == tenantId && !p.IsDeleted)
            .AsQueryable();

        if (branchId.HasValue)
            query = query.Where(p => p.BranchId == null || p.BranchId == branchId);

        if (categoryId.HasValue)
            query = query.Where(p => p.CategoryId == categoryId);

        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim().ToLower();
            query = query.Where(p =>
                p.Name.ToLower().Contains(s) ||
                (p.SKU     != null && p.SKU.ToLower().Contains(s)) ||
                (p.Barcode != null && p.Barcode.Contains(s)));
        }

        var total = await query.CountAsync(ct);
        var items = await query
            .OrderBy(p => p.Name)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);

        return new PagedResult<ProductDto>(
            items.Select(MapToDto).ToList(),
            total, page, pageSize,
            (int)Math.Ceiling(total / (double)pageSize));
    }

    // ── Update ────────────────────────────────────────────────────────────────
    public async Task<ProductDto> UpdateProductAsync(
        Guid tenantId, Guid productId, UpdateProductRequest req, CancellationToken ct = default)
    {
        var product = await _db.Products
            .FirstOrDefaultAsync(
                p => p.Id == productId && p.TenantId == tenantId && !p.IsDeleted, ct)
            ?? throw new KeyNotFoundException("المنتج غير موجود.");

        if (req.Name        is not null) product.Name              = req.Name.Trim();
        if (req.Description is not null) product.Description       = req.Description.Trim();
        if (req.Price       is not null) product.Price             = req.Price.Value;
        if (req.Cost        is not null) product.Cost              = req.Cost;
        if (req.ComparePrice is not null) product.ComparePrice     = req.ComparePrice;
        if (req.CategoryId  is not null) product.CategoryId        = req.CategoryId;
        if (req.IsActive    is not null) product.IsActive          = req.IsActive.Value;
        if (req.IsAvailableOnline is not null) product.IsAvailableOnline = req.IsAvailableOnline.Value;
        if (req.ImageUrl    is not null) product.ImageUrl          = req.ImageUrl;

        await _db.SaveChangesAsync(ct);
        return await GetProductAsync(tenantId, productId, ct);
    }

    // ── Soft Delete ───────────────────────────────────────────────────────────
    public async Task DeleteProductAsync(
        Guid tenantId, Guid productId, CancellationToken ct = default)
    {
        var product = await _db.Products
            .FirstOrDefaultAsync(
                p => p.Id == productId && p.TenantId == tenantId && !p.IsDeleted, ct)
            ?? throw new KeyNotFoundException("المنتج غير موجود.");

        // تحقق مافيش أوردرات نشطة على المنتج ده
        var hasActiveOrders = await _db.OrderItems
            .Include(oi => oi.Order)
            .AnyAsync(oi =>
                oi.ProductId == productId &&
                oi.Order.Status != OrderStatus.Delivered &&
                oi.Order.Status != OrderStatus.Cancelled &&
                oi.Order.Status != OrderStatus.Refunded, ct);

        if (hasActiveOrders)
            throw new InvalidOperationException("لا يمكن حذف منتج مرتبط بأوردرات نشطة.");

        product.IsDeleted = true;
        product.IsActive  = false;
        product.DeletedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync(ct);

        _logger.LogWarning(
            "Product '{Name}' (ID: {Id}) soft-deleted for tenant {TenantId}",
            product.Name, product.Id, tenantId);
    }

    // ── Update Inventory ──────────────────────────────────────────────────────
    public async Task UpdateInventoryAsync(
        Guid tenantId, Guid productId, UpdateInventoryRequest req, CancellationToken ct = default)
    {
        var inv = await _db.Inventories
            .FirstOrDefaultAsync(
                i => i.ProductId == productId && i.BranchId == req.BranchId, ct);

        if (inv is null)
        {
            _db.Inventories.Add(new Inventory
            {
                TenantId    = tenantId,
                ProductId   = productId,
                BranchId    = req.BranchId,
                Quantity    = req.Quantity,
                MinQuantity = req.MinQuantity,
                MaxQuantity = req.MaxQuantity
            });
        }
        else
        {
            inv.Quantity    = req.Quantity;
            inv.MinQuantity = req.MinQuantity;
            inv.MaxQuantity = req.MaxQuantity;
        }

        await _db.SaveChangesAsync(ct);
    }

    // ── Low Stock Alert ───────────────────────────────────────────────────────
    public async Task<List<ProductDto>> GetLowStockAsync(
        Guid tenantId, Guid? branchId, CancellationToken ct = default)
    {
        var query = _db.Inventories
            .Include(i => i.Product).ThenInclude(p => p.Category)
            .Include(i => i.Product).ThenInclude(p => p.Inventories)
            .Where(i =>
                i.TenantId == tenantId &&
                !i.IsDeleted &&
                i.Product.TrackInventory &&
                i.Product.IsActive &&
                !i.Product.IsDeleted &&
                (i.Quantity - i.ReservedQuantity) <= i.MinQuantity);

        if (branchId.HasValue)
            query = query.Where(i => i.BranchId == branchId.Value);

        var inventories = await query.ToListAsync(ct);
        return inventories
            .Select(i => MapToDto(i.Product))
            .DistinctBy(p => p.Id)
            .ToList();
    }

    // ── Find by Barcode (POS scanner) ─────────────────────────────────────────
    public async Task<ProductDto?> GetByBarcodeAsync(
        Guid tenantId, string barcode, CancellationToken ct = default)
    {
        var product = await _db.Products
            .Include(p => p.Category)
            .Include(p => p.Inventories)
            .FirstOrDefaultAsync(
                p => p.TenantId == tenantId &&
                     p.Barcode == barcode &&
                     p.IsActive &&
                     !p.IsDeleted, ct);

        return product is null ? null : MapToDto(product);
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private static ProductDto MapToDto(Product p) => new(
        Id:               p.Id,
        Name:             p.Name,
        Description:      p.Description,
        ImageUrl:         p.ImageUrl,
        Price:            p.Price,
        Cost:             p.Cost,
        ComparePrice:     p.ComparePrice,
        SKU:              p.SKU,
        Barcode:          p.Barcode,
        Type:             p.Type,
        TrackInventory:   p.TrackInventory,
        IsActive:         p.IsActive,
        IsAvailableOnline: p.IsAvailableOnline,
        CategoryId:       p.CategoryId,
        CategoryName:     p.Category?.Name,
        TotalStock:       p.Inventories.Sum(i => i.Quantity - i.ReservedQuantity),
        RentalDailyRate:  p.RentalDailyRate,
        CreatedAt:        p.CreatedAt
    );
}
