using MesterX.Domain.Interfaces;

namespace MesterX.Infrastructure.Services;

// ════════════════════════════════════════════════════════════════════════════
// DateTimeService — abstraction للوقت (قابل للـ mocking في tests)
// ════════════════════════════════════════════════════════════════════════════
public class DateTimeService : IDateTimeService
{
    public DateTime UtcNow    => DateTime.UtcNow;
    public DateTime LocalNow  => DateTime.Now;

    // وقت القاهرة (UTC+2 أو UTC+3 في الصيف)
    public DateTime CairoNow
    {
        get
        {
            try
            {
                var cairoZone = TimeZoneInfo.FindSystemTimeZoneById("Africa/Cairo");
                return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, cairoZone);
            }
            catch
            {
                return DateTime.UtcNow.AddHours(2); // fallback
            }
        }
    }

    public DateOnly Today        => DateOnly.FromDateTime(DateTime.UtcNow);
    public DateOnly CairoToday   => DateOnly.FromDateTime(CairoNow);
}
