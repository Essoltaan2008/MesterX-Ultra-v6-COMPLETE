using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading.Tasks;
using MesterX.Application.Services;
using MesterX.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace MesterX.Infrastructure.Services;

public class FeatureFlagService : IFeatureFlagService
{
    private readonly IServiceProvider _serviceProvider;
    private static readonly ConcurrentDictionary<string, (bool Enabled, DateTime Expiry)> _cache = new();
    private static readonly TimeSpan CacheDuration = TimeSpan.FromMinutes(5);

    public FeatureFlagService(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public async Task<bool> IsEnabledAsync(string featureKey)
    {
        if (_cache.TryGetValue(featureKey, out var cached) && cached.Expiry > DateTime.UtcNow)
        {
            return cached.Enabled;
        }

        using var scope = _serviceProvider.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<MesterXDbContext>();

        var flag = await db.FeatureFlags
            .IgnoreQueryFilters() // Feature flags are global
            .FirstOrDefaultAsync(f => f.Key == featureKey);

        bool isEnabled = flag?.IsEnabled ?? false;

        _cache[featureKey] = (isEnabled, DateTime.UtcNow.Add(CacheDuration));

        return isEnabled;
    }

    public async Task EnsureEnabledAsync(string featureKey)
    {
        if (!await IsEnabledAsync(featureKey))
        {
            throw new UnauthorizedAccessException($"Feature '{featureKey}' is not enabled in this phase.");
        }
    }
}
