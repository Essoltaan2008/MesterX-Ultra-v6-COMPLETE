using System.Security.Claims;
using MesterX.Domain.Interfaces;
using Microsoft.AspNetCore.Http;

namespace MesterX.Infrastructure.Services;

// ════════════════════════════════════════════════════════════════════════════
// CurrentUserService — يجيب بيانات المستخدم الحالي من JWT Claims
// ════════════════════════════════════════════════════════════════════════════
public class CurrentUserService : ICurrentUserService
{
    private readonly IHttpContextAccessor _http;

    public CurrentUserService(IHttpContextAccessor http) => _http = http;

    private ClaimsPrincipal? User => _http.HttpContext?.User;

    public Guid? UserId
    {
        get
        {
            var val = User?.FindFirstValue(ClaimTypes.NameIdentifier)
                   ?? User?.FindFirstValue("sub");
            return Guid.TryParse(val, out var id) ? id : null;
        }
    }

    public Guid? TenantId
    {
        get
        {
            var val = User?.FindFirstValue("tenant_id")
                   ?? User?.FindFirstValue("tenantId");
            return Guid.TryParse(val, out var id) ? id : null;
        }
    }

    public string? Email => User?.FindFirstValue(ClaimTypes.Email)
                         ?? User?.FindFirstValue("email");

    public string? Role => User?.FindFirstValue(ClaimTypes.Role)
                        ?? User?.FindFirstValue("role");

    public bool IsAuthenticated => User?.Identity?.IsAuthenticated == true;

    public bool IsInRole(string role) => User?.IsInRole(role) == true;
}
