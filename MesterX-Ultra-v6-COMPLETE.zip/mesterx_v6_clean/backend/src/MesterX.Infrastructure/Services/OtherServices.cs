using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MesterX.Application.Common.Interfaces;
using MesterX.Domain.Entities;
using MesterX.Domain.Enums;

namespace MesterX.Infrastructure.Services.Customers;

// ══════════════════════════════════════════════════════════════════════════════
// CUSTOMER SERVICE
// ══════════════════════════════════════════════════════════════════════════════

public class CustomerService : ICustomerService
{
    private readonly MesterXDbContext _db;

    public CustomerService(MesterXDbContext db) => _db = db;

    public async Task<CustomerDto> CreateCustomerAsync(
        Guid tenantId, CreateCustomerRequest req, CancellationToken ct = default)
    {
        // تحقق من رقم الهاتف unique per tenant
        if (req.PhoneNumber is not null &&
            await _db.Customers.AnyAsync(
                c => c.TenantId == tenantId && c.PhoneNumber == req.PhoneNumber && !c.IsDeleted, ct))
            throw new InvalidOperationException("رقم الهاتف هذا مسجّل بالفعل لعميل آخر.");

        var customer = new Customer
        {
            TenantId    = tenantId,
            Name        = req.Name.Trim(),
            Email       = req.Email?.ToLower().Trim(),
            PhoneNumber = req.PhoneNumber?.Trim(),
            Address     = req.Address?.Trim(),
            City        = req.City?.Trim(),
            BirthDate   = req.BirthDate,
            Notes       = req.Notes
        };

        _db.Customers.Add(customer);
        await _db.SaveChangesAsync(ct);
        return MapToDto(customer);
    }

    public async Task<CustomerDto?> GetCustomerAsync(
        Guid tenantId, Guid customerId, CancellationToken ct = default)
    {
        var c = await _db.Customers
            .FirstOrDefaultAsync(
                x => x.Id == customerId && x.TenantId == tenantId && !x.IsDeleted, ct);
        return c is null ? null : MapToDto(c);
    }

    public async Task<CustomerDto?> FindByPhoneAsync(
        Guid tenantId, string phone, CancellationToken ct = default)
    {
        var c = await _db.Customers
            .FirstOrDefaultAsync(
                x => x.TenantId == tenantId && x.PhoneNumber == phone && !x.IsDeleted, ct);
        return c is null ? null : MapToDto(c);
    }

    public async Task<PagedResult<CustomerDto>> GetCustomersAsync(
        Guid tenantId, string? search, int page, int pageSize, CancellationToken ct = default)
    {
        var query = _db.Customers
            .Where(c => c.TenantId == tenantId && !c.IsDeleted)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim().ToLower();
            query = query.Where(c =>
                c.Name.ToLower().Contains(s) ||
                (c.PhoneNumber != null && c.PhoneNumber.Contains(s)) ||
                (c.Email       != null && c.Email.ToLower().Contains(s)));
        }

        var total = await query.CountAsync(ct);
        var items = await query
            .OrderByDescending(c => c.TotalSpent)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);

        return new PagedResult<CustomerDto>(
            items.Select(MapToDto).ToList(),
            total, page, pageSize,
            (int)Math.Ceiling(total / (double)pageSize));
    }

    public async Task<CustomerDto> UpdateCustomerAsync(
        Guid tenantId, Guid customerId, CreateCustomerRequest req, CancellationToken ct = default)
    {
        var customer = await _db.Customers
            .FirstOrDefaultAsync(c => c.Id == customerId && c.TenantId == tenantId && !c.IsDeleted, ct)
            ?? throw new KeyNotFoundException("العميل غير موجود.");

        customer.Name        = req.Name.Trim();
        customer.Email       = req.Email?.ToLower().Trim();
        customer.PhoneNumber = req.PhoneNumber?.Trim();
        customer.Address     = req.Address?.Trim();
        customer.City        = req.City?.Trim();
        customer.BirthDate   = req.BirthDate;
        customer.Notes       = req.Notes;

        await _db.SaveChangesAsync(ct);
        return MapToDto(customer);
    }

    public async Task AddLoyaltyPointsAsync(
        Guid tenantId, Guid customerId, int points, CancellationToken ct = default)
    {
        var customer = await _db.Customers
            .FirstOrDefaultAsync(c => c.Id == customerId && c.TenantId == tenantId, ct)
            ?? throw new KeyNotFoundException("العميل غير موجود.");

        customer.LoyaltyPoints += points;
        await _db.SaveChangesAsync(ct);
    }

    public async Task UpdateSpendingStatsAsync(
        Guid tenantId, Guid customerId, decimal amount, CancellationToken ct = default)
    {
        var customer = await _db.Customers
            .FirstOrDefaultAsync(c => c.Id == customerId && c.TenantId == tenantId, ct);
        if (customer is null) return;

        customer.TotalSpent  += amount;
        customer.TotalOrders += 1;
        customer.LoyaltyPoints += (int)(amount / 10);
        await _db.SaveChangesAsync(ct);
    }

    private static CustomerDto MapToDto(Customer c) => new(
        c.Id, c.Name, c.Email, c.PhoneNumber, c.Address,
        c.City, c.LoyaltyPoints, c.TotalSpent, c.TotalOrders,
        c.BirthDate, c.CreatedAt
    );
}

// ══════════════════════════════════════════════════════════════════════════════
// SUBSCRIPTION SERVICE
// ══════════════════════════════════════════════════════════════════════════════

namespace MesterX.Infrastructure.Services.Billing;

public class SubscriptionService : ISubscriptionService
{
    private readonly MesterXDbContext _db;
    private readonly ILogger<SubscriptionService> _logger;

    public SubscriptionService(MesterXDbContext db, ILogger<SubscriptionService> logger)
    {
        _db = db;
        _logger = logger;
    }

    public async Task<SubscriptionDto> GetActiveAsync(Guid tenantId, CancellationToken ct = default)
    {
        var sub = await _db.Subscriptions
            .Include(s => s.Plan)
            .FirstOrDefaultAsync(s =>
                s.TenantId == tenantId &&
                s.Status == SubscriptionStatus.Active &&
                !s.IsDeleted, ct)
            ?? throw new KeyNotFoundException("لا يوجد اشتراك نشط لهذه الشركة.");

        return MapSubToDto(sub);
    }

    public async Task<SubscriptionDto> UpgradeAsync(
        Guid tenantId, Guid planId, BillingCycle cycle, CancellationToken ct = default)
    {
        var plan = await _db.Plans.FindAsync([planId], ct)
            ?? throw new KeyNotFoundException("الباقة غير موجودة.");

        // إيقاف الاشتراك الحالي
        var current = await _db.Subscriptions
            .FirstOrDefaultAsync(s =>
                s.TenantId == tenantId &&
                (s.Status == SubscriptionStatus.Active || s.Status == SubscriptionStatus.Trialing) &&
                !s.IsDeleted, ct);

        if (current is not null)
        {
            current.Status      = SubscriptionStatus.Cancelled;
            current.CancelledAt = DateTime.UtcNow;
            current.CancelReason = "ترقية للباقة الجديدة";
        }

        var amount = cycle == BillingCycle.Annual ? plan.AnnualPrice : plan.MonthlyPrice;

        var newSub = new Subscription
        {
            TenantId     = tenantId,
            PlanId       = planId,
            Status       = SubscriptionStatus.Active,
            BillingCycle = cycle,
            Amount       = amount,
            StartDate    = DateTime.UtcNow,
            EndDate      = cycle == BillingCycle.Annual
                ? DateTime.UtcNow.AddYears(1)
                : DateTime.UtcNow.AddMonths(1),
            AutoRenew    = true
        };

        _db.Subscriptions.Add(newSub);

        // تحديث plan type في الـ tenant
        var tenant = await _db.Tenants.FindAsync([tenantId], ct);
        if (tenant is not null)
            tenant.Plan = plan.Type;

        await _db.SaveChangesAsync(ct);

        _logger.LogInformation(
            "Tenant {TenantId} upgraded to {Plan} ({Cycle})",
            tenantId, plan.Name, cycle);

        return await GetActiveAsync(tenantId, ct);
    }

    public async Task CancelAsync(Guid tenantId, string reason, CancellationToken ct = default)
    {
        var sub = await _db.Subscriptions
            .FirstOrDefaultAsync(s =>
                s.TenantId == tenantId &&
                s.Status == SubscriptionStatus.Active &&
                !s.IsDeleted, ct)
            ?? throw new InvalidOperationException("لا يوجد اشتراك نشط لإلغائه.");

        sub.Status      = SubscriptionStatus.Cancelled;
        sub.CancelledAt = DateTime.UtcNow;
        sub.CancelReason = reason;
        sub.AutoRenew    = false;

        await _db.SaveChangesAsync(ct);
    }

    public async Task<List<PlanDto>> GetPlansAsync(CancellationToken ct = default)
    {
        var plans = await _db.Plans
            .Where(p => p.IsActive && !p.IsDeleted)
            .OrderBy(p => p.MonthlyPrice)
            .ToListAsync(ct);

        return plans.Select(MapPlanToDto).ToList();
    }

    public async Task<bool> CheckFeatureAsync(
        Guid tenantId, string feature, CancellationToken ct = default)
    {
        var sub = await _db.Subscriptions
            .Include(s => s.Plan)
            .FirstOrDefaultAsync(s =>
                s.TenantId == tenantId &&
                (s.Status == SubscriptionStatus.Active || s.Status == SubscriptionStatus.Trialing) &&
                !s.IsDeleted, ct);

        if (sub is null) return false;

        return feature.ToLower() switch
        {
            "delivery"       => sub.Plan.HasDelivery,
            "marketplace"    => sub.Plan.HasMarketplace,
            "ai"             => sub.Plan.HasAi,
            "plugins"        => sub.Plan.HasPluginStore,
            "whatsapp"       => sub.Plan.HasWhatsApp,
            "whitelabel"     => sub.Plan.HasWhiteLabel,
            "restaurant"     => sub.Plan.HasRestaurantModule,
            "rental"         => sub.Plan.HasRentalModule,
            _ => false
        };
    }

    private static SubscriptionDto MapSubToDto(Subscription s) => new(
        s.Id, s.TenantId, MapPlanToDto(s.Plan),
        s.Status, s.BillingCycle, s.Amount,
        s.StartDate, s.EndDate, s.AutoRenew
    );

    private static PlanDto MapPlanToDto(Plan p) => new(
        p.Id, p.Name, p.NameEn ?? p.Name, p.Type,
        p.MonthlyPrice, p.AnnualPrice,
        p.MaxBranches, p.MaxUsers, p.MaxProducts,
        p.HasMarketplace, p.HasDelivery, p.HasAi,
        p.HasRestaurantModule, p.HasRentalModule, p.HasWhiteLabel
    );
}

// ══════════════════════════════════════════════════════════════════════════════
// PLATFORM SERVICE  (PlatformOwner فقط)
// ══════════════════════════════════════════════════════════════════════════════

namespace MesterX.Infrastructure.Services.Platform;

public class PlatformService : IPlatformService
{
    private readonly MesterXDbContext _db;

    public PlatformService(MesterXDbContext db) => _db = db;

    public async Task<PlatformStatsDto> GetStatsAsync(CancellationToken ct = default)
    {
        var tenants = await _db.Tenants.Where(t => !t.IsDeleted).ToListAsync(ct);

        var payments = await _db.Payments
            .Where(p => p.Status == PaymentStatus.Completed && !p.IsDeleted)
            .ToListAsync(ct);

        var subscriptions = await _db.Subscriptions
            .Include(s => s.Plan)
            .Where(s => s.Status == SubscriptionStatus.Active && !s.IsDeleted)
            .ToListAsync(ct);

        var mrr = subscriptions.Sum(s =>
            s.BillingCycle == BillingCycle.Annual ? s.Amount / 12 : s.Amount);

        var revenueByMonth = payments
            .GroupBy(p => p.CreatedAt.ToString("yyyy-MM"))
            .ToDictionary(g => g.Key, g => g.Sum(p => p.Amount));

        var topTenants = await _db.Tenants
            .Where(t => !t.IsDeleted)
            .Select(t => new
            {
                Tenant     = t,
                Revenue    = _db.Payments
                    .Where(p => p.TenantId == t.Id && p.Status == PaymentStatus.Completed)
                    .Sum(p => (decimal?)p.Amount) ?? 0,
                OrderCount = _db.Orders.Count(o => o.TenantId == t.Id && !o.IsDeleted)
            })
            .OrderByDescending(x => x.Revenue)
            .Take(10)
            .ToListAsync(ct);

        return new PlatformStatsDto(
            TotalTenants:   tenants.Count,
            ActiveTenants:  tenants.Count(t => t.IsActive),
            TrialTenants:   tenants.Count(t => t.TrialEndsAt.HasValue && t.TrialEndsAt > DateTime.UtcNow),
            TotalUsers:     await _db.Users.CountAsync(u => !u.IsDeleted, ct),
            TotalOrders:    await _db.Orders.CountAsync(o => !o.IsDeleted, ct),
            TotalRevenue:   payments.Sum(p => p.Amount),
            MonthlyRevenue: payments
                .Where(p => p.CreatedAt >= DateTime.UtcNow.AddMonths(-1))
                .Sum(p => p.Amount),
            MRR:            mrr,
            TotalProducts:  await _db.Products.CountAsync(p => !p.IsDeleted, ct),
            TenantsByPlan:  tenants
                .GroupBy(t => t.Plan.ToString())
                .ToDictionary(g => g.Key, g => g.Count()),
            RevenueByMonth: revenueByMonth,
            TopTenants: topTenants.Select(x => new TopTenantDto(
                x.Tenant.Id, x.Tenant.Name, x.Tenant.Slug,
                x.Tenant.Plan, x.OrderCount, x.Revenue, x.Tenant.CreatedAt
            )).ToList()
        );
    }

    public async Task<PagedResult<TenantDetailsDto>> GetTenantsAsync(
        string? search, PlanType? plan, bool? isActive,
        int page, int pageSize, CancellationToken ct = default)
    {
        var query = _db.Tenants.Where(t => !t.IsDeleted).AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim().ToLower();
            query = query.Where(t =>
                t.Name.ToLower().Contains(s) ||
                t.Slug.Contains(s) ||
                (t.Email != null && t.Email.ToLower().Contains(s)));
        }

        if (plan.HasValue)     query = query.Where(t => t.Plan == plan.Value);
        if (isActive.HasValue) query = query.Where(t => t.IsActive == isActive.Value);

        var total   = await query.CountAsync(ct);
        var tenants = await query
            .OrderByDescending(t => t.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);

        var dtos = new List<TenantDetailsDto>();
        foreach (var t in tenants)
            dtos.Add(await BuildTenantDetailsAsync(t, ct));

        return new PagedResult<TenantDetailsDto>(
            dtos, total, page, pageSize,
            (int)Math.Ceiling(total / (double)pageSize));
    }

    public async Task<TenantDetailsDto> GetTenantAsync(Guid tenantId, CancellationToken ct = default)
    {
        var tenant = await _db.Tenants
            .FirstOrDefaultAsync(t => t.Id == tenantId && !t.IsDeleted, ct)
            ?? throw new KeyNotFoundException("الشركة غير موجودة.");

        return await BuildTenantDetailsAsync(tenant, ct);
    }

    public async Task SuspendTenantAsync(Guid tenantId, string reason, CancellationToken ct = default)
    {
        var tenant = await _db.Tenants.FindAsync([tenantId], ct)
            ?? throw new KeyNotFoundException("الشركة غير موجودة.");

        tenant.IsActive = false;
        await _db.SaveChangesAsync(ct);
    }

    public async Task ActivateTenantAsync(Guid tenantId, CancellationToken ct = default)
    {
        var tenant = await _db.Tenants.FindAsync([tenantId], ct)
            ?? throw new KeyNotFoundException("الشركة غير موجودة.");

        tenant.IsActive = true;
        await _db.SaveChangesAsync(ct);
    }

    private async Task<TenantDetailsDto> BuildTenantDetailsAsync(
        Tenant t, CancellationToken ct)
    {
        var userCount   = await _db.Users.CountAsync(u => u.TenantId == t.Id && !u.IsDeleted, ct);
        var branchCount = await _db.Branches.CountAsync(b => b.TenantId == t.Id && !b.IsDeleted, ct);
        var orderCount  = await _db.Orders.CountAsync(o => o.TenantId == t.Id && !o.IsDeleted, ct);
        var revenue     = await _db.Payments
            .Where(p => p.TenantId == t.Id && p.Status == PaymentStatus.Completed)
            .SumAsync(p => (decimal?)p.Amount, ct) ?? 0;

        return new TenantDetailsDto(
            t.Id, t.Name, t.Slug, t.Plan,
            t.IsActive, t.IsVerified,
            userCount, branchCount, orderCount, revenue,
            t.Email, t.PhoneNumber, t.CreatedAt, t.TrialEndsAt
        );
    }
}
