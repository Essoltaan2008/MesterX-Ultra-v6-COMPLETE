using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MesterX.Application.Common.Interfaces;
using MesterX.Domain.Entities;
using MesterX.Domain.Enums;

namespace MesterX.Infrastructure.Services.Orders;

/// <summary>
/// Business rules:
/// • ضريبة القيمة المضافة 10% (السوق المصري)
/// • حجز المخزون atomically عند إنشاء الأوردر
/// • توليد OrderNumber تسلسلي per tenant  مثل: ORD-20250615-0042
/// • حساب DeliveryFee بناءً على إحداثيات GPS
/// • تحديث Customer stats (TotalSpent + TotalOrders) عند الإكمال
/// </summary>
public class OrderService : IOrderService
{
    private readonly MesterXDbContext _db;
    private readonly ILogger<OrderService> _logger;

    private const decimal VAT_RATE      = 0.10m;  // ضريبة القيمة المضافة المصرية 10%
    private const decimal BASE_DELIVERY = 15m;    // 15 جنيه أساسي
    private const decimal KM_RATE       = 3m;     // 3 جنيه/كيلومتر

    public OrderService(MesterXDbContext db, ILogger<OrderService> logger)
    {
        _db = db;
        _logger = logger;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // CREATE ORDER
    // ══════════════════════════════════════════════════════════════════════════
    public async Task<OrderDto> CreateOrderAsync(
        Guid tenantId, Guid userId, CreateOrderRequest req, CancellationToken ct = default)
    {
        // ── 1. Validate branch ────────────────────────────────────────────────
        var branch = await _db.Branches
            .FirstOrDefaultAsync(
                b => b.Id == req.BranchId && b.TenantId == tenantId && b.IsActive && !b.IsDeleted, ct)
            ?? throw new KeyNotFoundException("الفرع غير موجود أو غير نشط.");

        // ── 2. Load products with inventory ───────────────────────────────────
        var productIds = req.Items.Select(i => i.ProductId).Distinct().ToList();

        var products = await _db.Products
            .Include(p => p.Inventories.Where(inv => inv.BranchId == req.BranchId))
            .Where(p =>
                productIds.Contains(p.Id) &&
                p.TenantId == tenantId &&
                p.IsActive &&
                !p.IsDeleted)
            .ToListAsync(ct);

        if (products.Count != productIds.Count)
            throw new InvalidOperationException("بعض المنتجات غير موجودة أو غير نشطة.");

        // ── 3. Transaction: create order + reserve inventory ──────────────────
        await using var tx = await _db.Database.BeginTransactionAsync(ct);
        try
        {
            var orderNumber = await GenerateOrderNumberAsync(tenantId, ct);

            var order = new Order
            {
                TenantId        = tenantId,
                BranchId        = req.BranchId,
                CustomerId      = req.CustomerId,
                UserId          = userId,
                OrderNumber     = orderNumber,
                Type            = req.Type,
                TableNumber     = req.TableNumber,
                Notes           = req.Notes,
                PaymentMethod   = req.PaymentMethod,
                Status          = OrderStatus.Pending,
                PaymentStatus   = PaymentStatus.Pending,
                DeliveryAddress = req.DeliveryAddress,
                DeliveryLat     = req.DeliveryLat,
                DeliveryLng     = req.DeliveryLng
            };

            decimal subTotal = 0;

            foreach (var itemReq in req.Items)
            {
                var product = products.First(p => p.Id == itemReq.ProductId);

                // ── Inventory check ───────────────────────────────────────────
                if (product.TrackInventory)
                {
                    var inventory = product.Inventories.FirstOrDefault();
                    var available = (inventory?.Quantity ?? 0) - (inventory?.ReservedQuantity ?? 0);

                    if (available < itemReq.Quantity)
                        throw new InvalidOperationException(
                            $"المنتج '{product.Name}' غير متوفر بالكمية المطلوبة. " +
                            $"المتاح: {available}، المطلوب: {itemReq.Quantity}");
                }

                var itemTotal = product.Price * itemReq.Quantity;
                order.Items.Add(new OrderItem
                {
                    ProductId  = product.Id,
                    Quantity   = itemReq.Quantity,
                    UnitPrice  = product.Price,
                    Discount   = 0,
                    Total      = itemTotal,
                    Notes      = itemReq.Notes
                });
                subTotal += itemTotal;

                // ── Reserve inventory ─────────────────────────────────────────
                if (product.TrackInventory)
                {
                    var inv = product.Inventories.FirstOrDefault();
                    if (inv is not null)
                        inv.ReservedQuantity += itemReq.Quantity;
                }
            }

            // ── Calculate totals ──────────────────────────────────────────────
            order.SubTotal    = subTotal;
            order.TaxAmount   = Math.Round(subTotal * VAT_RATE, 2);
            order.DeliveryFee = req.Type == OrderType.Delivery
                ? CalculateDeliveryFee(req.DeliveryLat, req.DeliveryLng, branch)
                : 0;
            order.Total = order.SubTotal + order.TaxAmount + order.DeliveryFee - order.Discount;

            _db.Orders.Add(order);
            await _db.SaveChangesAsync(ct);
            await tx.CommitAsync(ct);

            _logger.LogInformation(
                "Order {OrderNumber} created for tenant {TenantId}, total: {Total} EGP",
                orderNumber, tenantId, order.Total);

            return await GetOrderAsync(tenantId, order.Id, ct);
        }
        catch
        {
            await tx.RollbackAsync(ct);
            throw;
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GET ORDER
    // ══════════════════════════════════════════════════════════════════════════
    public async Task<OrderDto> GetOrderAsync(
        Guid tenantId, Guid orderId, CancellationToken ct = default)
    {
        var order = await _db.Orders
            .Include(o => o.Branch)
            .Include(o => o.Customer)
            .Include(o => o.User)
            .Include(o => o.Items).ThenInclude(i => i.Product)
            .FirstOrDefaultAsync(
                o => o.Id == orderId && o.TenantId == tenantId && !o.IsDeleted, ct)
            ?? throw new KeyNotFoundException("الأوردر غير موجود.");

        return MapToDto(order);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GET PAGED
    // ══════════════════════════════════════════════════════════════════════════
    public async Task<PagedResult<OrderDto>> GetOrdersAsync(
        Guid tenantId, Guid? branchId, OrderStatus? status,
        DateTime? from, DateTime? to,
        int page, int pageSize, CancellationToken ct = default)
    {
        var query = _db.Orders
            .Include(o => o.Branch)
            .Include(o => o.Customer)
            .Include(o => o.User)
            .Include(o => o.Items).ThenInclude(i => i.Product)
            .Where(o => o.TenantId == tenantId && !o.IsDeleted)
            .AsQueryable();

        if (branchId.HasValue) query = query.Where(o => o.BranchId == branchId.Value);
        if (status.HasValue)   query = query.Where(o => o.Status == status.Value);
        if (from.HasValue)     query = query.Where(o => o.CreatedAt >= from.Value);
        if (to.HasValue)       query = query.Where(o => o.CreatedAt <= to.Value);

        var total = await query.CountAsync(ct);
        var items = await query
            .OrderByDescending(o => o.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);

        return new PagedResult<OrderDto>(
            items.Select(MapToDto).ToList(),
            total, page, pageSize,
            (int)Math.Ceiling(total / (double)pageSize));
    }

    // ══════════════════════════════════════════════════════════════════════════
    // UPDATE STATUS
    // ══════════════════════════════════════════════════════════════════════════
    public async Task<OrderDto> UpdateStatusAsync(
        Guid tenantId, Guid orderId, OrderStatus newStatus,
        string? reason, CancellationToken ct = default)
    {
        var order = await _db.Orders
            .Include(o => o.Items)
            .FirstOrDefaultAsync(
                o => o.Id == orderId && o.TenantId == tenantId && !o.IsDeleted, ct)
            ?? throw new KeyNotFoundException("الأوردر غير موجود.");

        await using var tx = await _db.Database.BeginTransactionAsync(ct);
        try
        {
            var prevStatus = order.Status;
            order.Status = newStatus;

            switch (newStatus)
            {
                case OrderStatus.Confirmed:
                    order.ConfirmedAt = DateTime.UtcNow;
                    break;

                case OrderStatus.Ready:
                    order.ReadyAt = DateTime.UtcNow;
                    break;

                case OrderStatus.Delivered:
                    order.CompletedAt  = DateTime.UtcNow;
                    order.PaymentStatus = PaymentStatus.Completed;
                    // تحرير المخزون المحجوز وتخفيض الكمية الفعلية
                    await ReleaseInventoryAsync(order, deduct: true, ct);
                    // تحديث إحصائيات العميل
                    if (order.CustomerId.HasValue)
                        await UpdateCustomerStatsAsync(tenantId, order.CustomerId.Value, order.Total, ct);
                    break;

                case OrderStatus.Cancelled:
                    order.CancelledAt  = DateTime.UtcNow;
                    order.CancelReason = reason;
                    order.PaymentStatus = PaymentStatus.Pending;
                    // تحرير المخزون المحجوز بدون تخفيض
                    await ReleaseInventoryAsync(order, deduct: false, ct);
                    break;

                case OrderStatus.Refunded:
                    order.PaymentStatus = PaymentStatus.Refunded;
                    break;
            }

            await _db.SaveChangesAsync(ct);
            await tx.CommitAsync(ct);

            _logger.LogInformation(
                "Order {OrderNumber} status changed: {Prev} → {New}",
                order.OrderNumber, prevStatus, newStatus);

            return await GetOrderAsync(tenantId, orderId, ct);
        }
        catch
        {
            await tx.RollbackAsync(ct);
            throw;
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // APPLY DISCOUNT
    // ══════════════════════════════════════════════════════════════════════════
    public async Task<OrderDto> ApplyDiscountAsync(
        Guid tenantId, Guid orderId, decimal discount, CancellationToken ct = default)
    {
        var order = await _db.Orders
            .FirstOrDefaultAsync(
                o => o.Id == orderId && o.TenantId == tenantId && !o.IsDeleted, ct)
            ?? throw new KeyNotFoundException("الأوردر غير موجود.");

        if (order.Status != OrderStatus.Pending && order.Status != OrderStatus.Confirmed)
            throw new InvalidOperationException("لا يمكن تطبيق خصم على أوردر في هذه المرحلة.");

        if (discount < 0 || discount > order.SubTotal)
            throw new InvalidOperationException("قيمة الخصم غير صحيحة.");

        order.Discount = discount;
        order.Total = order.SubTotal + order.TaxAmount + order.DeliveryFee - order.Discount;
        await _db.SaveChangesAsync(ct);

        return await GetOrderAsync(tenantId, orderId, ct);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // DAILY SUMMARY
    // ══════════════════════════════════════════════════════════════════════════
    public async Task<OrderSummaryDto> GetDailySummaryAsync(
        Guid tenantId, Guid branchId, DateTime date, CancellationToken ct = default)
    {
        var start = date.Date;
        var end   = start.AddDays(1);

        var orders = await _db.Orders
            .Where(o =>
                o.TenantId == tenantId &&
                o.BranchId == branchId &&
                !o.IsDeleted &&
                o.CreatedAt >= start &&
                o.CreatedAt < end)
            .ToListAsync(ct);

        var completed = orders.Where(o => o.Status == OrderStatus.Delivered).ToList();

        return new OrderSummaryDto(
            Date:              date.Date,
            TotalOrders:       orders.Count,
            CompletedOrders:   completed.Count,
            CancelledOrders:   orders.Count(o => o.Status == OrderStatus.Cancelled),
            TotalRevenue:      completed.Sum(o => o.Total),
            TotalTax:          completed.Sum(o => o.TaxAmount),
            TotalDeliveryFees: completed.Sum(o => o.DeliveryFee),
            OrdersByType:      orders
                .GroupBy(o => o.Type.ToString())
                .ToDictionary(g => g.Key, g => g.Count()),
            RevenueByPaymentMethod: completed
                .GroupBy(o => o.PaymentMethod.ToString())
                .ToDictionary(g => g.Key, g => g.Sum(o => o.Total))
        );
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PRIVATE HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// يولّد رقم أوردر تسلسلي: ORD-20250615-0042
    /// يستخدم SELECT MAX لضمان uniqueness بدون race condition
    /// </summary>
    private async Task<string> GenerateOrderNumberAsync(Guid tenantId, CancellationToken ct)
    {
        var today    = DateTime.UtcNow.Date;
        var tomorrow = today.AddDays(1);
        var prefix   = $"ORD-{today:yyyyMMdd}-";

        var lastOrder = await _db.Orders
            .Where(o =>
                o.TenantId == tenantId &&
                o.CreatedAt >= today &&
                o.CreatedAt < tomorrow &&
                o.OrderNumber.StartsWith(prefix))
            .OrderByDescending(o => o.OrderNumber)
            .Select(o => o.OrderNumber)
            .FirstOrDefaultAsync(ct);

        int seq = 1;
        if (lastOrder is not null)
        {
            var parts = lastOrder.Split('-');
            if (parts.Length == 3 && int.TryParse(parts[2], out var prev))
                seq = prev + 1;
        }

        return $"{prefix}{seq:D4}";
    }

    /// <summary>
    /// حساب تكلفة التوصيل بناءً على المسافة بالكيلومتر (Haversine formula)
    /// </summary>
    private static decimal CalculateDeliveryFee(double? lat, double? lng, Branch branch)
    {
        if (!lat.HasValue || !lng.HasValue ||
            !branch.Latitude.HasValue || !branch.Longitude.HasValue)
            return BASE_DELIVERY;

        var distanceKm = Haversine(
            branch.Latitude.Value, branch.Longitude.Value,
            lat.Value, lng.Value);

        return Math.Max(BASE_DELIVERY, BASE_DELIVERY + (decimal)distanceKm * KM_RATE);
    }

    private static double Haversine(double lat1, double lon1, double lat2, double lon2)
    {
        const double R = 6371;
        var dLat = ToRad(lat2 - lat1);
        var dLon = ToRad(lon2 - lon1);
        var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                Math.Cos(ToRad(lat1)) * Math.Cos(ToRad(lat2)) *
                Math.Sin(dLon / 2) * Math.Sin(dLon / 2);
        return R * 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
    }

    private static double ToRad(double deg) => deg * Math.PI / 180;

    /// <summary>
    /// تحرير المخزون المحجوز.
    /// deduct=true  → يطرح من الـ Quantity الفعلي (عند التسليم)
    /// deduct=false → يرجع الكمية المحجوزة فقط (عند الإلغاء)
    /// </summary>
    private async Task ReleaseInventoryAsync(Order order, bool deduct, CancellationToken ct)
    {
        var productIds  = order.Items.Select(i => i.ProductId).Distinct().ToList();
        var inventories = await _db.Inventories
            .Where(inv => productIds.Contains(inv.ProductId) && inv.BranchId == order.BranchId)
            .ToListAsync(ct);

        foreach (var item in order.Items)
        {
            var inv = inventories.FirstOrDefault(i => i.ProductId == item.ProductId);
            if (inv is null) continue;

            inv.ReservedQuantity = Math.Max(0, inv.ReservedQuantity - item.Quantity);

            if (deduct)
                inv.Quantity = Math.Max(0, inv.Quantity - item.Quantity);
        }
    }

    /// <summary>
    /// تحديث إحصائيات العميل بعد إتمام الأوردر
    /// </summary>
    private async Task UpdateCustomerStatsAsync(
        Guid tenantId, Guid customerId, decimal amount, CancellationToken ct)
    {
        var customer = await _db.Customers
            .FirstOrDefaultAsync(c => c.Id == customerId && c.TenantId == tenantId, ct);

        if (customer is null) return;

        customer.TotalOrders++;
        customer.TotalSpent += amount;

        // Loyalty: جنيه = نقطة
        var earnedPoints = (int)(amount / 10);
        customer.LoyaltyPoints += earnedPoints;
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private static OrderDto MapToDto(Order o) => new(
        Id:             o.Id,
        OrderNumber:    o.OrderNumber,
        BranchId:       o.BranchId,
        BranchName:     o.Branch?.Name,
        CustomerId:     o.CustomerId,
        CustomerName:   o.Customer?.Name,
        UserId:         o.UserId,
        CashierName:    o.User is null ? null : $"{o.User.FirstName} {o.User.LastName}",
        Status:         o.Status,
        Type:           o.Type,
        TableNumber:    o.TableNumber,
        SubTotal:       o.SubTotal,
        Discount:       o.Discount,
        TaxAmount:      o.TaxAmount,
        DeliveryFee:    o.DeliveryFee,
        Total:          o.Total,
        PaymentMethod:  o.PaymentMethod,
        PaymentStatus:  o.PaymentStatus,
        Notes:          o.Notes,
        DeliveryAddress: o.DeliveryAddress,
        Items:          o.Items.Select(i => new OrderItemDto(
            ProductId:   i.ProductId,
            ProductName: i.Product?.Name ?? "—",
            Quantity:    i.Quantity,
            UnitPrice:   i.UnitPrice,
            Discount:    i.Discount,
            Total:       i.Total,
            Notes:       i.Notes
        )).ToList(),
        CreatedAt:   o.CreatedAt,
        CompletedAt: o.CompletedAt
    );
}
