using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MesterX.Application.Common.Interfaces;
using MesterX.Domain.Entities;
using MesterX.Domain.Enums;

namespace MesterX.Infrastructure.Services.Delivery;

/// <summary>
/// إدارة السائقين + تخصيص الأوردرات + تتبع real-time عبر SignalR
/// </summary>
public class DeliveryService : IDeliveryService
{
    private readonly MesterXDbContext _db;
    private readonly IHubContext<DeliveryHub> _hub;
    private readonly ILogger<DeliveryService> _logger;

    public DeliveryService(
        MesterXDbContext db,
        IHubContext<DeliveryHub> hub,
        ILogger<DeliveryService> logger)
    {
        _db = db;
        _hub = hub;
        _logger = logger;
    }

    // ── تسجيل سائق جديد ─────────────────────────────────────────────────────
    public async Task<DriverDto> RegisterDriverAsync(
        Guid tenantId, Guid userId, RegisterDriverRequest req, CancellationToken ct = default)
    {
        if (await _db.DeliveryDrivers.AnyAsync(
            d => d.TenantId == tenantId && d.UserId == userId && !d.IsDeleted, ct))
            throw new InvalidOperationException("هذا المستخدم مسجّل بالفعل كسائق.");

        var driver = new DeliveryDriver
        {
            TenantId           = tenantId,
            UserId             = userId,
            NationalIdFrontUrl = req.NationalIdFrontUrl,
            NationalIdBackUrl  = req.NationalIdBackUrl,
            VehicleType        = req.VehicleType,
            VehiclePlate       = req.VehiclePlate,
            IsVerified         = false,
            IsAvailable        = false,
            IsOnline           = false
        };

        _db.DeliveryDrivers.Add(driver);
        await _db.SaveChangesAsync(ct);

        _logger.LogInformation(
            "Driver registered: UserId={UserId}, TenantId={TenantId}",
            userId, tenantId);

        return await BuildDriverDtoAsync(driver.Id, ct);
    }

    // ── التحقق من السائق (Manager) ──────────────────────────────────────────
    public async Task VerifyDriverAsync(Guid driverId, CancellationToken ct = default)
    {
        var driver = await _db.DeliveryDrivers.FindAsync([driverId], ct)
            ?? throw new KeyNotFoundException("السائق غير موجود.");

        driver.IsVerified  = true;
        driver.IsAvailable = true;
        await _db.SaveChangesAsync(ct);

        // إشعار السائق
        await _hub.Clients.Group($"driver_{driver.UserId}")
            .SendAsync("DriverVerified", new { driverId = driver.Id }, ct);
    }

    // ── أونلاين / أوفلاين ───────────────────────────────────────────────────
    public async Task SetOnlineStatusAsync(
        Guid userId, bool isOnline, CancellationToken ct = default)
    {
        var driver = await _db.DeliveryDrivers
            .FirstOrDefaultAsync(d => d.UserId == userId && !d.IsDeleted, ct)
            ?? throw new KeyNotFoundException("سجّل نفسك كسائق أولاً.");

        if (!driver.IsVerified)
            throw new InvalidOperationException("حسابك لم يُفعَّل بعد. انتظر موافقة المدير.");

        driver.IsOnline    = isOnline;
        driver.IsAvailable = isOnline;
        await _db.SaveChangesAsync(ct);

        // بث الحالة لكل الـ managers في نفس الـ tenant
        await _hub.Clients.Group($"tenant_{driver.TenantId}_managers")
            .SendAsync("DriverStatusChanged", new
            {
                driverId  = driver.Id,
                userId    = driver.UserId,
                isOnline,
                updatedAt = DateTime.UtcNow
            }, ct);
    }

    // ── تحديث الموقع ────────────────────────────────────────────────────────
    public async Task UpdateLocationAsync(
        Guid userId, double lat, double lng, CancellationToken ct = default)
    {
        var driver = await _db.DeliveryDrivers
            .FirstOrDefaultAsync(d => d.UserId == userId && !d.IsDeleted, ct)
            ?? throw new KeyNotFoundException("السائق غير موجود.");

        driver.CurrentLatitude  = lat;
        driver.CurrentLongitude = lng;
        await _db.SaveChangesAsync(ct);

        // إيجاد الأوردر النشط لهذا السائق وبث الموقع للعميل
        var activeDelivery = await _db.DeliveryOrders
            .Include(d => d.Order)
            .FirstOrDefaultAsync(d =>
                d.DriverId == driver.Id &&
                d.Status   == DeliveryStatus.OnWay &&
                !d.IsDeleted, ct);

        if (activeDelivery is not null)
        {
            await _hub.Clients.Group($"order_{activeDelivery.OrderId}")
                .SendAsync("DriverLocationUpdated", new { lat, lng, driverId = driver.Id }, ct);
        }
    }

    // ── تخصيص سائق لأوردر ───────────────────────────────────────────────────
    public async Task<DeliveryOrderDto> AssignDriverAsync(
        Guid tenantId, Guid orderId, Guid driverId, CancellationToken ct = default)
    {
        var order = await _db.Orders
            .Include(o => o.Branch)
            .FirstOrDefaultAsync(o => o.Id == orderId && o.TenantId == tenantId && !o.IsDeleted, ct)
            ?? throw new KeyNotFoundException("الأوردر غير موجود.");

        var driver = await _db.DeliveryDrivers
            .Include(d => d.User)
            .FirstOrDefaultAsync(d => d.Id == driverId && d.TenantId == tenantId && !d.IsDeleted, ct)
            ?? throw new KeyNotFoundException("السائق غير موجود.");

        if (!driver.IsVerified || !driver.IsOnline)
            throw new InvalidOperationException("السائق غير متاح حالياً.");

        // إنشاء DeliveryOrder أو تحديثه
        var deliveryOrder = await _db.DeliveryOrders
            .FirstOrDefaultAsync(d => d.OrderId == orderId, ct);

        if (deliveryOrder is null)
        {
            deliveryOrder = new DeliveryOrder
            {
                OrderId         = orderId,
                DriverId        = driverId,
                Status          = DeliveryStatus.Assigned,
                PickupAddress   = order.Branch?.Address ?? "",
                PickupLatitude  = order.Branch?.Latitude  ?? 0,
                PickupLongitude = order.Branch?.Longitude ?? 0,
                DropoffAddress  = order.DeliveryAddress ?? "",
                DropoffLatitude  = order.DeliveryLat ?? 0,
                DropoffLongitude = order.DeliveryLng ?? 0,
                DeliveryFee      = order.DeliveryFee,
                AssignedAt       = DateTime.UtcNow
            };
            _db.DeliveryOrders.Add(deliveryOrder);
        }
        else
        {
            deliveryOrder.DriverId   = driverId;
            deliveryOrder.Status     = DeliveryStatus.Assigned;
            deliveryOrder.AssignedAt = DateTime.UtcNow;
        }

        driver.IsAvailable = false;
        order.Status = OrderStatus.OutForDelivery;

        await _db.SaveChangesAsync(ct);

        // إشعار السائق
        await _hub.Clients.Group($"driver_{driver.UserId}")
            .SendAsync("NewDeliveryAssigned", new
            {
                deliveryOrderId = deliveryOrder.Id,
                orderId         = order.Id,
                orderNumber     = order.OrderNumber,
                pickupAddress   = deliveryOrder.PickupAddress,
                dropoffAddress  = deliveryOrder.DropoffAddress,
                deliveryFee     = order.DeliveryFee
            }, ct);

        _logger.LogInformation(
            "Driver {DriverId} assigned to Order {OrderNumber}",
            driverId, order.OrderNumber);

        return await BuildDeliveryDtoAsync(deliveryOrder.Id, ct);
    }

    // ── تحديث حالة التوصيل ──────────────────────────────────────────────────
    public async Task<DeliveryOrderDto> UpdateDeliveryStatusAsync(
        Guid tenantId, Guid deliveryOrderId, DeliveryStatus status, CancellationToken ct = default)
    {
        var delivery = await _db.DeliveryOrders
            .Include(d => d.Order)
            .Include(d => d.Driver)
            .FirstOrDefaultAsync(d => d.Id == deliveryOrderId && !d.IsDeleted, ct)
            ?? throw new KeyNotFoundException("الأوردر غير موجود.");

        delivery.Status = status;

        switch (status)
        {
            case DeliveryStatus.PickedUp:
                delivery.PickedUpAt = DateTime.UtcNow;
                break;

            case DeliveryStatus.OnWay:
                break;

            case DeliveryStatus.Delivered:
                delivery.DeliveredAt = DateTime.UtcNow;
                delivery.Order.Status = OrderStatus.Delivered;
                delivery.Order.CompletedAt = DateTime.UtcNow;
                if (delivery.Driver is not null)
                {
                    delivery.Driver.IsAvailable = true;
                    delivery.Driver.TotalDeliveries++;
                }
                break;

            case DeliveryStatus.Failed:
            case DeliveryStatus.Returned:
                delivery.Order.Status = OrderStatus.Cancelled;
                if (delivery.Driver is not null)
                    delivery.Driver.IsAvailable = true;
                break;
        }

        await _db.SaveChangesAsync(ct);

        // إشعار العميل
        await _hub.Clients.Group($"order_{delivery.OrderId}")
            .SendAsync("DeliveryStatusUpdated", new
            {
                orderId    = delivery.OrderId,
                status     = status.ToString(),
                updatedAt  = DateTime.UtcNow
            }, ct);

        return await BuildDeliveryDtoAsync(deliveryOrderId, ct);
    }

    // ── السائقون المتاحون ────────────────────────────────────────────────────
    public async Task<List<DriverDto>> GetAvailableDriversAsync(
        Guid tenantId, CancellationToken ct = default)
    {
        var drivers = await _db.DeliveryDrivers
            .Include(d => d.User)
            .Where(d =>
                d.TenantId == tenantId &&
                d.IsVerified && d.IsOnline && d.IsAvailable &&
                !d.IsDeleted)
            .ToListAsync(ct);

        return drivers.Select(MapDriverToDto).ToList();
    }

    // ── التوصيلات النشطة ────────────────────────────────────────────────────
    public async Task<List<DeliveryOrderDto>> GetActiveDeliveriesAsync(
        Guid tenantId, Guid? driverId, CancellationToken ct = default)
    {
        var query = _db.DeliveryOrders
            .Include(d => d.Order)
            .Include(d => d.Driver).ThenInclude(dr => dr!.User)
            .Where(d =>
                d.Order.TenantId == tenantId &&
                !d.IsDeleted &&
                d.Status != DeliveryStatus.Delivered &&
                d.Status != DeliveryStatus.Failed &&
                d.Status != DeliveryStatus.Returned)
            .AsQueryable();

        if (driverId.HasValue)
            query = query.Where(d => d.DriverId == driverId.Value);

        var deliveries = await query.ToListAsync(ct);
        return deliveries.Select(MapDeliveryToDto).ToList();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private async Task<DriverDto> BuildDriverDtoAsync(Guid driverId, CancellationToken ct)
    {
        var driver = await _db.DeliveryDrivers
            .Include(d => d.User)
            .FirstAsync(d => d.Id == driverId, ct);
        return MapDriverToDto(driver);
    }

    private async Task<DeliveryOrderDto> BuildDeliveryDtoAsync(Guid id, CancellationToken ct)
    {
        var d = await _db.DeliveryOrders
            .Include(x => x.Order)
            .Include(x => x.Driver).ThenInclude(dr => dr!.User)
            .FirstAsync(x => x.Id == id, ct);
        return MapDeliveryToDto(d);
    }

    private static DriverDto MapDriverToDto(DeliveryDriver d) => new(
        d.Id,
        d.UserId,
        $"{d.User?.FirstName} {d.User?.LastName}".Trim(),
        d.User?.PhoneNumber,
        d.IsVerified, d.IsOnline, d.IsAvailable,
        d.Rating, d.TotalDeliveries,
        d.VehicleType,
        d.CurrentLatitude, d.CurrentLongitude
    );

    private static DeliveryOrderDto MapDeliveryToDto(DeliveryOrder d) => new(
        d.Id,
        d.OrderId,
        d.Order?.OrderNumber ?? "",
        d.DriverId,
        d.Driver is null ? null : $"{d.Driver.User?.FirstName} {d.Driver.User?.LastName}".Trim(),
        d.Status,
        d.PickupAddress,
        d.DropoffAddress,
        d.DeliveryFee,
        d.EstimatedMinutes,
        d.AssignedAt,
        d.DeliveredAt
    );
}
