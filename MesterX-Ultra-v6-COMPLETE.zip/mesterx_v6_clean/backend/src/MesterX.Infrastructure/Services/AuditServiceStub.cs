using System;
using System.Threading.Tasks;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;

namespace MesterX.Infrastructure.Services;

public class AuditServiceStub : IAuditService
{
    public Task LogAsync(
        Guid tenantId,
        Guid? userId,
        AuditAction action,
        string entityType,
        Guid? entityId = null,
        string? oldValues = null,
        string? newValues = null,
        bool isSuccess = true,
        string? errorMessage = null)
    {
        // For now, just return completed task.
        // Phase 1 logging can be added here (Serilog, etc.)
        return Task.CompletedTask;
    }
}
