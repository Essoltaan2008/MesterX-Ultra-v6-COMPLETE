using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MesterX.Domain.Entities;
using MesterX.Domain.Enums;

namespace MesterX.Infrastructure.Seeding;

/// <summary>
/// يشتغل مرة واحدة عند الـ startup — يعمل migrate ثم يضيف البيانات الأساسية لو مش موجودة.
/// </summary>
public static class DatabaseSeeder
{
    public static async Task SeedAsync(MesterXDbContext db, ILogger? logger = null)
    {
        await db.Database.MigrateAsync();

        await SeedPlansAsync(db);
        await SeedPlatformOwnerAsync(db);
        await SeedPluginsAsync(db);
        await SeedDemoTenantAsync(db);

        await db.SaveChangesAsync();

        logger?.LogInformation("✅ MesterX v6 database seeded successfully.");
        Console.WriteLine("✅ MesterX v6 database seeded successfully.");
    }

    // ══════════════════════════════════════════════════════════════════════
    // PLANS  — أسعار السوق المصري 2025
    // ══════════════════════════════════════════════════════════════════════
    private static async Task SeedPlansAsync(MesterXDbContext db)
    {
        if (await db.Plans.AnyAsync()) return;

        db.Plans.AddRange(

            // 0 — Trial (تجريبي 14 يوم)
            new Plan
            {
                Id = Guid.Parse("00000000-0000-0000-0000-000000000001"),
                Name = "تجريبي",
                NameEn = "Trial",
                Type = PlanType.Trial,
                MonthlyPrice = 0,
                AnnualPrice  = 0,
                MaxBranches  = 1,
                MaxUsers     = 3,
                MaxProducts  = 50,
                HasMarketplace           = false,
                HasDelivery              = false,
                HasAi                    = false,
                HasPluginStore           = false,
                HasWhatsApp              = false,
                MaxWhatsAppNumbers       = 0,
                HasWhiteLabel            = false,
                HasRestaurantModule      = false,
                MaxRestaurantTables      = 0,
                HasKDS                   = false,
                HasQRMenu                = false,
                HasTableReservations     = false,
                HasRestaurantAnalytics   = false,
                HasRentalModule          = false,
                MaxRentalAssets          = 0,
                HasRentalMarketplace     = false,
                IsActive = true
            },

            // 1 — Basic (999 جنيه / شهر)
            new Plan
            {
                Id = Guid.Parse("00000000-0000-0000-0000-000000000002"),
                Name = "الأساسية",
                NameEn = "Basic",
                Type = PlanType.Basic,
                MonthlyPrice = 999,
                AnnualPrice  = 9990,
                MaxBranches  = 2,
                MaxUsers     = 10,
                MaxProducts  = 500,
                HasMarketplace           = false,
                HasDelivery              = true,
                HasAi                    = false,
                HasPluginStore           = true,
                HasWhatsApp              = true,
                MaxWhatsAppNumbers       = 1,
                HasWhiteLabel            = false,
                HasRestaurantModule      = false,
                MaxRestaurantTables      = 0,
                HasKDS                   = false,
                HasQRMenu                = false,
                HasTableReservations     = false,
                HasRestaurantAnalytics   = false,
                HasRentalModule          = false,
                MaxRentalAssets          = 0,
                HasRentalMarketplace     = false,
                IsActive = true
            },

            // 2 — Pro Monthly (1499 جنيه / شهر)
            new Plan
            {
                Id = Guid.Parse("00000000-0000-0000-0000-000000000003"),
                Name = "المحترفة",
                NameEn = "Pro",
                Type = PlanType.ProMonthly,
                MonthlyPrice = 1499,
                AnnualPrice  = 14990,
                MaxBranches  = 10,
                MaxUsers     = 50,
                MaxProducts  = 5000,
                HasMarketplace           = true,
                HasDelivery              = true,
                HasAi                    = true,
                HasPluginStore           = true,
                HasWhatsApp              = true,
                MaxWhatsAppNumbers       = 3,
                HasWhiteLabel            = false,
                HasRestaurantModule      = true,
                MaxRestaurantTables      = 20,
                HasKDS                   = true,
                HasQRMenu                = true,
                HasTableReservations     = false,
                HasRestaurantAnalytics   = false,
                HasRentalModule          = true,
                MaxRentalAssets          = 100,
                HasRentalMarketplace     = false,
                IsActive = true
            },

            // 3 — Lifetime (30,000 جنيه مرة واحدة)
            new Plan
            {
                Id = Guid.Parse("00000000-0000-0000-0000-000000000004"),
                Name = "مدى الحياة",
                NameEn = "Lifetime",
                Type = PlanType.Lifetime,
                MonthlyPrice = 0,       // دفعة واحدة
                AnnualPrice  = 30000,   // نستخدم AnnualPrice للدفعة الكاملة
                MaxBranches  = 20,
                MaxUsers     = 100,
                MaxProducts  = 20000,
                HasMarketplace           = true,
                HasDelivery              = true,
                HasAi                    = true,
                HasPluginStore           = true,
                HasWhatsApp              = true,
                MaxWhatsAppNumbers       = 5,
                HasWhiteLabel            = true,
                HasRestaurantModule      = true,
                MaxRestaurantTables      = 30,
                HasKDS                   = true,
                HasQRMenu                = true,
                HasTableReservations     = true,
                HasRestaurantAnalytics   = false,
                HasRentalModule          = true,
                MaxRentalAssets          = 500,
                HasRentalMarketplace     = true,
                IsActive = true
            },

            // 4 — Enterprise (2500 جنيه / شهر)
            new Plan
            {
                Id = Guid.Parse("00000000-0000-0000-0000-000000000005"),
                Name = "المؤسسية",
                NameEn = "Enterprise",
                Type = PlanType.Enterprise,
                MonthlyPrice = 2500,
                AnnualPrice  = 25000,
                MaxBranches  = int.MaxValue,
                MaxUsers     = int.MaxValue,
                MaxProducts  = int.MaxValue,
                HasMarketplace           = true,
                HasDelivery              = true,
                HasAi                    = true,
                HasPluginStore           = true,
                HasWhatsApp              = true,
                MaxWhatsAppNumbers       = int.MaxValue,
                HasWhiteLabel            = true,
                HasRestaurantModule      = true,
                MaxRestaurantTables      = -1,   // -1 = غير محدود
                HasKDS                   = true,
                HasQRMenu                = true,
                HasTableReservations     = true,
                HasRestaurantAnalytics   = true,
                HasRentalModule          = true,
                MaxRentalAssets          = -1,
                HasRentalMarketplace     = true,
                HasRentalAiInsights      = true,
                IsActive = true
            }
        );
    }

    // ══════════════════════════════════════════════════════════════════════
    // PLATFORM OWNER
    // ══════════════════════════════════════════════════════════════════════
    private static async Task SeedPlatformOwnerAsync(MesterXDbContext db)
    {
        if (await db.Users.AnyAsync(u => u.Role == UserRole.PlatformOwner)) return;

        // BCrypt hash لـ "Admin@MesterX2025!" — غيّره فوراً في الـ production
        const string passwordHash = "$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGTTmUuAyHNP.RUzf5m/Yd3QpTu";

        db.Users.Add(new User
        {
            Id            = Guid.Parse("00000000-0000-0000-0000-000000000010"),
            TenantId      = null,
            Email         = "mahmoudtohamy44@gmail.com",
            PasswordHash  = passwordHash,
            FirstName     = "Mahmoud",
            LastName      = "Tohamy",
            PhoneNumber   = "+201090647292",
            Role          = UserRole.PlatformOwner,
            IsActive      = true,
            IsEmailVerified  = true,
            IsPhoneVerified  = true,
            TwoFactorEnabled = false
        });
    }

    // ══════════════════════════════════════════════════════════════════════
    // BUILT-IN PLUGINS
    // ══════════════════════════════════════════════════════════════════════
    private static async Task SeedPluginsAsync(MesterXDbContext db)
    {
        if (await db.Plugins.AnyAsync()) return;

        db.Plugins.AddRange(
            new Plugin
            {
                Name = "نظام الحجوزات",
                Slug = "booking-system",
                Description = "اتح للعملاء حجز الطاولات أو المواعيد أو الخدمات أونلاين.",
                Version = "1.0.0", DeveloperName = "MesterX",
                Price = 0, Category = PluginCategory.Booking,
                IsActive = true, IsVerified = true
            },
            new Plugin
            {
                Name = "برنامج الولاء",
                Slug = "loyalty-program",
                Description = "نظام نقاط مع مكافآت ومستويات للعملاء.",
                Version = "1.0.0", DeveloperName = "MesterX",
                Price = 0, Category = PluginCategory.Loyalty,
                IsActive = true, IsVerified = true
            },
            new Plugin
            {
                Name = "المحاسبة المتقدمة",
                Slug = "advanced-accounting",
                Description = "محاسبة مزدوجة، أرباح وخسائر، ميزانية عمومية وتقارير ضريبية.",
                Version = "1.0.0", DeveloperName = "MesterX",
                Price = 99, Category = PluginCategory.Accounting,
                IsActive = true, IsVerified = true
            },
            new Plugin
            {
                Name = "CRM Pro",
                Slug = "crm-pro",
                Description = "إدارة علاقات العملاء مع pipelines ومتابعات وتصنيف العملاء.",
                Version = "1.0.0", DeveloperName = "MesterX",
                Price = 149, Category = PluginCategory.CRM,
                IsActive = true, IsVerified = true
            },
            new Plugin
            {
                Name = "تسويق واتساب",
                Slug = "whatsapp-marketing",
                Description = "حملات واتساب بالجملة مع قوالب وجدولة.",
                Version = "1.0.0", DeveloperName = "MesterX",
                Price = 79, Category = PluginCategory.Marketing,
                IsActive = true, IsVerified = true
            }
        );
    }

    // ══════════════════════════════════════════════════════════════════════
    // DEMO TENANT  — مطعم تجريبي على الباقة المحترفة
    // ══════════════════════════════════════════════════════════════════════
    private static async Task SeedDemoTenantAsync(MesterXDbContext db)
    {
        if (await db.Tenants.AnyAsync()) return;

        var tenantId  = Guid.Parse("00000000-0000-0000-0000-000000000100");
        var branchId  = Guid.Parse("00000000-0000-0000-0000-000000000101");
        var ownerId   = Guid.Parse("00000000-0000-0000-0000-000000000102");
        var proPlanId = Guid.Parse("00000000-0000-0000-0000-000000000003");

        const string passwordHash = "$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGTTmUuAyHNP.RUzf5m/Yd3QpTu";

        // ── Tenant ─────────────────────────────────────────────────────────
        db.Tenants.Add(new Tenant
        {
            Id            = tenantId,
            Name          = "مطعم المسترX التجريبي",
            Slug          = "demo-restaurant",
            Plan          = PlanType.ProMonthly,
            PhoneNumber   = "+20100000000",
            Email         = "demo@mesterx.com",
            Address       = "شارع التحرير، وسط البلد",
            City          = "Cairo",
            IsActive      = true,
            IsVerified    = true,
            ActiveModules = (int)(TenantModules.POS | TenantModules.Restaurant)
        });

        // ── Owner User ────────────────────────────────────────────────────
        db.Users.Add(new User
        {
            Id             = ownerId,
            TenantId       = tenantId,
            Email          = "owner@demo.mesterx.com",
            PasswordHash   = passwordHash,
            FirstName      = "أحمد",
            LastName       = "محمود",
            PhoneNumber    = "+20100111111",
            Role           = UserRole.CompanyOwner,
            IsActive       = true,
            IsEmailVerified = true
        });

        // ── Main Branch ───────────────────────────────────────────────────
        db.Branches.Add(new Branch
        {
            Id          = branchId,
            TenantId    = tenantId,
            ManagerId   = ownerId,
            Name        = "الفرع الرئيسي — وسط البلد",
            Address     = "شارع التحرير، وسط البلد، القاهرة",
            City        = "Cairo",
            Latitude    = 30.0444,
            Longitude   = 31.2357,
            PhoneNumber = "+20100222222",
            IsActive    = true
        });

        // ── Active Subscription (Pro) ─────────────────────────────────────
        db.Subscriptions.Add(new Subscription
        {
            TenantId      = tenantId,
            PlanId        = proPlanId,
            Status        = SubscriptionStatus.Active,
            BillingCycle  = BillingCycle.Monthly,
            Amount        = 1499,
            StartDate     = DateTime.UtcNow,
            EndDate       = DateTime.UtcNow.AddMonths(1),
            AutoRenew     = true
        });

        // ── Demo Category ─────────────────────────────────────────────────
        var catId = Guid.Parse("00000000-0000-0000-0000-000000000201");
        db.Categories.Add(new Category
        {
            Id        = catId,
            TenantId  = tenantId,
            Name      = "المشروبات",
            SortOrder = 1,
            IsActive  = true
        });

        // ── Demo Product ──────────────────────────────────────────────────
        var productId = Guid.Parse("00000000-0000-0000-0000-000000000301");
        db.Products.Add(new Product
        {
            Id                 = productId,
            TenantId           = tenantId,
            BranchId           = branchId,
            CategoryId         = catId,
            Name               = "قهوة عربية",
            Description        = "قهوة عربية أصيلة بالهيل",
            Price              = 35,
            Cost               = 10,
            SKU                = "COFFEE-001",
            Type               = ProductType.Physical,
            TrackInventory     = true,
            IsActive           = true,
            IsAvailableOnline  = true
        });

        // ── Initial Inventory ─────────────────────────────────────────────
        db.Inventories.Add(new Inventory
        {
            TenantId    = tenantId,
            ProductId   = productId,
            BranchId    = branchId,
            Quantity    = 100,
            MinQuantity = 10,
            MaxQuantity = 500
        });

        // ── Demo Customer ─────────────────────────────────────────────────
        db.Customers.Add(new Customer
        {
            TenantId       = tenantId,
            Name           = "عميل تجريبي",
            PhoneNumber    = "+20100999999",
            Email          = "customer@demo.com",
            City           = "Cairo",
            LoyaltyPoints  = 50,
            TotalSpent     = 0,
            TotalOrders    = 0
        });
    }
}
