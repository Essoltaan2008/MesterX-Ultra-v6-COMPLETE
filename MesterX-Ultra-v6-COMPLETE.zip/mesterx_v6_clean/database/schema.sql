-- ═══════════════════════════════════════════════════════════════════════════
-- MesterX Ultra Enterprise v6 — PostgreSQL Schema
-- إنتاج مصري 🇪🇬 | ضريبة القيمة المضافة 14%
-- Engine: PostgreSQL 16 | Extensions: uuid-ossp, pg_trgm
-- ═══════════════════════════════════════════════════════════════════════════

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ─── AUTO TIMESTAMP FUNCTION ──────────────────────────────────────────────
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

-- ═══════════════════════════════════════════════════════════════════════════
-- CORE — TENANTS / AUTH
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS tenants (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name             VARCHAR(200) NOT NULL,
    name_ar          VARCHAR(200),
    slug             VARCHAR(100) NOT NULL UNIQUE,
    tax_number       VARCHAR(50),
    phone            VARCHAR(30),
    email            VARCHAR(200),
    address          TEXT,
    logo_url         TEXT,
    currency         VARCHAR(10) NOT NULL DEFAULT 'EGP',
    vat_rate         DECIMAL(5,4) NOT NULL DEFAULT 0.14,
    status           SMALLINT NOT NULL DEFAULT 0,
    modules          INTEGER NOT NULL DEFAULT 1,
    current_license_id UUID,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by       UUID,
    updated_by       UUID,
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_tenants_slug   ON tenants(slug);
CREATE INDEX IF NOT EXISTS idx_tenants_status ON tenants(status);

CREATE TABLE IF NOT EXISTS branches (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name             VARCHAR(200) NOT NULL,
    name_ar          VARCHAR(200),
    address          TEXT,
    phone            VARCHAR(30),
    is_main          BOOLEAN NOT NULL DEFAULT FALSE,
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by       UUID,
    updated_by       UUID,
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_branches_tenant ON branches(tenant_id);

CREATE TABLE IF NOT EXISTS users (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id        UUID REFERENCES branches(id) ON DELETE SET NULL,
    full_name        VARCHAR(200) NOT NULL,
    email            VARCHAR(200) NOT NULL,
    phone            VARCHAR(30),
    password_hash    VARCHAR(500) NOT NULL,
    role             SMALLINT NOT NULL DEFAULT 3,
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    last_login_at    TIMESTAMPTZ,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by       UUID,
    updated_by       UUID,
    version          INTEGER NOT NULL DEFAULT 1,
    UNIQUE(tenant_id, email)
);
CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_users_email  ON users(email);

CREATE TABLE IF NOT EXISTS refresh_tokens (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    user_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash       VARCHAR(500) NOT NULL UNIQUE,
    expires_at       TIMESTAMPTZ NOT NULL,
    is_revoked       BOOLEAN NOT NULL DEFAULT FALSE,
    revoked_at       TIMESTAMPTZ,
    device_info      TEXT,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user ON refresh_tokens(user_id);

CREATE TABLE IF NOT EXISTS roles (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    name             VARCHAR(100) NOT NULL,
    name_ar          VARCHAR(100),
    is_system        BOOLEAN NOT NULL DEFAULT FALSE,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS permissions (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name             VARCHAR(200) NOT NULL UNIQUE,
    description_ar   TEXT
);

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id          UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id    UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS feature_flags (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    module           VARCHAR(50) NOT NULL,
    is_enabled       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1,
    UNIQUE(tenant_id, module)
);

-- ═══════════════════════════════════════════════════════════════════════════
-- LICENSING
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS licenses (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    plan_type        SMALLINT NOT NULL DEFAULT 0,
    status           SMALLINT NOT NULL DEFAULT 0,
    license_key_hash VARCHAR(500) NOT NULL UNIQUE,
    amount_paid      DECIMAL(12,2) NOT NULL DEFAULT 0,
    starts_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at       TIMESTAMPTZ,
    sync_addon_expires_at TIMESTAMPTZ,
    max_devices      INTEGER NOT NULL DEFAULT 1,
    notes            TEXT,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by       UUID,
    updated_by       UUID,
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_licenses_tenant ON licenses(tenant_id);
CREATE INDEX IF NOT EXISTS idx_licenses_status ON licenses(status);

CREATE TABLE IF NOT EXISTS device_registrations (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    license_id       UUID NOT NULL REFERENCES licenses(id) ON DELETE CASCADE,
    fingerprint_hash VARCHAR(500) NOT NULL,
    device_name      VARCHAR(200) NOT NULL,
    os               VARCHAR(100),
    app_version      VARCHAR(50),
    last_seen_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_revoked       BOOLEAN NOT NULL DEFAULT FALSE,
    revoked_at       TIMESTAMPTZ,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1,
    UNIQUE(license_id, fingerprint_hash)
);

-- ═══════════════════════════════════════════════════════════════════════════
-- PRODUCTS / INVENTORY
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS categories (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    parent_id        UUID REFERENCES categories(id) ON DELETE SET NULL,
    name             VARCHAR(200) NOT NULL,
    name_ar          VARCHAR(200),
    icon_url         TEXT,
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    sort_order       INTEGER NOT NULL DEFAULT 0,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_categories_tenant ON categories(tenant_id);

CREATE TABLE IF NOT EXISTS products (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    category_id      UUID REFERENCES categories(id) ON DELETE SET NULL,
    name             VARCHAR(300) NOT NULL,
    name_ar          VARCHAR(300),
    sku              VARCHAR(100),
    barcode          VARCHAR(100),
    description      TEXT,
    image_url        TEXT,
    cost_price       DECIMAL(12,2) NOT NULL DEFAULT 0,
    sell_price       DECIMAL(12,2) NOT NULL DEFAULT 0,
    vat_rate         DECIMAL(5,4) NOT NULL DEFAULT 0.14,
    unit             VARCHAR(50) NOT NULL DEFAULT 'قطعة',
    min_stock_level  DECIMAL(12,4) NOT NULL DEFAULT 0,
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    is_service       BOOLEAN NOT NULL DEFAULT FALSE,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by       UUID,
    updated_by       UUID,
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_products_sku    ON products(tenant_id, sku) WHERE sku IS NOT NULL;
CREATE INDEX       IF NOT EXISTS idx_products_barcode ON products(barcode)        WHERE barcode IS NOT NULL;
CREATE INDEX       IF NOT EXISTS idx_products_tenant  ON products(tenant_id);
CREATE INDEX       IF NOT EXISTS idx_products_search  ON products USING gin(name gin_trgm_ops);

CREATE TABLE IF NOT EXISTS stock_items (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    product_id       UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    branch_id        UUID NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    quantity         DECIMAL(12,4) NOT NULL DEFAULT 0,
    reserved_qty     DECIMAL(12,4) NOT NULL DEFAULT 0,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1,
    UNIQUE(product_id, branch_id)
);
CREATE INDEX IF NOT EXISTS idx_stock_tenant ON stock_items(tenant_id);

CREATE TABLE IF NOT EXISTS stock_movements (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    product_id       UUID NOT NULL,
    branch_id        UUID NOT NULL,
    movement_type    SMALLINT NOT NULL,
    quantity_before  DECIMAL(12,4) NOT NULL,
    quantity_change  DECIMAL(12,4) NOT NULL,
    quantity_after   DECIMAL(12,4) NOT NULL,
    reference_id     UUID,
    reference_type   VARCHAR(50),
    notes            TEXT,
    created_by       UUID,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_stock_mov_tenant    ON stock_movements(tenant_id);
CREATE INDEX IF NOT EXISTS idx_stock_mov_product   ON stock_movements(product_id);
CREATE INDEX IF NOT EXISTS idx_stock_mov_created   ON stock_movements(created_at);

-- ═══════════════════════════════════════════════════════════════════════════
-- CUSTOMERS / SUPPLIERS
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS customers (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    name             VARCHAR(200) NOT NULL,
    name_ar          VARCHAR(200),
    phone            VARCHAR(30),
    email            VARCHAR(200),
    address          TEXT,
    tax_number       VARCHAR(50),
    total_purchases  DECIMAL(14,2) NOT NULL DEFAULT 0,
    loyalty_points   INTEGER NOT NULL DEFAULT 0,
    credit_limit     DECIMAL(12,2) NOT NULL DEFAULT 0,
    outstanding_bal  DECIMAL(12,2) NOT NULL DEFAULT 0,
    segment          SMALLINT NOT NULL DEFAULT 0,
    notes            TEXT,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by       UUID,
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_customers_tenant ON customers(tenant_id);
CREATE INDEX IF NOT EXISTS idx_customers_phone  ON customers(tenant_id, phone);

CREATE TABLE IF NOT EXISTS suppliers (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    name             VARCHAR(200) NOT NULL,
    name_ar          VARCHAR(200),
    contact_person   VARCHAR(200),
    phone            VARCHAR(30),
    email            VARCHAR(200),
    address          TEXT,
    tax_number       VARCHAR(50),
    bank_account     VARCHAR(100),
    credit_limit     DECIMAL(12,2) NOT NULL DEFAULT 0,
    outstanding_bal  DECIMAL(12,2) NOT NULL DEFAULT 0,
    status           SMALLINT NOT NULL DEFAULT 0,
    notes            TEXT,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_suppliers_tenant ON suppliers(tenant_id);

-- ═══════════════════════════════════════════════════════════════════════════
-- POS — SALES
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS sale_orders (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    branch_id        UUID NOT NULL REFERENCES branches(id),
    order_number     VARCHAR(50) NOT NULL UNIQUE,
    customer_id      UUID REFERENCES customers(id) ON DELETE SET NULL,
    cashier_id       UUID REFERENCES users(id) ON DELETE SET NULL,
    status           SMALLINT NOT NULL DEFAULT 0,
    sub_total        DECIMAL(14,2) NOT NULL DEFAULT 0,
    vat_amount       DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount_amount  DECIMAL(12,2) NOT NULL DEFAULT 0,
    total_amount     DECIMAL(14,2) NOT NULL DEFAULT 0,
    amount_paid      DECIMAL(14,2) NOT NULL DEFAULT 0,
    change_given     DECIMAL(12,2) NOT NULL DEFAULT 0,
    payment_method   SMALLINT NOT NULL DEFAULT 0,
    notes            TEXT,
    client_ref_id    UUID,
    is_offline_order BOOLEAN NOT NULL DEFAULT FALSE,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by       UUID,
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_sale_orders_tenant  ON sale_orders(tenant_id);
CREATE INDEX IF NOT EXISTS idx_sale_orders_branch  ON sale_orders(branch_id);
CREATE INDEX IF NOT EXISTS idx_sale_orders_created ON sale_orders(created_at);

CREATE TABLE IF NOT EXISTS sale_order_items (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    sale_order_id    UUID NOT NULL REFERENCES sale_orders(id) ON DELETE CASCADE,
    product_id       UUID NOT NULL REFERENCES products(id),
    product_name     VARCHAR(300) NOT NULL,
    quantity         DECIMAL(12,4) NOT NULL,
    unit_price       DECIMAL(12,2) NOT NULL,
    vat_amount       DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount_amount  DECIMAL(12,2) NOT NULL DEFAULT 0,
    line_total       DECIMAL(14,2) NOT NULL,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_sale_items_order ON sale_order_items(sale_order_id);

CREATE TABLE IF NOT EXISTS payments (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    sale_order_id    UUID NOT NULL REFERENCES sale_orders(id) ON DELETE CASCADE,
    method           SMALLINT NOT NULL DEFAULT 0,
    amount           DECIMAL(12,2) NOT NULL,
    reference_number VARCHAR(200),
    status           SMALLINT NOT NULL DEFAULT 2,
    notes            TEXT,
    paid_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_payments_order ON payments(sale_order_id);

CREATE TABLE IF NOT EXISTS sale_refunds (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    sale_order_id    UUID NOT NULL REFERENCES sale_orders(id),
    refund_amount    DECIMAL(12,2) NOT NULL,
    reason           TEXT,
    refunded_by      UUID REFERENCES users(id),
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);

-- ═══════════════════════════════════════════════════════════════════════════
-- PURCHASE ORDERS / EXPENSES
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS purchase_orders (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    branch_id        UUID NOT NULL REFERENCES branches(id),
    supplier_id      UUID NOT NULL REFERENCES suppliers(id),
    po_number        VARCHAR(50) NOT NULL UNIQUE,
    status           SMALLINT NOT NULL DEFAULT 0,
    order_date       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expected_date    TIMESTAMPTZ,
    received_date    TIMESTAMPTZ,
    total_amount     DECIMAL(14,2) NOT NULL DEFAULT 0,
    amount_paid      DECIMAL(12,2) NOT NULL DEFAULT 0,
    notes            TEXT,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by       UUID,
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_po_tenant ON purchase_orders(tenant_id);

CREATE TABLE IF NOT EXISTS purchase_order_items (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    purchase_order_id UUID NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
    product_id       UUID NOT NULL REFERENCES products(id),
    quantity_ordered DECIMAL(12,4) NOT NULL,
    quantity_received DECIMAL(12,4) NOT NULL DEFAULT 0,
    unit_cost        DECIMAL(12,2) NOT NULL,
    line_total       DECIMAL(14,2) NOT NULL,
    notes            TEXT,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS expenses (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    branch_id        UUID NOT NULL REFERENCES branches(id),
    description      VARCHAR(500) NOT NULL,
    category         SMALLINT NOT NULL DEFAULT 7,
    amount           DECIMAL(12,2) NOT NULL,
    expense_date     DATE NOT NULL DEFAULT CURRENT_DATE,
    receipt_url      TEXT,
    approved_by      UUID,
    approved_at      TIMESTAMPTZ,
    notes            TEXT,
    recorded_by      UUID REFERENCES users(id),
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_expenses_tenant ON expenses(tenant_id);
CREATE INDEX IF NOT EXISTS idx_expenses_date   ON expenses(expense_date);

-- ═══════════════════════════════════════════════════════════════════════════
-- SYNC / AUDIT
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS sync_queue (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    idempotency_key  VARCHAR(100) NOT NULL,
    entity_type      SMALLINT NOT NULL,
    operation        SMALLINT NOT NULL DEFAULT 0,
    payload          JSONB NOT NULL,
    status           SMALLINT NOT NULL DEFAULT 0,
    conflict_strategy SMALLINT NOT NULL DEFAULT 0,
    server_version   INTEGER,
    client_version   INTEGER,
    resolved_at      TIMESTAMPTZ,
    error_message    TEXT,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1,
    UNIQUE(tenant_id, idempotency_key)
);
CREATE INDEX IF NOT EXISTS idx_sync_queue_tenant ON sync_queue(tenant_id);
CREATE INDEX IF NOT EXISTS idx_sync_queue_status ON sync_queue(status);

CREATE TABLE IF NOT EXISTS sync_logs (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    user_id          UUID,
    branch_id        UUID,
    sync_started_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    sync_completed_at TIMESTAMPTZ,
    records_pushed   INTEGER NOT NULL DEFAULT 0,
    records_pulled   INTEGER NOT NULL DEFAULT 0,
    conflicts_detected INTEGER NOT NULL DEFAULT 0,
    conflicts_resolved INTEGER NOT NULL DEFAULT 0,
    is_success       BOOLEAN NOT NULL DEFAULT TRUE,
    error_message    TEXT,
    client_version   VARCHAR(50),
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_sync_logs_tenant ON sync_logs(tenant_id);
CREATE INDEX IF NOT EXISTS idx_sync_logs_date   ON sync_logs(sync_started_at);

CREATE TABLE IF NOT EXISTS audit_logs (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    user_id          UUID,
    action           SMALLINT NOT NULL,
    entity_type      VARCHAR(100) NOT NULL,
    entity_id        UUID,
    old_values       JSONB,
    new_values       JSONB,
    ip_address       VARCHAR(50),
    user_agent       TEXT,
    is_success       BOOLEAN NOT NULL DEFAULT TRUE,
    error_message    TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_audit_tenant  ON audit_logs(tenant_id);
CREATE INDEX IF NOT EXISTS idx_audit_user    ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);

CREATE TABLE IF NOT EXISTS platform_configs (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key              VARCHAR(200) NOT NULL UNIQUE,
    value            TEXT,
    description_ar   TEXT,
    is_public        BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);

-- ═══════════════════════════════════════════════════════════════════════════
-- MARKETPLACE / VENDORS
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS vendor_categories (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    name             VARCHAR(200) NOT NULL,
    name_ar          VARCHAR(200),
    description      TEXT,
    icon_url         TEXT,
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS vendors (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    category_id      UUID REFERENCES vendor_categories(id),
    user_id          UUID REFERENCES users(id),
    name             VARCHAR(200) NOT NULL,
    name_ar          VARCHAR(200),
    bio              TEXT,
    phone            VARCHAR(30),
    whatsapp         VARCHAR(30),
    email            VARCHAR(200),
    address          TEXT,
    city             VARCHAR(100),
    vendor_type      SMALLINT NOT NULL DEFAULT 10,
    status           SMALLINT NOT NULL DEFAULT 0,
    rating           DECIMAL(3,2) NOT NULL DEFAULT 0,
    reviews_count    INTEGER NOT NULL DEFAULT 0,
    is_verified      BOOLEAN NOT NULL DEFAULT FALSE,
    commission_rate  DECIMAL(5,4) NOT NULL DEFAULT 0.10,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_vendors_tenant ON vendors(tenant_id);
CREATE INDEX IF NOT EXISTS idx_vendors_status ON vendors(status);

CREATE TABLE IF NOT EXISTS vendor_services (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    vendor_id        UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    name             VARCHAR(300) NOT NULL,
    name_ar          VARCHAR(300),
    description      TEXT,
    base_price       DECIMAL(12,2) NOT NULL DEFAULT 0,
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS vendor_availabilities (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    vendor_id        UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    available_date   DATE NOT NULL,
    start_time       TIME NOT NULL,
    end_time         TIME NOT NULL,
    max_bookings     INTEGER NOT NULL DEFAULT 1,
    booked_count     INTEGER NOT NULL DEFAULT 0,
    is_blocked       BOOLEAN NOT NULL DEFAULT FALSE,
    block_reason     TEXT,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_vendor_avail_date ON vendor_availabilities(vendor_id, available_date);

CREATE TABLE IF NOT EXISTS bookings (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    vendor_id        UUID NOT NULL REFERENCES vendors(id),
    customer_id      UUID NOT NULL REFERENCES customers(id),
    booking_number   VARCHAR(50) NOT NULL UNIQUE,
    event_date       DATE NOT NULL,
    estimated_guests INTEGER,
    status           SMALLINT NOT NULL DEFAULT 0,
    total_price      DECIMAL(14,2) NOT NULL DEFAULT 0,
    deposit_amount   DECIMAL(12,2) NOT NULL DEFAULT 0,
    remaining_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    deposit_paid_at  TIMESTAMPTZ,
    full_paid_at     TIMESTAMPTZ,
    notes            TEXT,
    vendor_notes     TEXT,
    contract_url     TEXT,
    contract_signed_at TIMESTAMPTZ,
    cancelled_at     TIMESTAMPTZ,
    cancellation_reason TEXT,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at       TIMESTAMPTZ,
    deleted_by       UUID,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_bookings_tenant ON bookings(tenant_id);
CREATE INDEX IF NOT EXISTS idx_bookings_vendor ON bookings(vendor_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);

CREATE TABLE IF NOT EXISTS booking_payments (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    booking_id       UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    amount           DECIMAL(12,2) NOT NULL,
    payment_type     SMALLINT NOT NULL DEFAULT 0,
    method           SMALLINT NOT NULL DEFAULT 0,
    status           SMALLINT NOT NULL DEFAULT 0,
    transaction_id   VARCHAR(200),
    paid_at          TIMESTAMPTZ,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS booking_services (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    booking_id       UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    service_id       UUID REFERENCES vendor_services(id),
    name             VARCHAR(300) NOT NULL,
    price            DECIMAL(12,2) NOT NULL DEFAULT 0,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS booking_timeline (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    booking_id       UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    event_type       SMALLINT NOT NULL,
    description      TEXT,
    performed_by     UUID,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS vendor_reviews (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    vendor_id        UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    customer_id      UUID REFERENCES customers(id),
    booking_id       UUID REFERENCES bookings(id),
    rating           SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment          TEXT,
    is_published     BOOLEAN NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS vendor_payments (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id        UUID NOT NULL,
    vendor_id        UUID NOT NULL REFERENCES vendors(id),
    amount           DECIMAL(12,2) NOT NULL,
    status           SMALLINT NOT NULL DEFAULT 0,
    bank_account     VARCHAR(100),
    bank_name        VARCHAR(100),
    transaction_id   VARCHAR(200),
    processed_at     TIMESTAMPTZ,
    notes            TEXT,
    is_deleted       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version          INTEGER NOT NULL DEFAULT 1
);

-- ═══════════════════════════════════════════════════════════════════════════
-- AUTO-TIMESTAMP TRIGGERS
-- ═══════════════════════════════════════════════════════════════════════════

DO $$
DECLARE t TEXT;
BEGIN
  FOR t IN SELECT table_name FROM information_schema.columns
           WHERE column_name = 'updated_at'
             AND table_schema = 'public'
  LOOP
    EXECUTE format('
      DROP TRIGGER IF EXISTS trg_updated_at ON %I;
      CREATE TRIGGER trg_updated_at
        BEFORE UPDATE ON %I
        FOR EACH ROW EXECUTE FUNCTION set_updated_at();
    ', t, t);
  END LOOP;
END $$;

-- ═══════════════════════════════════════════════════════════════════════════
-- VIEWS
-- ═══════════════════════════════════════════════════════════════════════════

CREATE OR REPLACE VIEW v_stock_levels AS
SELECT
    si.tenant_id,
    si.branch_id,
    b.name         AS branch_name,
    p.id           AS product_id,
    p.name         AS product_name,
    p.name_ar,
    p.sku,
    p.barcode,
    p.sell_price,
    si.quantity,
    si.reserved_qty,
    (si.quantity - si.reserved_qty) AS available_qty,
    p.min_stock_level,
    CASE WHEN (si.quantity - si.reserved_qty) <= p.min_stock_level
         THEN TRUE ELSE FALSE END AS is_low_stock
FROM stock_items si
JOIN products  p ON p.id = si.product_id
JOIN branches  b ON b.id = si.branch_id
WHERE si.is_deleted = FALSE
  AND p.is_deleted  = FALSE;

CREATE OR REPLACE VIEW v_daily_sales AS
SELECT
    tenant_id,
    branch_id,
    DATE(created_at)       AS sale_date,
    COUNT(*)               AS total_orders,
    SUM(total_amount)      AS total_revenue,
    SUM(vat_amount)        AS total_vat,
    SUM(discount_amount)   AS total_discount,
    AVG(total_amount)      AS avg_order_value
FROM sale_orders
WHERE is_deleted = FALSE
  AND status     = 1
GROUP BY tenant_id, branch_id, DATE(created_at);

-- ═══════════════════════════════════════════════════════════════════════════
-- SEED DATA
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO platform_configs (id, key, value, description_ar, is_public) VALUES
  (uuid_generate_v4(), 'vat_rate',          '0.14',       'نسبة ضريبة القيمة المضافة المصرية', TRUE),
  (uuid_generate_v4(), 'currency',          'EGP',        'العملة الافتراضية', TRUE),
  (uuid_generate_v4(), 'currency_symbol',   'ج.م',        'رمز العملة', TRUE),
  (uuid_generate_v4(), 'trial_days',        '14',         'مدة التجربة المجانية بالأيام', FALSE),
  (uuid_generate_v4(), 'pro_price_monthly', '499',        'سعر الباقة الشهرية بالجنيه', FALSE),
  (uuid_generate_v4(), 'lifetime_price',    '9999',       'سعر الترخيص الدائم بالجنيه', FALSE),
  (uuid_generate_v4(), 'enterprise_price',  '1999',       'سعر باقة الإنتربرايز شهرياً بالجنيه', FALSE),
  (uuid_generate_v4(), 'sync_addon_price',  '999',        'سعر إضافة المزامنة السنوية', FALSE),
  (uuid_generate_v4(), 'support_phone',     '01000000000','رقم الدعم الفني', TRUE),
  (uuid_generate_v4(), 'support_email',     'support@mesterx.com', 'إيميل الدعم', TRUE)
ON CONFLICT (key) DO NOTHING;
