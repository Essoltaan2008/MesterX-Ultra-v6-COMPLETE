-- ═══════════════════════════════════════════════════════════════════════════
-- MesterX — Rental Module Migration
-- يُنفَّذ بعد الـ migration الأساسي للـ POS (public schema)
-- ═══════════════════════════════════════════════════════════════════════════

-- ── 0. Create rental schema ────────────────────────────────────────────────
CREATE SCHEMA IF NOT EXISTS rental;

-- ── 1. Patches على الجداول الموجودة ──────────────────────────────────────

-- 1a. Tenant — إضافة ActiveModules
ALTER TABLE tenants
    ADD COLUMN IF NOT EXISTS active_modules INTEGER NOT NULL DEFAULT 1;
-- 1 = POS فقط مفعّل (TenantModules.POS)
-- 3 = POS + Rental  (TenantModules.Both)

COMMENT ON COLUMN tenants.active_modules
    IS 'Bitmask: 1=POS, 2=Rental, 3=Both';

-- 1b. Plans — إضافة Rental flags
ALTER TABLE plans
    ADD COLUMN IF NOT EXISTS has_rental_module      BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS max_rental_assets      INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS has_rental_marketplace BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS has_rental_ai_insights BOOLEAN NOT NULL DEFAULT FALSE;

-- 1c. Customers — إضافة Rental-specific fields (nullable — لا تأثير على POS)
ALTER TABLE customers
    ADD COLUMN IF NOT EXISTS national_id        VARCHAR(30)  DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS id_image_url       VARCHAR(500) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS is_blacklisted     BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS blacklist_reason   VARCHAR(300) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS outstanding_debt   DECIMAL(12,2) NOT NULL DEFAULT 0;

-- ── 2. Rental Assets ───────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS rental.rental_assets (
    id                    UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id             UUID         NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

    asset_code            VARCHAR(30)  NOT NULL,
    name                  VARCHAR(200) NOT NULL,
    category              SMALLINT     NOT NULL,   -- AssetCategory enum
    sub_category          VARCHAR(100),
    brand                 VARCHAR(100),
    size                  VARCHAR(50),
    color                 VARCHAR(50),
    description           VARCHAR(800),

    pricing_model         SMALLINT     NOT NULL DEFAULT 0,  -- RentalPricingModel
    rental_price_per_day  DECIMAL(12,2) NOT NULL DEFAULT 0,
    rental_price_per_hour DECIMAL(12,2) NOT NULL DEFAULT 0,
    sale_price            DECIMAL(12,2) NOT NULL DEFAULT 0,
    deposit_amount        DECIMAL(12,2) NOT NULL DEFAULT 0,
    purchase_cost         DECIMAL(12,2) NOT NULL DEFAULT 0,
    late_penalty_per_day  DECIMAL(12,2) NOT NULL DEFAULT 0,
    max_rental_days       INTEGER      NOT NULL DEFAULT 7,

    status                SMALLINT     NOT NULL DEFAULT 0,  -- AssetStatus
    condition             SMALLINT     NOT NULL DEFAULT 0,  -- AssetCondition
    barcode               VARCHAR(100),
    qr_code_url           VARCHAR(500),
    primary_image_url     VARCHAR(500),
    is_listed_on_marketplace BOOLEAN  NOT NULL DEFAULT FALSE,

    total_rental_count    INTEGER      NOT NULL DEFAULT 0,
    total_revenue         DECIMAL(14,2) NOT NULL DEFAULT 0,
    last_rented_at        TIMESTAMPTZ,

    -- BaseEntity
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by  UUID,
    updated_by  UUID,
    is_deleted  BOOLEAN     NOT NULL DEFAULT FALSE,
    deleted_at  TIMESTAMPTZ,
    deleted_by  UUID,
    version     BIGINT      NOT NULL DEFAULT 1,

    CONSTRAINT uq_asset_code UNIQUE (tenant_id, asset_code)
);

CREATE INDEX IF NOT EXISTS idx_rental_assets_tenant_status
    ON rental.rental_assets (tenant_id, status) WHERE NOT is_deleted;

CREATE INDEX IF NOT EXISTS idx_rental_assets_tenant_category
    ON rental.rental_assets (tenant_id, category) WHERE NOT is_deleted;

CREATE INDEX IF NOT EXISTS idx_rental_assets_barcode
    ON rental.rental_assets (barcode) WHERE barcode IS NOT NULL AND NOT is_deleted;

-- ── 3. Rental Asset Images ─────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS rental.rental_asset_images (
    id          UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID         NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    asset_id    UUID         NOT NULL REFERENCES rental.rental_assets(id) ON DELETE CASCADE,
    image_url   VARCHAR(500) NOT NULL,
    is_primary  BOOLEAN      NOT NULL DEFAULT FALSE,
    sort_order  INTEGER      NOT NULL DEFAULT 0,

    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by  UUID,
    updated_by  UUID,
    is_deleted  BOOLEAN     NOT NULL DEFAULT FALSE,
    deleted_at  TIMESTAMPTZ,
    deleted_by  UUID,
    version     BIGINT      NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_rental_images_asset ON rental.rental_asset_images (asset_id);

-- ── 4. Rental Bookings ─────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS rental.rental_bookings (
    id              UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID         NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    booking_number  VARCHAR(30)  NOT NULL,

    customer_id     UUID         NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    handled_by_user_id UUID      REFERENCES users(id) ON DELETE SET NULL,

    booking_type    SMALLINT     NOT NULL DEFAULT 0,  -- BookingType
    status          SMALLINT     NOT NULL DEFAULT 0,  -- BookingStatus

    booking_date    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    pickup_date     TIMESTAMPTZ  NOT NULL,
    return_due_date TIMESTAMPTZ  NOT NULL,
    actual_return_date TIMESTAMPTZ,
    event_date      TIMESTAMPTZ,
    event_location  VARCHAR(300),

    sub_total          DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount_amount    DECIMAL(12,2) NOT NULL DEFAULT 0,
    vat_amount         DECIMAL(12,2) NOT NULL DEFAULT 0,
    total_amount       DECIMAL(12,2) NOT NULL DEFAULT 0,
    deposit_required   DECIMAL(12,2) NOT NULL DEFAULT 0,
    deposit_paid       DECIMAL(12,2) NOT NULL DEFAULT 0,
    amount_paid        DECIMAL(12,2) NOT NULL DEFAULT 0,
    late_days          INTEGER      NOT NULL DEFAULT 0,
    late_penalty_total DECIMAL(12,2) NOT NULL DEFAULT 0,
    penalty_waived     BOOLEAN      NOT NULL DEFAULT FALSE,
    penalty_waived_by  UUID,

    contract_signed    BOOLEAN      NOT NULL DEFAULT FALSE,
    contract_pdf_url   VARCHAR(500),
    is_online_booking  BOOLEAN      NOT NULL DEFAULT FALSE,
    notes              VARCHAR(800),

    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by  UUID,
    updated_by  UUID,
    is_deleted  BOOLEAN     NOT NULL DEFAULT FALSE,
    deleted_at  TIMESTAMPTZ,
    deleted_by  UUID,
    version     BIGINT      NOT NULL DEFAULT 1,

    CONSTRAINT uq_booking_number UNIQUE (tenant_id, booking_number)
);

CREATE INDEX IF NOT EXISTS idx_rental_bookings_tenant_status
    ON rental.rental_bookings (tenant_id, status) WHERE NOT is_deleted;
CREATE INDEX IF NOT EXISTS idx_rental_bookings_customer
    ON rental.rental_bookings (tenant_id, customer_id) WHERE NOT is_deleted;
CREATE INDEX IF NOT EXISTS idx_rental_bookings_dates
    ON rental.rental_bookings (tenant_id, pickup_date, return_due_date) WHERE NOT is_deleted;

-- ── 5. Rental Booking Items ────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS rental.rental_booking_items (
    id               UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id        UUID         NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    booking_id       UUID         NOT NULL REFERENCES rental.rental_bookings(id) ON DELETE CASCADE,
    asset_id         UUID         NOT NULL REFERENCES rental.rental_assets(id) ON DELETE RESTRICT,

    quantity          INTEGER      NOT NULL DEFAULT 1,
    unit_price        DECIMAL(12,2) NOT NULL,
    deposit_amount    DECIMAL(12,2) NOT NULL DEFAULT 0,
    line_total        DECIMAL(12,2) NOT NULL,

    is_returned         BOOLEAN      NOT NULL DEFAULT FALSE,
    returned_at         TIMESTAMPTZ,
    condition_at_pickup VARCHAR(200),
    condition_at_return VARCHAR(200),

    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by  UUID,
    updated_by  UUID,
    is_deleted  BOOLEAN     NOT NULL DEFAULT FALSE,
    deleted_at  TIMESTAMPTZ,
    deleted_by  UUID,
    version     BIGINT      NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_booking_items_booking ON rental.rental_booking_items (booking_id);
CREATE INDEX IF NOT EXISTS idx_booking_items_asset   ON rental.rental_booking_items (asset_id);

-- ── 6. Rental Payments ─────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS rental.rental_payments (
    id                      UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID         NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    booking_id              UUID         NOT NULL REFERENCES rental.rental_bookings(id) ON DELETE CASCADE,

    amount                  DECIMAL(12,2) NOT NULL,
    payment_method          SMALLINT     NOT NULL,  -- RentalPaymentMethod
    purpose                 SMALLINT     NOT NULL,  -- RentalPaymentPurpose
    payment_date            TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    external_transaction_id VARCHAR(200),
    notes                   VARCHAR(500),
    is_refunded             BOOLEAN      NOT NULL DEFAULT FALSE,
    refunded_at             TIMESTAMPTZ,
    recorded_by             UUID,

    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by  UUID,
    updated_by  UUID,
    is_deleted  BOOLEAN     NOT NULL DEFAULT FALSE,
    deleted_at  TIMESTAMPTZ,
    deleted_by  UUID,
    version     BIGINT      NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_rental_payments_booking
    ON rental.rental_payments (booking_id);
CREATE INDEX IF NOT EXISTS idx_rental_payments_date
    ON rental.rental_payments (tenant_id, payment_date) WHERE NOT is_deleted;

-- ── 7. Damage Reports ──────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS rental.damage_reports (
    id                   UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id            UUID         NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    booking_id           UUID         NOT NULL REFERENCES rental.rental_bookings(id) ON DELETE RESTRICT,
    asset_id             UUID         NOT NULL REFERENCES rental.rental_assets(id) ON DELETE RESTRICT,

    title                VARCHAR(200) NOT NULL,
    description          VARCHAR(800),
    damage_level         SMALLINT     NOT NULL,  -- DamageLevel
    compensation_amount  DECIMAL(12,2) NOT NULL DEFAULT 0,
    compensation_paid    BOOLEAN      NOT NULL DEFAULT FALSE,
    compensation_paid_at TIMESTAMPTZ,
    damage_images_json   TEXT         NOT NULL DEFAULT '[]',
    requires_maintenance BOOLEAN      NOT NULL DEFAULT FALSE,
    reported_by          UUID,

    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by  UUID,
    updated_by  UUID,
    is_deleted  BOOLEAN     NOT NULL DEFAULT FALSE,
    deleted_at  TIMESTAMPTZ,
    deleted_by  UUID,
    version     BIGINT      NOT NULL DEFAULT 1
);

-- ── 8. Maintenance Logs ────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS rental.maintenance_logs (
    id               UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id        UUID         NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    asset_id         UUID         NOT NULL REFERENCES rental.rental_assets(id) ON DELETE CASCADE,
    damage_report_id UUID         REFERENCES rental.damage_reports(id) ON DELETE SET NULL,

    title            VARCHAR(200) NOT NULL,
    description      VARCHAR(800),
    technician_name  VARCHAR(200),
    cost             DECIMAL(12,2) NOT NULL DEFAULT 0,
    scheduled_date   TIMESTAMPTZ  NOT NULL,
    completed_date   TIMESTAMPTZ,
    is_completed     BOOLEAN      NOT NULL DEFAULT FALSE,

    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by  UUID,
    updated_by  UUID,
    is_deleted  BOOLEAN     NOT NULL DEFAULT FALSE,
    deleted_at  TIMESTAMPTZ,
    deleted_by  UUID,
    version     BIGINT      NOT NULL DEFAULT 1
);

-- ── 9. Marketplace Listings ────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS rental.marketplace_listings (
    id                  UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           UUID         NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    asset_id            UUID         NOT NULL REFERENCES rental.rental_assets(id) ON DELETE CASCADE,

    custom_description  VARCHAR(800),
    custom_tags         VARCHAR(300),
    is_visible          BOOLEAN      NOT NULL DEFAULT TRUE,
    view_count          INTEGER      NOT NULL DEFAULT 0,
    average_rating      DOUBLE PRECISION NOT NULL DEFAULT 0,
    review_count        INTEGER      NOT NULL DEFAULT 0,

    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by  UUID,
    updated_by  UUID,
    is_deleted  BOOLEAN     NOT NULL DEFAULT FALSE,
    deleted_at  TIMESTAMPTZ,
    deleted_by  UUID,
    version     BIGINT      NOT NULL DEFAULT 1,

    CONSTRAINT uq_marketplace_asset UNIQUE (asset_id)
);

-- ── 10. Seed Plans with Rental flags ──────────────────────────────────────
-- (اختياري — حدّث الخطط الموجودة)

UPDATE plans SET
    has_rental_module    = TRUE,
    max_rental_assets    = -1,   -- غير محدود
    has_rental_marketplace = TRUE,
    has_rental_ai_insights = TRUE
WHERE plan_type IN (3, 4);  -- Lifetime, Enterprise

UPDATE plans SET
    has_rental_module = TRUE,
    max_rental_assets = 200
WHERE plan_type = 2;  -- ProMonthly

-- ═══════════════════════════════════════════════════════════════════════════
-- Migration complete.
-- لتشغيله: psql -U mesterx -d mesterx_db -f rental_migration.sql
-- أو: dotnet ef migrations add AddRentalModule (بعد تعديل DbContext)
-- ═══════════════════════════════════════════════════════════════════════════
