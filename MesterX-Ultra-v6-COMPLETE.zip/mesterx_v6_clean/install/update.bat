@echo off
chcp 65001 >nul
title MesterX — تحديث تلقائي
color 0E

echo  [..] جاري فحص التحديثات...
cd /d "%ProgramFiles%\MesterX"

:: إيقاف الخدمات
docker compose down

:: سحب أحدث صور
docker compose pull

:: إعادة التشغيل
docker compose up -d --build

echo  [OK] تم التحديث بنجاح!
echo  [..] جاري إعادة التشغيل...
timeout /t 5
start "" http://localhost:3000
exit
