# 📦 دليل بناء الـ Installer

## طريقة 1: بناء Setup.exe باستخدام NSIS

### المتطلبات
- [NSIS 3.x](https://nsis.sourceforge.io/Download) مثبّت على الجهاز
- المشروع كامل في مجلد واحد

### الخطوات
```cmd
1. تثبيت NSIS
2. انقر بالزر الأيمن على MesterX-Setup.nsi
3. اختر "Compile NSIS Script"
4. بيطلع MesterX-Setup-v6.0.0.exe في نفس المجلد
```

## طريقة 2: تشغيل مباشر بدون Installer

```cmd
1. فك الـ ZIP في أي مجلد
2. انقر بالزر الأيمن على install\install.ps1
3. اختر "Run with PowerShell"
4. اقبل صلاحيات Administrator
```

## طريقة 3: سيلف-تشغيل من الـ ZIP

```cmd
بعد فك الـ ZIP:
double-click على: install\start.bat
```

## هيكل الملفات المطلوبة للـ Installer

```
MesterX-Ultra-v6/
├── install/
│   ├── MesterX-Setup.nsi  ← compile هذا
│   ├── install.ps1
│   ├── start.bat
│   ├── stop.bat
│   ├── update.bat
│   └── uninstall.bat
├── wizard/
│   └── index.html         ← First-Run Wizard
├── mobile/
│   └── qr-connect.html    ← QR Code page
├── dashboard/
│   └── index.html         ← Owner Dashboard
├── scripts/
│   ├── backup.ps1
│   ├── health-check.ps1
│   ├── auto-update.ps1
│   └── config-gen.ps1
├── installer-assets/
│   └── mesterx.ico        ← أيقونة المشروع (اختياري)
├── backend/
├── frontend/
├── database/
├── devops/
├── docker-compose.yml
└── .env.example
```

## بعد التثبيت — الملفات بتتحط في:

| الملف | المكان |
|-------|--------|
| البرنامج | `C:\Program Files\MesterX\` |
| البيانات | `C:\ProgramData\MesterX\` |
| الـ Logs | `C:\ProgramData\MesterX\logs\` |
| Backups | `C:\ProgramData\MasterX\backups\` |
| Config | `C:\ProgramData\MesterX\install-info.json` |

## اختصارات بعد التثبيت

| الاختصار | العمل |
|----------|-------|
| سطح المكتب: MesterX | تشغيل البرنامج |
| Start Menu > MesterX | كل الأوامر |
| `http://localhost:3000` | واجهة الكاشير |
| `http://localhost:5000/swagger` | API Documentation |
| `install\stop.bat` | إيقاف |
| `install\update.bat` | تحديث |

## Windows Scheduled Tasks (تلقائية)

| Task | الجدول |
|------|--------|
| MesterX-AutoStart | عند تسجيل الدخول |
| MesterX-DailyBackup | كل يوم الساعة 2 صباحاً |
| MesterX-HealthCheck | كل 5 دقائق |
