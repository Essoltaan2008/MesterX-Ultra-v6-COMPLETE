; ═══════════════════════════════════════════════════════════════════════════
; MesterX Ultra Enterprise v6 — NSIS Installer Script
; نسخّ هذا الملف + مجلد المشروع → تشغّل makensis → يطلع Setup.exe
; ═══════════════════════════════════════════════════════════════════════════

!define APP_NAME     "MesterX Ultra Enterprise"
!define APP_VERSION  "6.0.0"
!define APP_COMPANY  "MesterX"
!define APP_URL      "https://mesterx.com"
!define INSTALL_DIR  "$PROGRAMFILES\MesterX"

Unicode true
Name          "${APP_NAME} v${APP_VERSION}"
OutFile       "MesterX-Setup-v${APP_VERSION}.exe"
InstallDir    "${INSTALL_DIR}"
ShowInstDetails show
SetCompressor /SOLID lzma

; ── Request Admin ──────────────────────────────────────────────────────────
RequestExecutionLevel admin

; ── Include Modern UI ──────────────────────────────────────────────────────
!include "MUI2.nsh"
!include "LogicLib.nsh"

; ── MUI Settings ────────────────────────────────────────────────────────────
!define MUI_ABORTWARNING
!define MUI_ICON "installer-assets\mesterx.ico"
!define MUI_UNICON "installer-assets\mesterx.ico"
!define MUI_WELCOMEPAGE_TITLE "أهلاً بك في MesterX v${APP_VERSION}"
!define MUI_WELCOMEPAGE_TEXT "هذا الـ Wizard سيرشدك خلال عملية تثبيت MesterX Ultra Enterprise.$\n$\nالبرنامج يعمل على Windows 10/11 ويتطلب Docker Desktop.$\nانقر التالي للمتابعة."
!define MUI_FINISHPAGE_RUN     "$INSTDIR\install\start.bat"
!define MUI_FINISHPAGE_RUN_TEXT "تشغيل MesterX الآن"
!define MUI_FINISHPAGE_SHOWREADME "$INSTDIR\README.md"
!define MUI_FINISHPAGE_SHOWREADME_TEXT "عرض دليل الاستخدام"

; ── Pages ───────────────────────────────────────────────────────────────────
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "README.md"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_WELCOME
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_UNPAGE_FINISH

; ── Language ─────────────────────────────────────────────────────────────────
!insertmacro MUI_LANGUAGE "Arabic"
!insertmacro MUI_LANGUAGE "English"

; ── Version Info ─────────────────────────────────────────────────────────────
VIProductVersion "${APP_VERSION}.0"
VIAddVersionKey "ProductName"     "${APP_NAME}"
VIAddVersionKey "ProductVersion"  "${APP_VERSION}"
VIAddVersionKey "CompanyName"     "${APP_COMPANY}"
VIAddVersionKey "LegalCopyright"  "© 2025 MesterX"
VIAddVersionKey "FileDescription" "${APP_NAME} Installer"
VIAddVersionKey "FileVersion"     "${APP_VERSION}"

; ════════════════════════════════════════════════════════════════════════════
; INSTALL SECTION
; ════════════════════════════════════════════════════════════════════════════
Section "MesterX Core" SEC_CORE
    SectionIn RO
    SetOutPath "$INSTDIR"

    ; ── نسخ كل ملفات المشروع ───────────────────────────────────────────────
    File /r "backend\"
    File /r "frontend\"
    File /r "database\"
    File /r "devops\"
    File /r "install\"
    File /r "wizard\"
    File /r "mobile\"
    File /r "dashboard\"
    File /r "scripts\"
    File "docker-compose.yml"
    File ".env.example"
    File "README.md"
    File "MesterX-Ultra-v6.sln"

    ; ── تشغيل PowerShell Installer ─────────────────────────────────────────
    DetailPrint "جاري إعداد البرنامج..."
    nsExec::ExecToLog 'powershell.exe -ExecutionPolicy Bypass -File "$INSTDIR\install\install.ps1"'

    ; ── اختصار سطح المكتب ──────────────────────────────────────────────────
    CreateShortCut "$DESKTOP\MesterX.lnk" "$INSTDIR\install\start.bat" "" "$INSTDIR\installer-assets\mesterx.ico"

    ; ── Start Menu ──────────────────────────────────────────────────────────
    CreateDirectory "$SMPROGRAMS\MesterX"
    CreateShortCut  "$SMPROGRAMS\MesterX\MesterX.lnk"           "$INSTDIR\install\start.bat"     "" "$INSTDIR\installer-assets\mesterx.ico"
    CreateShortCut  "$SMPROGRAMS\MesterX\ايقاف MesterX.lnk"     "$INSTDIR\install\stop.bat"      "" "$INSTDIR\installer-assets\mesterx.ico"
    CreateShortCut  "$SMPROGRAMS\MesterX\تحديث MesterX.lnk"     "$INSTDIR\install\update.bat"    "" "$INSTDIR\installer-assets\mesterx.ico"
    CreateShortCut  "$SMPROGRAMS\MesterX\الغاء التثبيت.lnk"     "$INSTDIR\Uninstall.exe"         ""
    CreateShortCut  "$SMPROGRAMS\MesterX\لوحة التحكم.lnk"       "$INSTDIR\dashboard\index.html"  ""

    ; ── Windows Registry ────────────────────────────────────────────────────
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MesterX" "DisplayName"     "${APP_NAME} v${APP_VERSION}"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MesterX" "UninstallString" "$INSTDIR\Uninstall.exe"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MesterX" "DisplayVersion"  "${APP_VERSION}"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MesterX" "Publisher"       "${APP_COMPANY}"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MesterX" "URLInfoAbout"    "${APP_URL}"
    WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MesterX" "NoModify"      1
    WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MesterX" "NoRepair"       1

    WriteUninstaller "$INSTDIR\Uninstall.exe"
SectionEnd

; ── Scheduled Tasks ────────────────────────────────────────────────────────
Section "النسخ الاحتياطي التلقائي" SEC_BACKUP
    DetailPrint "إعداد النسخ الاحتياطي اليومي..."
    nsExec::ExecToLog 'schtasks /create /tn "MesterX-DailyBackup" /tr "powershell.exe -File \"$INSTDIR\scripts\backup.ps1\"" /sc daily /st 02:00 /f'
SectionEnd

; ── Health Monitor ─────────────────────────────────────────────────────────
Section "مراقبة الخدمات" SEC_HEALTH
    DetailPrint "إعداد مراقبة الخدمات..."
    nsExec::ExecToLog 'schtasks /create /tn "MesterX-HealthCheck" /tr "powershell.exe -File \"$INSTDIR\scripts\health-check.ps1\"" /sc minute /mo 5 /f'
SectionEnd

; ════════════════════════════════════════════════════════════════════════════
; UNINSTALL SECTION
; ════════════════════════════════════════════════════════════════════════════
Section "Uninstall"
    ; إيقاف الخدمات
    nsExec::ExecToLog 'cmd /c cd /d "$INSTDIR" && docker compose down -v'

    ; حذف Scheduled Tasks
    nsExec::ExecToLog 'schtasks /delete /tn "MesterX-AutoStart"   /f'
    nsExec::ExecToLog 'schtasks /delete /tn "MesterX-DailyBackup" /f'
    nsExec::ExecToLog 'schtasks /delete /tn "MesterX-HealthCheck" /f'

    ; حذف الملفات
    RMDir /r "$INSTDIR"

    ; حذف الاختصارات
    Delete "$DESKTOP\MesterX.lnk"
    RMDir /r "$SMPROGRAMS\MesterX"

    ; حذف Registry
    DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MesterX"

    MessageBox MB_OK "تم إلغاء تثبيت MesterX بنجاح.$\nالبيانات محفوظة في: $PROGRAMDATA\MesterX\backups"
SectionEnd
