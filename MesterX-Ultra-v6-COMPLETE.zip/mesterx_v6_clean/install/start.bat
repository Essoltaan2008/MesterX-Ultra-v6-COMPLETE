@echo off
chcp 65001 >nul
title MesterX Ultra Enterprise v6
color 0B

echo.
echo  ████████████████████████████████████████
echo  █   MesterX Ultra Enterprise v6        █
echo  █   جاري التشغيل...                   █
echo  ████████████████████████████████████████
echo.

cd /d "%ProgramFiles%\MesterX"

:: فحص Docker
docker info >nul 2>&1
if errorlevel 1 (
    echo  [!!] Docker مش شغّال - جاري التشغيل...
    start "" "C:\Program Files\Docker\Docker\Docker Desktop.exe"
    timeout /t 15 /nobreak >nul
)

:: تشغيل الخدمات
echo  [..] جاري تشغيل قاعدة البيانات والـ API...
docker compose up -d

:: انتظار الـ API
echo  [..] انتظار جاهزية الـ API...
:WAIT_LOOP
curl -s http://localhost:5000/health >nul 2>&1
if errorlevel 1 (
    timeout /t 3 /nobreak >nul
    goto WAIT_LOOP
)

echo.
echo  [OK] MesterX شغّال بنجاح!
echo.
echo  الـ Frontend : http://localhost:3000
echo  الـ API Docs : http://localhost:5000/swagger
echo.

:: فتح المتصفح
start "" http://localhost:3000

:: فتح Wizard لو أول تشغيل
if exist "%ProgramData%\MesterX\install-info.json" (
    powershell -Command "$info=Get-Content '%ProgramData%\MesterX\install-info.json'|ConvertFrom-Json; if($info.wizardDone -eq $false){Start-Process '%ProgramFiles%\MesterX\wizard\index.html'}"
)

exit
