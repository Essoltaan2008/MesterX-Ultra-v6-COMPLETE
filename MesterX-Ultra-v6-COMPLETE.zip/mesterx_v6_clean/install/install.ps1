#Requires -RunAsAdministrator
$ErrorActionPreference = "Stop"
$VERSION     = "6.0.0"
$INSTALL_DIR = "$env:ProgramFiles\MesterX"
$DATA_DIR    = "$env:ProgramData\MesterX"
$LOG_DIR     = "$DATA_DIR\logs"
$BACKUP_DIR  = "$DATA_DIR\backups"

function Write-Step { param($n,$t) Write-Host "`n[$n/8] $t" -ForegroundColor Cyan }
function Write-OK   { param($t) Write-Host "  [OK] $t" -ForegroundColor Green }
function Write-WARN { param($t) Write-Host "  [!!] $t" -ForegroundColor Yellow }
function Write-FAIL { param($t) Write-Host "  [XX] $t" -ForegroundColor Red; exit 1 }

Clear-Host
Write-Host "  ███╗   ███╗███████╗███████╗████████╗███████╗██████╗ ██╗  ██╗" -ForegroundColor Cyan
Write-Host "  MesterX Ultra Enterprise v6 — Windows Installer" -ForegroundColor White
Write-Host "  صُنع في مصر  |  EGP  |  VAT 14%" -ForegroundColor DarkGray
Write-Host ""

Write-Step 1 "فحص المتطلبات..."
$winVer = [System.Environment]::OSVersion.Version
if ($winVer.Major -lt 10) { Write-FAIL "Windows 10 او احدث مطلوب" }
Write-OK "Windows $($winVer.Major).$($winVer.Minor)"

$ram = (Get-CimInstance Win32_PhysicalMemory | Measure-Object Capacity -Sum).Sum / 1GB
if ($ram -lt 4) { Write-WARN "RAM اقل من 4GB" } else { Write-OK "RAM: $([math]::Round($ram,1)) GB" }

$disk = (Get-PSDrive C).Free / 1GB
if ($disk -lt 10) { Write-FAIL "مساحة C: اقل من 10GB" }
Write-OK "مساحة: $([math]::Round($disk,1)) GB"

Write-Step 2 "فحص Docker Desktop..."
$dockerPath = Get-Command docker -ErrorAction SilentlyContinue
if (-not $dockerPath) {
    Write-WARN "Docker مش مثبت - جاري التحميل (~500MB)..."
    $installer = "$env:TEMP\DockerDesktopInstaller.exe"
    Invoke-WebRequest -Uri "https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe" -OutFile $installer -UseBasicParsing
    Start-Process -FilePath $installer -ArgumentList "install --quiet" -Wait
    Write-OK "Docker اتثبت - ممكن تحتاج restart"
} else {
    Write-OK "Docker موجود: $(docker --version 2>$null)"
}

Write-Step 3 "انشاء المجلدات..."
@($INSTALL_DIR,$DATA_DIR,$LOG_DIR,$BACKUP_DIR,"$DATA_DIR\wizard-config") | ForEach-Object {
    New-Item -ItemType Directory -Force -Path $_ | Out-Null
    Write-OK "تم: $_"
}

Write-Step 4 "نسخ ملفات MesterX..."
$source = Split-Path -Parent $PSScriptRoot
Copy-Item -Path "$source\*" -Destination $INSTALL_DIR -Recurse -Force -Exclude @("install","installer-assets","*.zip","*.7z")
Write-OK "الملفات اتنسخت"

Write-Step 5 "توليد اعدادات الامان..."
function New-SecurePass {
    $c = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz0123456789!@#"
    $b = [byte[]]::new(32)
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
    -join ($b | ForEach-Object { $c[$_ % $c.Length] })
}
function New-HexKey {
    $b = [byte[]]::new(64)
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
    ($b | ForEach-Object { "{0:x2}" -f $_ }) -join ""
}

$dbPass = New-SecurePass
$jwtSec = New-HexKey
$fp = [System.Security.Cryptography.SHA256]::Create().ComputeHash(
    [System.Text.Encoding]::UTF8.GetBytes("$env:COMPUTERNAME-$env:USERNAME-MX6")
)
$deviceFP = ($fp | ForEach-Object { "{0:x2}" -f $_ }) -join ""

@"
# MesterX v$VERSION — Auto-Generated | $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
DB_HOST=db
DB_PORT=5432
DB_NAME=mesterxdb
DB_USER=mesterx
DB_PASSWORD=$dbPass
JWT_SECRET=$jwtSec
ENVIRONMENT=Production
NEXT_PUBLIC_API_URL=http://localhost:5000/api
FRONTEND_URL=http://localhost:3000
VAT_RATE=0.14
CURRENCY=EGP
CURRENCY_SYMBOL=ج.م
DEVICE_FINGERPRINT=$deviceFP
"@ | Set-Content "$INSTALL_DIR\.env" -Encoding UTF8
Write-OK "ملف .env اتولد باسرار آمنة"

Write-Step 6 "اعداد التشغيل التلقائي مع Windows..."
$taskScript = "$INSTALL_DIR\install\start-silent.ps1"
"Set-Location '$INSTALL_DIR'; Start-Process docker -ArgumentList 'compose up -d' -WindowStyle Hidden -Wait" | Set-Content $taskScript -Encoding UTF8

$action   = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$taskScript`""
$trigger  = New-ScheduledTaskTrigger -AtLogOn
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 5)
Register-ScheduledTask -TaskName "MesterX-AutoStart" -Action $action -Trigger $trigger -Settings $settings -RunLevel Highest -Force | Out-Null
Write-OK "Auto-start مع Windows"

Write-Step 7 "انشاء الاختصارات..."
$shell   = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath("CommonDesktopDirectory")
$sc = $shell.CreateShortcut("$desktop\MesterX.lnk")
$sc.TargetPath = "$INSTALL_DIR\install\start.bat"
$sc.WorkingDirectory = $INSTALL_DIR
$sc.Description = "MesterX Ultra Enterprise v6"
$sc.Save()
Write-OK "اختصار سطح المكتب"

Write-Step 8 "حفظ بيانات التثبيت..."
@{
    version=      $VERSION
    installDate=  (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    installDir=   $INSTALL_DIR
    dataDir=      $DATA_DIR
    computerName= $env:COMPUTERNAME
    firstRun=     $true
    wizardDone=   $false
} | ConvertTo-Json | Set-Content "$DATA_DIR\install-info.json" -Encoding UTF8
Write-OK "بيانات التثبيت"

Write-Host ""
Write-Host "═══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  MesterX تم تثبيته بنجاح!" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "  جاري فتح wizard الاعداد الاول..." -ForegroundColor Yellow

Start-Sleep 2
Start-Process "$INSTALL_DIR\wizard\index.html"
