@echo off
chcp 65001 >nul
title MesterX — إلغاء التثبيت
color 0C

echo  تحذير: سيتم حذف MesterX بالكامل.
echo  هل تريد نسخ احتياطي قبل الحذف؟
choice /c YN /m "نعم/لا"

if errorlevel 2 goto SKIP_BACKUP

echo  [..] جاري عمل نسخة احتياطية...
cd /d "%ProgramFiles%\MesterX"
powershell -File scripts\backup.ps1
echo  [OK] النسخة الاحتياطية في %ProgramData%\MesterX\backups\

:SKIP_BACKUP
echo  [..] إيقاف الخدمات...
docker compose down -v

echo  [..] حذف Scheduled Task...
schtasks /delete /tn "MesterX-AutoStart" /f >nul 2>&1

echo  [..] حذف اختصار سطح المكتب...
del /f /q "%PUBLIC%\Desktop\MesterX.lnk" >nul 2>&1

echo  [..] حذف ملفات البرنامج...
rd /s /q "%ProgramFiles%\MesterX" >nul 2>&1

echo.
echo  [OK] تم إلغاء تثبيت MesterX.
pause
