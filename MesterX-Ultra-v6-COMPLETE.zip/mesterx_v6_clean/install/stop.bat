@echo off
chcp 65001 >nul
title MesterX — إيقاف
color 0C

echo  [..] جاري إيقاف MesterX...
cd /d "%ProgramFiles%\MesterX"
docker compose down

echo  [OK] تم الإيقاف بنجاح.
timeout /t 2 >nul
exit
