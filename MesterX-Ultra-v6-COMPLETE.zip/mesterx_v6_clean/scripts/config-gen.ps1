param(
    [string]$BusinessType  = "supermarket",
    [string]$BusinessName  = "متجري",
    [string]$OwnerName     = "",
    [string]$OwnerPhone    = "",
    [string]$OwnerEmail    = "",
    [string]$AdminPassword = "",
    [string]$BranchName    = "الفرع الرئيسي",
    [string]$City          = "القاهرة"
)

$INSTALL_DIR = "$env:ProgramFiles\MesterX"
$DATA_DIR    = "$env:ProgramData\MesterX"
$configFile  = "$DATA_DIR\wizard-config\business.json"

@{
    businessType  = $BusinessType
    businessName  = $BusinessName
    ownerName     = $OwnerName
    ownerPhone    = $OwnerPhone
    ownerEmail    = $OwnerEmail
    adminPassword = $AdminPassword
    branchName    = $BranchName
    city          = $City
    currency      = "EGP"
    vatRate       = 0.14
    configDate    = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
} | ConvertTo-Json | Set-Content $configFile -Encoding UTF8

Write-Host "[OK] Config محفوظ: $configFile"

# تطبيق الإعدادات على البرنامج عبر API
$apiBase = "http://localhost:5000/api"
$headers = @{"Content-Type" = "application/json"}

# تسجيل الـ Tenant
$tenantBody = @{
    name         = $BusinessName
    slug         = ($BusinessName -replace "\s+","-").ToLower() -replace "[^a-z0-9-]",""
    city         = $City
    vatRate      = 0.14
    currency     = "EGP"
    businessType = $BusinessType
} | ConvertTo-Json

try {
    $r = Invoke-RestMethod -Uri "$apiBase/admin/setup" -Method Post -Body $tenantBody -Headers $headers
    Write-Host "[OK] الـ Tenant اتسجّل: $($r.data.id)"

    # تحديث install-info
    $info = Get-Content "$DATA_DIR\install-info.json" | ConvertFrom-Json
    $info.wizardDone = $true
    $info.tenantId   = $r.data.id
    $info | ConvertTo-Json | Set-Content "$DATA_DIR\install-info.json" -Encoding UTF8
} catch {
    Write-Host "[!!] الـ API مش شغّال بعد — الإعدادات هتتطبق عند أول تشغيل"
}
