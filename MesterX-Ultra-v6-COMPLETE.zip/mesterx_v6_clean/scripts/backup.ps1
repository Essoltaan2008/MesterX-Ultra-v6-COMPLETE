param([string]$BackupDir = "$env:ProgramData\MesterX\backups")

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupPath = "$BackupDir\backup-$timestamp"
New-Item -ItemType Directory -Force -Path $backupPath | Out-Null

Write-Host "[..] بدء النسخ الاحتياطي: $timestamp"

# نسخ احتياطي لقاعدة البيانات
Write-Host "[..] نسخ قاعدة البيانات..."
$env:PGPASSWORD = (Get-Content "$env:ProgramFiles\MesterX\.env" | Where-Object {$_ -match "^DB_PASSWORD="} | ForEach-Object {$_ -replace "DB_PASSWORD=",""})
docker exec mesterx_db pg_dump -U mesterx mesterxdb -F c -f /tmp/mesterx-backup.dump 2>$null
docker cp mesterx_db:/tmp/mesterx-backup.dump "$backupPath\database.dump"
Write-Host "[OK] قاعدة البيانات"

# نسخ ملف .env
Copy-Item "$env:ProgramFiles\MesterX\.env" "$backupPath\.env.bak"
Copy-Item "$env:ProgramData\MesterX\install-info.json" "$backupPath\install-info.json.bak"

# ضغط النسخة
Compress-Archive -Path $backupPath -DestinationPath "$BackupDir\backup-$timestamp.zip"
Remove-Item -Path $backupPath -Recurse -Force

# حذف نسخ قديمة (احتفظ بآخر 7)
Get-ChildItem $BackupDir -Filter "*.zip" | Sort-Object CreationTime -Descending | Select-Object -Skip 7 | Remove-Item -Force

Write-Host "[OK] النسخة الاحتياطية: $BackupDir\backup-$timestamp.zip"
