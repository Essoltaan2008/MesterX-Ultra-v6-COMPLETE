$LOG = "$env:ProgramData\MesterX\logs\health-$(Get-Date -Format 'yyyy-MM-dd').log"

function Log($msg) { "$(Get-Date -Format 'HH:mm:ss') $msg" | Add-Content $LOG }

$services = @(
    @{Name="API";     Url="http://localhost:5000/health"}
    @{Name="Frontend";Url="http://localhost:3000"}
)

foreach ($svc in $services) {
    try {
        $r = Invoke-WebRequest -Uri $svc.Url -TimeoutSec 5 -UseBasicParsing
        if ($r.StatusCode -eq 200) { Log "[OK] $($svc.Name) يعمل بطبيعية" }
        else { Log "[!!] $($svc.Name) رجع StatusCode: $($r.StatusCode)" }
    } catch {
        Log "[XX] $($svc.Name) لا يستجيب — جاري إعادة التشغيل..."
        Set-Location "$env:ProgramFiles\MesterX"
        docker compose restart 2>>$LOG
    }
}
