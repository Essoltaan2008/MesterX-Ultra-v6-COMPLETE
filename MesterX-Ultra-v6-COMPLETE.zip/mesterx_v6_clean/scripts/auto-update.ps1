$UPDATE_URL  = "https://updates.mesterx.com/v6/version.json"
$INSTALL_DIR = "$env:ProgramFiles\MesterX"
$DATA_DIR    = "$env:ProgramData\MesterX"
$LOG         = "$DATA_DIR\logs\update-$(Get-Date -Format 'yyyyMMdd').log"

function Log($msg) { "$(Get-Date -Format 'HH:mm:ss') $msg" | Add-Content $LOG }

try {
    $current = (Get-Content "$DATA_DIR\install-info.json" | ConvertFrom-Json).version
    Log "الإصدار الحالي: $current"
    
    # فحص أحدث إصدار
    try {
        $latest = (Invoke-WebRequest -Uri $UPDATE_URL -TimeoutSec 10 -UseBasicParsing | ConvertFrom-Json)
        if ($latest.version -ne $current) {
            Log "إصدار جديد متوفر: $($latest.version)"
            
            # إشعار المستخدم
            Add-Type -AssemblyName System.Windows.Forms
            $result = [System.Windows.Forms.MessageBox]::Show(
                "إصدار جديد من MesterX متوفر ($($latest.version))`nهل تريد التحديث الآن؟",
                "تحديث MesterX", 
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Information
            )
            
            if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
                Set-Location $INSTALL_DIR
                docker compose pull
                docker compose up -d --build
                Log "تم التحديث بنجاح"
            }
        } else {
            Log "أحدث إصدار مثبّت بالفعل"
        }
    } catch {
        Log "لا يوجد اتصال بخادم التحديثات — تجاوز"
    }
} catch {
    Log "خطأ في فحص التحديثات: $_"
}
