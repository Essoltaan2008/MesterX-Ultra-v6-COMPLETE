import type { AppProps } from 'next/app';
import { useEffect } from 'react';
import { useAuthStore } from '@/lib/store';
import { authAPI } from '@/lib/api';
import { Toaster } from 'react-hot-toast';
import '@/styles/globals.css';

export default function App({ Component, pageProps }: AppProps) {
  const { login } = useAuthStore();

  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      authAPI.me().then((res) => {
        login(res.data.data, token, localStorage.getItem('refreshToken') || '');
      });
    }
  }, [login]);

  return (
    <>
      <Component {...pageProps} />
      <Toaster />
    </>
  );
}
