import { useEffect, useState } from 'react';
import Layout from '@/components/Layout';
import { dashboardAPI, salesAPI } from '@/lib/api';
import { useAuthStore } from '@/lib/store';
import { useRouter } from 'next/router';

export default function Dashboard() {
  const router = useRouter();
  const { user } = useAuthStore();
  const [dashboard, setDashboard] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      router.push('/login');
      return;
    }

    dashboardAPI
      .getDashboard()
      .then((res) => setDashboard(res.data.data))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, [user, router]);

  if (!user) return null;

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading dashboard...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <p className="text-gray-600 text-sm">Today's Revenue</p>
          <p className="text-3xl font-bold text-indigo-600">
            {dashboard?.todayRevenue.toLocaleString()} EGP
          </p>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <p className="text-gray-600 text-sm">Today's Sales</p>
          <p className="text-3xl font-bold text-green-600">{dashboard?.todayTransactions}</p>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <p className="text-gray-600 text-sm">Total Customers</p>
          <p className="text-3xl font-bold text-blue-600">{dashboard?.totalCustomers}</p>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <p className="text-gray-600 text-sm">Low Stock Items</p>
          <p className="text-3xl font-bold text-orange-600">{dashboard?.lowStockProducts}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Weekly Revenue</h3>
          <p className="text-2xl font-bold text-indigo-600">
            {dashboard?.weekRevenue.toLocaleString()} EGP
          </p>
          <p className="text-gray-500 text-sm mt-2">{dashboard?.weekTransactions} transactions</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Monthly Revenue</h3>
          <p className="text-2xl font-bold text-indigo-600">
            {dashboard?.monthRevenue.toLocaleString()} EGP
          </p>
          <p className="text-gray-500 text-sm mt-2">{dashboard?.monthTransactions} transactions</p>
        </div>
      </div>
    </Layout>
  );
}
