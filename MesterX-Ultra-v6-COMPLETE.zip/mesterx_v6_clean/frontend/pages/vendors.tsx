import { useEffect, useState } from 'react';
import Layout from '@/components/Layout';
import { vendorsAPI } from '@/lib/api';
import { useAuthStore } from '@/lib/store';
import { useRouter } from 'next/router';

export default function Vendors() {
  const router = useRouter();
  const { user } = useAuthStore();
  const [vendors, setVendors] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      router.push('/login');
      return;
    }

    loadVendors();
  }, [user, router, search]);

  const loadVendors = () => {
    setLoading(true);
    vendorsAPI
      .search({ search, type: null, page: 1, pageSize: 20 })
      .then((res) => setVendors(res.data.data))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  if (!user) return null;

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">Wedding Vendors</h1>

        <div className="flex gap-4 mb-6">
          <input
            type="text"
            placeholder="Search vendors..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
          />
          <button
            onClick={loadVendors}
            className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            Search
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {vendors.map((vendor) => (
            <div key={vendor.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition">
              {vendor.logoUrl && (
                <img src={vendor.logoUrl} alt={vendor.businessName} className="w-full h-48 object-cover" />
              )}
              <div className="p-6">
                <h3 className="text-lg font-bold text-gray-800">{vendor.businessName}</h3>
                <p className="text-gray-600 text-sm mb-2">{vendor.vendorType}</p>
                <div className="flex items-center mb-4">
                  <span className="text-yellow-500">⭐ {vendor.rating.toFixed(1)}</span>
                  <span className="text-gray-500 text-sm ml-2">({vendor.reviewCount} reviews)</span>
                </div>
                {vendor.address && (
                  <p className="text-gray-500 text-sm mb-4">📍 {vendor.address}</p>
                )}
                <button
                  onClick={() => router.push(`/vendors/${vendor.id}`)}
                  className="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                >
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </Layout>
  );
}
