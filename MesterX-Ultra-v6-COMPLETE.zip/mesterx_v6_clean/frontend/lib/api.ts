import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  register: (data: any) => apiClient.post('/auth/register', data),
  login: (data: any) => apiClient.post('/auth/login', data),
  logout: () => apiClient.post('/auth/logout'),
  me: () => apiClient.get('/auth/me'),
};

export const productsAPI = {
  list: (page: number = 1) => apiClient.get(`/inventory/products?page=${page}`),
  create: (data: any) => apiClient.post('/inventory/products', data),
  update: (id: string, data: any) => apiClient.put(`/inventory/products/${id}`, data),
  delete: (id: string) => apiClient.delete(`/inventory/products/${id}`),
};

export const salesAPI = {
  list: () => apiClient.get('/pos/sales'),
  create: (data: any) => apiClient.post('/pos/sales', data),
  getById: (id: string) => apiClient.get(`/pos/sales/${id}`),
};

export const vendorsAPI = {
  search: (params: any) => apiClient.get('/vendors/search', { params }),
  getDetail: (id: string) => apiClient.get(`/vendors/${id}`),
  create: (data: any) => apiClient.post('/vendors', data),
};

export const bookingsAPI = {
  list: () => apiClient.get('/bookings'),
  create: (data: any) => apiClient.post('/bookings', data),
  getById: (id: string) => apiClient.get(`/bookings/${id}`),
  confirm: (id: string) => apiClient.post(`/bookings/${id}/confirm`),
  cancel: (id: string, reason: string) => apiClient.post(`/bookings/${id}/cancel`, { reason }),
};

export const dashboardAPI = {
  getDashboard: () => apiClient.get('/dashboard'),
  getSales: (from: string, to: string) => apiClient.get('/reports/sales', { params: { from, to } }),
};

export default apiClient;
